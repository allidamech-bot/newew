/**
 * Supabase-ready adapter layer.
 * These repositories intentionally throw until credentials and schema are applied.
 * UI and service locator continue using mock adapters in mock mode.
 */
import { AppError } from "@/lib/errors";
import type {
  AnalyticsRepository,
  AuditRepository,
  AuthRepository,
  BrandRepository,
  CartRepository,
  CatalogRepository,
  CategoryRepository,
  CmsRepository,
  ConversationRepository,
  DisputeRepository,
  InventoryRepository,
  MediaStorageProvider,
  ModerationRepository,
  NotificationRepository,
  OfferRepository,
  OrderRepository,
  PaymentProvider,
  ProfileRepository,
  PromotionRepository,
  ReturnsRepository,
  ReviewRepository,
  SearchProvider,
  ShippingProvider,
  StoreRepository,
  WishlistRepository,
} from "@/repositories/types";

function notConfigured(): never {
  throw new AppError(
    "SERVER_ERROR",
    "Supabase provider is not configured. Keep NEXT_PUBLIC_DATA_PROVIDER=mock or complete Supabase setup.",
    { status: 503 }
  );
}

const auth: AuthRepository = {
  signIn: async () => notConfigured(),
  signUp: async () => notConfigured(),
  signOut: async () => notConfigured(),
  getSession: async () => notConfigured(),
  requestPasswordReset: async () => notConfigured(),
  listDemoAccounts: async () => notConfigured(),
};

const profile: ProfileRepository = {
  getById: async () => notConfigured(),
  update: async () => notConfigured(),
  listAddresses: async () => notConfigured(),
  createAddress: async () => notConfigured(),
  updateAddress: async () => notConfigured(),
  deleteAddress: async () => notConfigured(),
};

const catalog: CatalogRepository = {
  listProducts: async () => notConfigured(),
  getProductBySlug: async () => notConfigured(),
  getProductById: async () => notConfigured(),
  listRelated: async () => notConfigured(),
  createProduct: async () => notConfigured(),
  updateProduct: async () => notConfigured(),
  listByStore: async () => notConfigured(),
};

const categories: CategoryRepository = {
  list: async () => notConfigured(),
  getBySlug: async () => notConfigured(),
  getTree: async () => notConfigured(),
  listAttributes: async () => notConfigured(),
  listAllAttributes: async () => notConfigured(),
  createCategory: async () => notConfigured(),
  updateCategory: async () => notConfigured(),
};

const stores: StoreRepository = {
  list: async () => notConfigured(),
  getBySlug: async () => notConfigured(),
  getById: async () => notConfigured(),
  listByOwner: async () => notConfigured(),
  follow: async () => notConfigured(),
  unfollow: async () => notConfigured(),
  listFollowed: async () => notConfigured(),
  updateStore: async () => notConfigured(),
};

const brands: BrandRepository = {
  list: async () => notConfigured(),
};

const cart: CartRepository = {
  getCart: async () => notConfigured(),
  addItem: async () => notConfigured(),
  updateItem: async () => notConfigured(),
  removeItem: async () => notConfigured(),
  applyCoupon: async () => notConfigured(),
  clearCoupon: async () => notConfigured(),
  mergeGuestCart: async () => notConfigured(),
  saveForLater: async () => notConfigured(),
};

const orders: OrderRepository = {
  createFromCart: async () => notConfigured(),
  listByBuyer: async () => notConfigured(),
  listByStore: async () => notConfigured(),
  getById: async () => notConfigured(),
  updateStatus: async () => notConfigured(),
  cancel: async () => notConfigured(),
};

const reviews: ReviewRepository = {
  listByProduct: async () => notConfigured(),
  listByStore: async () => notConfigured(),
  listByBuyer: async () => notConfigured(),
  create: async () => notConfigured(),
  respond: async () => notConfigured(),
};

const conversations: ConversationRepository = {
  listForUser: async () => notConfigured(),
  get: async () => notConfigured(),
  listMessages: async () => notConfigured(),
  sendMessage: async () => notConfigured(),
  markRead: async () => notConfigured(),
};

const notifications: NotificationRepository = {
  list: async () => notConfigured(),
  markRead: async () => notConfigured(),
  markAllRead: async () => notConfigured(),
};

const wishlists: WishlistRepository = {
  list: async () => notConfigured(),
  addItem: async () => notConfigured(),
  removeItem: async () => notConfigured(),
  listProductIds: async () => notConfigured(),
};

const promotions: PromotionRepository = {
  listActive: async () => notConfigured(),
  validateCoupon: async () => notConfigured(),
};

const search: SearchProvider = {
  search: async () => notConfigured(),
  suggest: async () => notConfigured(),
  trending: async () => notConfigured(),
};

const inventory: InventoryRepository = {
  listByStore: async () => notConfigured(),
  adjust: async () => notConfigured(),
};

const shipping: ShippingProvider = {
  listMethods: async () => notConfigured(),
  estimate: async () => notConfigured(),
};

const payments: PaymentProvider = {
  createIntent: async () => notConfigured(),
  confirm: async () => notConfigured(),
};

const media: MediaStorageProvider = {
  upload: async () => notConfigured(),
  getPublicUrl: async () => notConfigured(),
};

const moderation: ModerationRepository = {
  listReports: async () => notConfigured(),
  updateReport: async () => notConfigured(),
  listPendingProducts: async () => notConfigured(),
  moderateProduct: async () => notConfigured(),
  listSellerApplications: async () => notConfigured(),
  reviewApplication: async () => notConfigured(),
};

const returnsRepo: ReturnsRepository = {
  listByBuyer: async () => notConfigured(),
  listByStore: async () => notConfigured(),
  create: async () => notConfigured(),
  updateStatus: async () => notConfigured(),
};

const disputes: DisputeRepository = {
  list: async () => notConfigured(),
  listByBuyer: async () => notConfigured(),
  create: async () => notConfigured(),
  updateStatus: async () => notConfigured(),
};

const offers: OfferRepository = {
  listForUser: async () => notConfigured(),
  create: async () => notConfigured(),
  respond: async () => notConfigured(),
};

const analytics: AnalyticsRepository = {
  track: async () => notConfigured(),
  sellerMetrics: async () => notConfigured(),
  platformMetrics: async () => notConfigured(),
};

const cms: CmsRepository = {
  homepageModules: async () => notConfigured(),
  collections: async () => notConfigured(),
  getCollection: async () => notConfigured(),
  helpCategories: async () => notConfigured(),
  helpArticles: async () => notConfigured(),
  helpArticle: async () => notConfigured(),
  createTicket: async () => notConfigured(),
  listTickets: async () => notConfigured(),
};

const audit: AuditRepository = {
  list: async () => notConfigured(),
  write: async () => notConfigured(),
};

export const supabaseServices = {
  auth,
  profile,
  catalog,
  categories,
  stores,
  brands,
  cart,
  orders,
  reviews,
  conversations,
  notifications,
  wishlists,
  promotions,
  search,
  inventory,
  shipping,
  payments,
  media,
  moderation,
  returns: returnsRepo,
  disputes,
  offers,
  analytics,
  cms,
  audit,
};
