"use client";

import { useEffect, useState } from "react";
import { mockDb } from "@/mocks/db";
import type { UserProfile } from "@/types";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

export default function AdminUsersPage() {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [q, setQ] = useState("");

  useEffect(() => {
    setUsers([...mockDb.users]);
  }, []);

  const filtered = users.filter(
    (u) =>
      u.email.toLowerCase().includes(q.toLowerCase()) ||
      u.displayName.toLowerCase().includes(q.toLowerCase())
  );

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Users</h1>
      <Input
        className="mt-4 max-w-md"
        placeholder="Search users"
        value={q}
        onChange={(e) => setQ(e.target.value)}
      />
      <div className="mt-6 space-y-2">
        {filtered.map((user) => (
          <div
            key={user.id}
            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4"
          >
            <div>
              <p className="font-semibold">{user.displayName}</p>
              <p className="text-sm text-[var(--muted-foreground)]">{user.email}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              {user.roles.map((role) => (
                <Badge key={role} variant="secondary" className="capitalize">
                  {role.replaceAll("_", " ")}
                </Badge>
              ))}
              <Badge variant="outline" className="capitalize">
                {user.status}
              </Badge>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
