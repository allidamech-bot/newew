"use client";

import { useEffect, useState } from "react";
import { mockDb } from "@/mocks/db";
import type { PlatformSettings } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  useEffect(() => { setSettings({ ...mockDb.platformSettings }); }, []);
  if (!settings) return null;
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Platform settings</h1>
      <div className="mt-6 grid gap-3 md:grid-cols-2">
        {Object.entries(settings).map(([key, value]) => (
          <Card key={key}>
            <CardHeader><CardTitle className="text-base">{key}</CardTitle></CardHeader>
            <CardContent className="text-sm text-[var(--muted-foreground)]">{String(value)}</CardContent>
          </Card>
        ))}
      </div>
      <p className="mt-4 text-xs text-[var(--muted-foreground)]">
        High-risk setting changes should require confirmation and audit logs when the live admin API is connected.
      </p>
    </div>
  );
}
