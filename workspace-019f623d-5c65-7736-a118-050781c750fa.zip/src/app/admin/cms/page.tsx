"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { HomepageModule } from "@/types";
import { Badge } from "@/components/ui/badge";

export default function AdminCmsPage() {
  const [modules, setModules] = useState<HomepageModule[]>([]);
  const [collections, setCollections] = useState<Array<{ slug: string; title: { en: string } }>>([]);
  useEffect(() => {
    void getServices().cms.homepageModules().then(setModules);
    void getServices().cms.collections().then(setCollections);
  }, []);
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">CMS</h1>
      <h2 className="mt-6 font-semibold">Homepage modules</h2>
      <div className="mt-3 space-y-2">
        {modules.map((m) => (
          <div key={m.id} className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <div>
              <p className="font-medium">{m.id}</p>
              <p className="text-sm text-[var(--muted-foreground)]">{m.type}</p>
            </div>
            <Badge variant={m.visible ? "success" : "secondary"}>{m.visible ? "Visible" : "Hidden"}</Badge>
          </div>
        ))}
      </div>
      <h2 className="mt-8 font-semibold">Collections</h2>
      <div className="mt-3 space-y-2">
        {collections.map((c) => (
          <div key={c.slug} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <p className="font-medium">{c.title.en}</p>
            <p className="text-sm text-[var(--muted-foreground)]">/{c.slug}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
