import { notFound } from "next/navigation";
import { getServices } from "@/services";
import { ProductDetailClient } from "@/features/catalog/product-detail-client";
import type { Metadata } from "next";

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const product = await getServices().catalog.getProductBySlug(params.slug);
  if (!product) return { title: "Product" };
  return {
    title: product.title.en,
    description: product.shortDescription.en,
    openGraph: {
      title: product.title.en,
      description: product.shortDescription.en,
      images: product.media[0]?.url ? [product.media[0].url] : [],
    },
  };
}

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const services = getServices();
  const product = await services.catalog.getProductBySlug(params.slug);
  if (!product) notFound();
  const [store, related, reviews, shipping] = await Promise.all([
    services.stores.getById(product.storeId),
    services.catalog.listRelated(product.id, 8),
    services.reviews.listByProduct(product.id),
    services.shipping.listMethods(product.storeId, product.type),
  ]);

  return (
    <ProductDetailClient
      product={product}
      store={store}
      related={related}
      reviews={reviews}
      shipping={shipping}
    />
  );
}
