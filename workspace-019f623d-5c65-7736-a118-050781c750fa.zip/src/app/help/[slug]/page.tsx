import { notFound } from "next/navigation";
import Link from "next/link";
import { getServices } from "@/services";

export default async function HelpArticlePage({ params }: { params: { slug: string } }) {
  const article = await getServices().cms.helpArticle(params.slug);
  if (!article) notFound();
  return (
    <div className="container-sol py-10">
      <Link href="/help" className="text-sm text-[var(--primary)] hover:underline">
        Help Center
      </Link>
      <h1 className="mt-3 text-3xl font-semibold tracking-tight">{article.title.en}</h1>
      <p className="mt-4 max-w-3xl leading-relaxed text-[var(--muted-foreground)]">{article.body.en}</p>
    </div>
  );
}
