import { getServices } from "@/services";
import { DiscoverClient } from "@/features/search/discover-client";

export const metadata = { title: "Discover" };

export default async function DiscoverPage({
  searchParams,
}: {
  searchParams: Record<string, string | string[] | undefined>;
}) {
  const sort = typeof searchParams.sort === "string" ? searchParams.sort : "recommended";
  const type = typeof searchParams.type === "string" ? searchParams.type : undefined;
  const services = getServices();
  const [products, categories, stores] = await Promise.all([
    services.catalog.listProducts({
      sort,
      pageSize: 24,
      filters: type
        ? { productTypes: [type as "digital" | "service" | "physical"] }
        : undefined,
    }),
    services.categories.getTree(),
    services.stores.list({ pageSize: 50 }),
  ]);

  return (
    <DiscoverClient
      initialProducts={products.items}
      total={products.total}
      categories={categories}
      stores={stores.items}
      initialSort={sort}
      initialType={type}
    />
  );
}
