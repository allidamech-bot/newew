import { getServices } from "@/services";
import { SearchClient } from "@/features/search/search-client";

export const metadata = { title: "Search" };

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Record<string, string | string[] | undefined>;
}) {
  const q = typeof searchParams.q === "string" ? searchParams.q : "";
  const sort = typeof searchParams.sort === "string" ? searchParams.sort : "relevance";
  const services = getServices();
  const [result, trending, stores] = await Promise.all([
    services.search.search(q, undefined, sort === "relevance" ? undefined : sort, 1, 48),
    services.search.trending(),
    services.stores.list({ pageSize: 100 }),
  ]);

  return (
    <SearchClient
      query={q}
      result={result}
      trending={trending}
      stores={stores.items}
      sort={sort}
    />
  );
}
