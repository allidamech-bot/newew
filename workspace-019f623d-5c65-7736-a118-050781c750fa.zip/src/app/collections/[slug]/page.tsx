import { notFound } from "next/navigation";
import { getServices } from "@/services";
import { ProductCard } from "@/components/commerce/product-card";

export default async function CollectionPage({ params }: { params: { slug: string } }) {
  const services = getServices();
  const collection = await services.cms.getCollection(params.slug);
  if (!collection) notFound();
  const products = (
    await Promise.all(collection.productIds.map((id) => services.catalog.getProductById(id)))
  ).filter(Boolean);
  const stores = await services.stores.list({ pageSize: 100 });
  const storeMap = new Map(stores.items.map((s) => [s.id, s]));

  return (
    <div className="container-sol py-8">
      <h1 className="text-3xl font-semibold tracking-tight">{collection.title.en}</h1>
      <p className="mt-2 max-w-2xl text-[var(--muted-foreground)]">{collection.description.en}</p>
      <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
        {products.map((p) =>
          p ? <ProductCard key={p.id} product={p} store={storeMap.get(p.storeId)} /> : null
        )}
      </div>
    </div>
  );
}
