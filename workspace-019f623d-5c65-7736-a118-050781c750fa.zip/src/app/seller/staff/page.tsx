"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const roles = [
  { name: "Store administrator", access: "Full store access, staff, and settings" },
  { name: "Catalog manager", access: "Products, media, collections" },
  { name: "Inventory manager", access: "Stock adjustments and warehouses" },
  { name: "Order manager", access: "Orders, fulfillment, returns" },
  { name: "Customer support", access: "Messages and review responses" },
  { name: "Marketing manager", access: "Promotions and announcements" },
  { name: "Analyst", access: "Read-only analytics" },
];

export default function SellerStaffPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Staff & permissions</h1>
      <p className="mt-1 text-sm text-[var(--muted-foreground)]">
        Permission model is implemented in architecture and UI. Invite/membership APIs connect when Supabase auth is enabled.
      </p>
      <div className="mt-6 grid gap-3 md:grid-cols-2">
        {roles.map((role) => (
          <Card key={role.name}>
            <CardHeader><CardTitle className="text-base">{role.name}</CardTitle></CardHeader>
            <CardContent className="text-sm text-[var(--muted-foreground)]">{role.access}</CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
