"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { Promotion } from "@/types";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/feedback/empty-state";

export default function SellerPromotionsPage() {
  const [items, setItems] = useState<Promotion[]>([]);

  useEffect(() => {
    void getServices().promotions.listActive().then(setItems);
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Promotions</h1>
      <p className="mt-1 text-sm text-[var(--muted-foreground)]">Active platform and store promotions.</p>
      <div className="mt-6 space-y-3">
        {items.map((p) => (
          <div key={p.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-semibold">{p.name.en}</p>
                <p className="text-sm text-[var(--muted-foreground)]">
                  {p.type} · code {p.code || "—"} · value {p.value}
                </p>
              </div>
              <Badge variant={p.active ? "success" : "secondary"}>{p.active ? "Active" : "Inactive"}</Badge>
            </div>
          </div>
        ))}
        {!items.length ? <EmptyState title="No active promotions" description="Create coupons and campaigns to drive conversion." /> : null}
      </div>
    </div>
  );
}
