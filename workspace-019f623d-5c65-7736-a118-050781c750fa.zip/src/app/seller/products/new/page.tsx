"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Category, ProductType, Store } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { fromMajor } from "@/lib/money";
import { slugify } from "@/lib/utils";
import { toast } from "sonner";

const steps = [
  "Type",
  "Basics",
  "Category",
  "Media",
  "Variants",
  "Pricing",
  "Inventory",
  "Shipping",
  "SEO",
  "Review",
] as const;

export default function NewProductPage() {
  const user = useAuthStore((s) => s.session?.user);
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [store, setStore] = useState<Store | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    type: "physical" as ProductType,
    titleEn: "",
    titleAr: "",
    descriptionEn: "",
    descriptionAr: "",
    categoryId: "",
    imageUrl: "/images/placeholder-product.svg",
    price: "49",
    quantity: "10",
    sku: "",
    weightGrams: "500",
    requiresShipping: true,
    variantColors: "ink,sand",
    seoTitle: "",
    seoDescription: "",
    offersEnabled: false,
  });

  useEffect(() => {
    if (!user) return;
    (async () => {
      const owned = await getServices().stores.listByOwner(user.id);
      const fallback = owned[0] || (await getServices().stores.list({ pageSize: 1 })).items[0];
      setStore(fallback || null);
      setCategories(await getServices().categories.list());
      if (fallback) {
        setForm((f) => ({ ...f, categoryId: fallback.categories[0] || "" }));
      }
    })();
  }, [user]);

  const combinations = useMemo(() => {
    const colors = form.variantColors
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    return colors;
  }, [form.variantColors]);

  async function save(status: "draft" | "pending_review" | "published") {
    if (!user || !store) return;
    setSaving(true);
    try {
      const title = { en: form.titleEn, ar: form.titleAr || form.titleEn };
      const product = await getServices().catalog.createProduct({
        storeId: store.id,
        sellerId: user.id,
        type: form.type,
        title,
        description: {
          en: form.descriptionEn,
          ar: form.descriptionAr || form.descriptionEn,
        },
        shortDescription: {
          en: form.descriptionEn.slice(0, 120),
          ar: (form.descriptionAr || form.descriptionEn).slice(0, 120),
        },
        categoryId: form.categoryId || categories[0]?.id,
        slug: slugify(form.titleEn || "untitled-product"),
        basePrice: fromMajor(Number(form.price) || 0),
        quantity: Number(form.quantity) || 0,
        status,
        requiresShipping: form.type === "physical" || form.type === "made_to_order",
        media: [
          {
            id: `media-${Date.now()}`,
            bucket: "product-media",
            path: "uploads/cover.svg",
            url: form.imageUrl,
            isCover: true,
            sortOrder: 0,
            moderationStatus: "approved",
          },
        ],
        variantOptions: combinations.length
          ? [{ name: "color", values: combinations }]
          : [],
        variants: combinations.map((color, idx) => ({
          id: `var-new-${idx}`,
          productId: "pending",
          sku: `${form.sku || "SKU"}-${color.toUpperCase()}`,
          title: { en: color, ar: color },
          options: { color },
          price: fromMajor(Number(form.price) || 0),
          quantity: Number(form.quantity) || 0,
          reservedQuantity: 0,
          lowStockThreshold: 3,
          enabled: true,
          mediaIds: [],
        })),
        offersEnabled: form.offersEnabled,
        seoTitle: form.seoTitle
          ? { en: form.seoTitle, ar: form.seoTitle }
          : undefined,
        seoDescription: form.seoDescription
          ? { en: form.seoDescription, ar: form.seoDescription }
          : undefined,
        weightGrams: Number(form.weightGrams) || undefined,
      });
      // fix variant product ids
      if (product.variants.length) {
        await getServices().catalog.updateProduct(product.id, {
          variants: product.variants.map((v) => ({ ...v, productId: product.id })),
        });
      }
      toast.success(status === "draft" ? "Draft saved" : "Product submitted");
      router.push("/seller/products");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not save product");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="text-2xl font-semibold tracking-tight">Product wizard</h1>
      <p className="mt-1 text-sm text-[var(--muted-foreground)]">
        Progressive product creation with autosave-ready draft flow.
      </p>
      <div className="mt-4 flex flex-wrap gap-2">
        {steps.map((label, i) => (
          <button
            key={label}
            type="button"
            onClick={() => setStep(i)}
            className={`rounded-full px-3 py-1 text-xs ${
              i === step
                ? "bg-[var(--primary)] text-[var(--primary-foreground)]"
                : "border border-[var(--border)] text-[var(--muted-foreground)]"
            }`}
          >
            {i + 1}. {label}
          </button>
        ))}
      </div>

      <div className="mt-6 space-y-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-5">
        {step === 0 && (
          <div className="grid gap-2 sm:grid-cols-2">
            {(["physical", "digital", "service", "made_to_order", "preorder"] as ProductType[]).map(
              (type) => (
                <label
                  key={type}
                  className={`cursor-pointer rounded-lg border p-3 capitalize ${
                    form.type === type ? "border-[var(--primary)]" : "border-[var(--border)]"
                  }`}
                >
                  <input
                    type="radio"
                    className="me-2"
                    checked={form.type === type}
                    onChange={() => setForm((f) => ({ ...f, type }))}
                  />
                  {type.replaceAll("_", " ")}
                </label>
              )
            )}
          </div>
        )}
        {step === 1 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>Title (English)</Label>
              <Input
                value={form.titleEn}
                onChange={(e) => setForm((f) => ({ ...f, titleEn: e.target.value }))}
              />
            </div>
            <div className="space-y-1">
              <Label>Title (Arabic)</Label>
              <Input
                value={form.titleAr}
                onChange={(e) => setForm((f) => ({ ...f, titleAr: e.target.value }))}
                dir="rtl"
              />
            </div>
            <div className="space-y-1">
              <Label>Description (English)</Label>
              <Textarea
                value={form.descriptionEn}
                onChange={(e) => setForm((f) => ({ ...f, descriptionEn: e.target.value }))}
              />
            </div>
            <div className="space-y-1">
              <Label>Description (Arabic)</Label>
              <Textarea
                value={form.descriptionAr}
                onChange={(e) => setForm((f) => ({ ...f, descriptionAr: e.target.value }))}
                dir="rtl"
              />
            </div>
          </div>
        )}
        {step === 2 && (
          <div className="space-y-1">
            <Label>Category</Label>
            <select
              className="h-10 w-full rounded-md border border-[var(--border)] bg-[var(--background)] px-3"
              value={form.categoryId}
              onChange={(e) => setForm((f) => ({ ...f, categoryId: e.target.value }))}
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name.en}
                </option>
              ))}
            </select>
          </div>
        )}
        {step === 3 && (
          <div className="space-y-1">
            <Label>Cover image URL / path</Label>
            <Input
              value={form.imageUrl}
              onChange={(e) => setForm((f) => ({ ...f, imageUrl: e.target.value }))}
            />
            <p className="text-xs text-[var(--muted-foreground)]">
              Mock media adapter accepts local paths and data URLs.
            </p>
          </div>
        )}
        {step === 4 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>Color variants (comma separated)</Label>
              <Input
                value={form.variantColors}
                onChange={(e) => setForm((f) => ({ ...f, variantColors: e.target.value }))}
              />
            </div>
            <p className="text-sm text-[var(--muted-foreground)]">
              Generated combinations: {combinations.length || 0}
            </p>
            <ul className="text-sm">
              {combinations.map((c) => (
                <li key={c} className="capitalize">
                  • {c}
                </li>
              ))}
            </ul>
          </div>
        )}
        {step === 5 && (
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label>Price (major units)</Label>
              <Input
                inputMode="decimal"
                value={form.price}
                onChange={(e) => setForm((f) => ({ ...f, price: e.target.value }))}
              />
            </div>
            <div className="space-y-1">
              <Label>SKU prefix</Label>
              <Input value={form.sku} onChange={(e) => setForm((f) => ({ ...f, sku: e.target.value }))} />
            </div>
            <label className="flex items-center gap-2 text-sm sm:col-span-2">
              <input
                type="checkbox"
                checked={form.offersEnabled}
                onChange={(e) => setForm((f) => ({ ...f, offersEnabled: e.target.checked }))}
              />
              Enable offers
            </label>
          </div>
        )}
        {step === 6 && (
          <div className="space-y-1">
            <Label>Quantity</Label>
            <Input
              inputMode="numeric"
              value={form.quantity}
              onChange={(e) => setForm((f) => ({ ...f, quantity: e.target.value }))}
            />
          </div>
        )}
        {step === 7 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>Weight (grams)</Label>
              <Input
                value={form.weightGrams}
                onChange={(e) => setForm((f) => ({ ...f, weightGrams: e.target.value }))}
              />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="checkbox"
                checked={form.requiresShipping}
                onChange={(e) => setForm((f) => ({ ...f, requiresShipping: e.target.checked }))}
              />
              Requires shipping
            </label>
          </div>
        )}
        {step === 8 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>SEO title</Label>
              <Input
                value={form.seoTitle}
                onChange={(e) => setForm((f) => ({ ...f, seoTitle: e.target.value }))}
              />
            </div>
            <div className="space-y-1">
              <Label>SEO description</Label>
              <Textarea
                value={form.seoDescription}
                onChange={(e) => setForm((f) => ({ ...f, seoDescription: e.target.value }))}
              />
            </div>
          </div>
        )}
        {step === 9 && (
          <div className="space-y-2 text-sm">
            <p>
              <strong>Type:</strong> {form.type}
            </p>
            <p>
              <strong>Title:</strong> {form.titleEn || "—"}
            </p>
            <p>
              <strong>Store:</strong> {store?.name || "—"}
            </p>
            <p>
              <strong>Price:</strong> ${form.price}
            </p>
            <p>
              <strong>Variants:</strong> {combinations.join(", ") || "None"}
            </p>
            <p>
              <strong>Qty:</strong> {form.quantity}
            </p>
          </div>
        )}

        <div className="flex flex-wrap justify-between gap-2 pt-2">
          <Button variant="outline" disabled={step === 0} onClick={() => setStep((s) => s - 1)}>
            Back
          </Button>
          <div className="flex flex-wrap gap-2">
            <Button variant="secondary" disabled={saving} onClick={() => void save("draft")}>
              Save draft
            </Button>
            {step < steps.length - 1 ? (
              <Button onClick={() => setStep((s) => s + 1)}>Continue</Button>
            ) : (
              <Button disabled={saving || !form.titleEn} onClick={() => void save("pending_review")}>
                {saving ? "Saving…" : "Submit for review"}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
