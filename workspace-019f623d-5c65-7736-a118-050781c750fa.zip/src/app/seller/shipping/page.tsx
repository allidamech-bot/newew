"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { ShippingMethod } from "@/types";
import { formatMoney } from "@/lib/money";

export default function SellerShippingPage() {
  const [methods, setMethods] = useState<ShippingMethod[]>([]);

  useEffect(() => {
    void getServices().shipping.listMethods().then(setMethods);
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Shipping</h1>
      <p className="mt-1 text-sm text-[var(--muted-foreground)]">Configured shipping methods via ShippingProvider abstraction.</p>
      <div className="mt-6 space-y-3">
        {methods.map((m) => (
          <div key={m.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <p className="font-semibold">{m.name.en}</p>
            <p className="mt-1 text-sm text-[var(--muted-foreground)]">{m.description.en}</p>
            <p className="mt-2 text-sm">
              {formatMoney(m.price)} · {m.minDays}–{m.maxDays} days · {m.enabled ? "Enabled" : "Disabled"}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
