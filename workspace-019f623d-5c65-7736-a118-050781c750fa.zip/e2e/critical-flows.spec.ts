import { test, expect } from "@playwright/test";

async function signIn(page: import("@playwright/test").Page, email: string) {
  await page.goto("/auth/sign-in");
  await page.locator("#email").fill(email);
  await page.locator("#password").fill("demo1234");
  await page.getByRole("button", { name: /^sign in$/i }).click();
  await page.waitForTimeout(700);
}

test.describe("NEXORA critical matrix", () => {
  test("guest discover/filter/product/cart", async ({ page }) => {
    await page.goto("/discover");
    await expect(page.getByRole("heading", { name: /discover/i })).toBeVisible();
    await page.locator("a[href^='/product/']").first().click();
    await page.getByRole("button", { name: /add to cart/i }).first().click();
    await page.goto("/cart");
    await expect(page.getByRole("heading", { name: /cart/i })).toBeVisible();
  });

  test("buyer auth + account + checkout path", async ({ page }) => {
    await signIn(page, "buyer@nexora.demo");
    await page.goto("/account");
    await expect(page.getByRole("heading", { name: /account overview/i })).toBeVisible({
      timeout: 15000,
    });
    await page.goto("/discover");
    await page.locator("a[href^='/product/']").first().click();
    await page.getByRole("button", { name: /add to cart/i }).first().click();
    await page.goto("/checkout");
    await expect(page.locator("body")).toContainText(/checkout|order|address|payment|sign in|cart/i, {
      timeout: 15000,
    });
  });

  test("seller dashboard + product wizard + promotions", async ({ page }) => {
    await signIn(page, "seller@nexora.demo");
    await page.goto("/seller");
    await expect(page.getByRole("heading", { name: /seller dashboard/i })).toBeVisible({
      timeout: 15000,
    });
    await page.goto("/seller/products/new");
    await expect(page.getByRole("heading", { name: /product wizard/i })).toBeVisible({
      timeout: 15000,
    });
    await expect(page.getByText(/quality score/i)).toBeVisible();
    await page.goto("/seller/promotions");
    await expect(page.getByRole("heading", { name: /promotions/i })).toBeVisible({
      timeout: 15000,
    });
  });

  test("admin applications + cms + settings", async ({ page }) => {
    await signIn(page, "admin@nexora.demo");
    await page.goto("/admin/applications");
    await expect(page.getByRole("heading", { name: /seller applications/i })).toBeVisible({
      timeout: 15000,
    });
    await page.goto("/admin/cms");
    await expect(page.getByRole("heading", { name: /cms/i })).toBeVisible({ timeout: 15000 });
    await page.goto("/admin/settings");
    await expect(page.getByRole("heading", { name: /platform settings/i })).toBeVisible({
      timeout: 15000,
    });
  });

  test("arabic SSR dir=rtl after locale cookie", async ({ page }) => {
    await page.context().addCookies([
      {
        name: "nexora-locale",
        value: "ar",
        url: "http://127.0.0.1:3000",
      },
    ]);
    await page.goto("/");
    await expect(page.locator("html")).toHaveAttribute("lang", "ar");
    await expect(page.locator("html")).toHaveAttribute("dir", "rtl");
  });

  test("mobile viewport checkout shell", async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 812 });
    await signIn(page, "buyer@nexora.demo");
    await page.goto("/cart");
    await expect(page.getByRole("heading", { name: /cart/i })).toBeVisible({ timeout: 15000 });
    await page.goto("/checkout");
    await expect(page.locator("body")).toContainText(/checkout|cart|sign in|address|payment/i, {
      timeout: 15000,
    });
  });

  test("responsive shell at 320 and 1920", async ({ page }) => {
    for (const width of [320, 768, 1280, 1920]) {
      await page.setViewportSize({ width, height: 900 });
      await page.goto("/discover");
      await expect(page.getByRole("heading", { name: /discover/i })).toBeVisible();
      const overflowPx = await page.evaluate(() => {
        return document.documentElement.scrollWidth - document.documentElement.clientWidth;
      });
      // allow tiny sub-pixel/scrollbar variance on very narrow viewports
      expect(overflowPx).toBeLessThan(120);
    }
  });
});
