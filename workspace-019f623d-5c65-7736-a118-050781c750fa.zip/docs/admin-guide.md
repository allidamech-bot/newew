# Admin guide

Sign in as `admin@nexora.demo` / `demo1234` and open `/admin`.

Capabilities in mock mode:
- Platform metrics overview
- User list
- Seller applications review
- Product moderation
- Category/attribute management
- Orders, disputes, reports, reviews
- CMS homepage modules
- Feature flags
- Settings + audit logs
