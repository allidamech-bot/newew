# Authorization

## Roles
guest, buyer, seller, store_staff, moderator, admin, super_admin

## Frontend
- Account shell requires authentication
- Seller shell requires seller/store_staff/admin roles (onboarding allows buyer)
- Admin shell requires moderator/admin/super_admin

## Backend helpers (SQL)
- `has_platform_role(role_name)`
- `is_admin()`
- `owns_store(store_id)`
- `has_store_permission(store_id, permission_key)`
- `can_access_order(order_id)`
- `can_access_conversation(conversation_id)`

Frontend checks are convenience only. RLS is authoritative after Supabase connection.
