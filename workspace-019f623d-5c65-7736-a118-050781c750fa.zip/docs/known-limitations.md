# Known limitations

## Not production-complete without additional work
- Supabase adapters are stubs (interfaces ready; SDK methods not fully implemented).
- No live payment processor, payout rails, or tax engine.
- Search is in-memory mock, not typo-tolerant search infrastructure.
- Realtime messaging/notifications are polled/static mock, not websocket/realtime.
- Image upload uses mock media adapter; no virus scanning/MIME deep validation pipeline.
- Some seller/admin screens are operational but not every advanced bulk/CSV workflow.
- Playwright coverage is critical-path smoke, not full 15-scenario enterprise suite in CI by default.
- Arabic font uses robust local/system stack (no network Google Fonts during build).
- Social auth / 2FA are architecture placeholders.

## Mock mode security
Mock authentication and in-memory data are for local demos only.

## Honest readiness statement
The repository is a substantial, runnable multi-role marketplace foundation with backend-ready schema and policies. It is **not** claimed as fully production-ready for real money movement until Supabase adapters, payment providers, and operational hardening are completed.
