# Testing

## Unit / component / integration
```bash
npm run test
```

Covers money math, auth demos, promotions, cart/order creation, and key UI components.

## E2E
```bash
npm run build
npx playwright install chromium
npm run test:e2e
```

Critical journeys include guest discovery, auth, protected routes, locale direction, and static IA routes.
