# Mock data

Seed source: `src/mocks/seed.ts`
Runtime DB: `src/mocks/db.ts`

Includes:
- 6+ stores
- hierarchical categories and rich attributes
- 50+ products (variants, digital, services, deals, low stock, OOS)
- orders in multiple statuses
- conversations, notifications, reviews, promotions
- demo accounts for all major roles

Reset between tests via `resetMockDb()`.
