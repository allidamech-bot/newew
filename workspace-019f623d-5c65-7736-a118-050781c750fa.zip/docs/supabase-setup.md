# Supabase setup

## Steps
1. Create a Supabase project.
2. Copy `.env.example` values into `.env.local`.
3. Apply migrations in order from `supabase/migrations`.
4. Create storage buckets listed in `00009_functions_and_storage.sql`.
5. Enable Email auth (and optional Google/Apple later).
6. Configure auth redirect URLs for local and production app URLs.
7. Implement repository methods in `src/adapters/supabase` with `@supabase/supabase-js`.
8. Set `NEXT_PUBLIC_DATA_PROVIDER=supabase`.

## Migrations order
1. extensions/helpers
2. identity/access
3. sellers/stores
4. catalog
5. inventory/cart/orders
6. shipping/returns/reviews/messaging
7. support/moderation/cms/analytics
8. RLS policies
9. functions/storage notes

## Notes
- Mock mode remains available if credentials are missing.
- Do not expose service role keys to the browser.
