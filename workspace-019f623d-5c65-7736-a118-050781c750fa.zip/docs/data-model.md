# Data model

See `supabase/migrations` for the normalized PostgreSQL schema.

Major domains:
- Identity & access (`profiles`, `roles`, `permissions`, `addresses`)
- Sellers & stores
- Catalog (categories, attributes, products, variants, media)
- Inventory & warehouses
- Carts, wishlists, saved searches
- Promotions & coupons
- Orders, payments, commissions
- Shipping, returns, disputes
- Reviews, messaging, offers, notifications
- Support, moderation, CMS, analytics, audit

Financial amounts are stored as integer minor units.
