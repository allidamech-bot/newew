# Environment

See `.env.example`.

Runtime validation lives in `src/lib/env.ts`.

Mock mode must not require Supabase variables.
