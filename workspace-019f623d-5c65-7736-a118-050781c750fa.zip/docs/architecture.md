# Architecture

NEXORA uses a modular domain-driven frontend architecture.

## Layers
- **Presentation**: `src/app`, `src/components`, feature UI modules
- **Application services**: `src/services` locator
- **Repositories/interfaces**: `src/repositories`
- **Adapters**: `src/adapters/mock`, `src/adapters/supabase`
- **Domain types**: `src/types`
- **Validation / money / errors**: `src/lib`, `src/validation`
- **Config**: brand, platform, navigation, feature flags

## Data provider switch
`getServices()` selects mock or Supabase adapters based on `NEXT_PUBLIC_DATA_PROVIDER`.

Pages and components must not import Supabase SDK calls directly.

## State
- Server/async data: TanStack Query where used; many routes currently call repositories in client effects or server components.
- URL state: search/discover filters and sort.
- Zustand: auth session, guest cart cache, compare tray, recently viewed, locale.

## Money
All financial values use integer minor units (`amount` cents) via `src/lib/money.ts`.

## AuthZ
Frontend route shells enforce role gates. Database RLS policies are defined for backend enforcement when Supabase is connected.
