# Seller guide

Sign in as `seller@nexora.demo` / `demo1234` and open `/seller`.

Capabilities:
- Dashboard metrics
- Product list + multi-step product wizard
- Inventory adjustments
- Order fulfillment status updates
- Returns, messages, reviews
- Promotions view, analytics, shipping methods
- Store profile customization
- Onboarding flow at `/seller/onboarding`
