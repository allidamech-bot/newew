# Product overview

NEXORA is a multi-vendor marketplace supporting:

- Physical, digital, service, made-to-order, and preorder product types
- Multi-store carts and order groups
- Seller onboarding, catalog, inventory, fulfillment
- Buyer accounts, wishlists, messaging, returns, disputes
- Admin moderation, CMS modules, feature flags, audit logs
- English + Arabic with RTL support

Temporary brand identity is centralized and replaceable.
