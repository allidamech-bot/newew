# Security

## Trust boundaries
- Browser client is untrusted for totals, roles, and inventory.
- Mock mode is development-only and not a security boundary.
- Supabase RLS + service-layer checks are required before production traffic.

## Sensitive data
- Seller identity documents: private bucket + restricted RLS
- Payment card data: never stored locally; provider tokens only
- Private profile fields: `profile_private`
- Dispute evidence and message attachments: private storage

## Controls
- Input validation with Zod-ready patterns
- No secrets in client bundles
- Idempotency keys for checkout/payment
- Audit logs for moderation and high-risk admin actions
- Account/store suspension fields in schema

## Payment boundary
Mock payment provider confirms intents only. Real processors must be connected through `PaymentProvider`.
