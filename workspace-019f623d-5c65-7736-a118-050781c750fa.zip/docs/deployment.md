# Deployment

## Recommended
1. `npm run test:all`
2. Deploy to Vercel/Node host with env vars
3. Keep `NEXT_PUBLIC_DATA_PROVIDER=mock` until Supabase is fully wired
4. Configure production `NEXT_PUBLIC_APP_URL`

## Production checklist
- Secrets only on server
- Supabase RLS applied
- Storage policies applied
- Payment provider live keys in server env
- Monitoring/error tracking provider connected
