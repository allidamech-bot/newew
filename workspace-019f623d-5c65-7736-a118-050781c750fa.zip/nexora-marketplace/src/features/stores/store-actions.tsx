"use client";

import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import { toast } from "sonner";
import { useState } from "react";

export function StoreActions({ storeId, ownerId }: { storeId: string; ownerId: string }) {
  const user = useAuthStore((s) => s.session?.user);
  const router = useRouter();
  const [following, setFollowing] = useState(false);

  return (
    <div className="flex gap-2">
      <Button
        variant={following ? "secondary" : "default"}
        onClick={async () => {
          if (!user) {
            router.push("/auth/sign-in");
            return;
          }
          if (following) {
            await getServices().stores.unfollow(user.id, storeId);
            setFollowing(false);
            toast.message("Unfollowed");
          } else {
            await getServices().stores.follow(user.id, storeId);
            setFollowing(true);
            toast.success("Following store");
          }
        }}
      >
        {following ? "Following" : "Follow"}
      </Button>
      <Button
        variant="outline"
        onClick={async () => {
          if (!user) {
            router.push("/auth/sign-in");
            return;
          }
          const { conversation } = await getServices().conversations.sendMessage({
            senderId: user.id,
            recipientId: ownerId,
            body: "Hello! I have a question about your store.",
            storeId,
            type: "general",
          });
          router.push(`/account/messages/${conversation.id}`);
        }}
      >
        Message
      </Button>
    </div>
  );
}
