"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { platform } from "@/config/platform";

type RVState = {
  ids: string[];
  add: (id: string) => void;
};

export const useRecentlyViewedStore = create<RVState>()(
  persist(
    (set, get) => ({
      ids: [],
      add: (id) => {
        const next = [id, ...get().ids.filter((x) => x !== id)].slice(0, 18);
        set({ ids: next });
      },
    }),
    { name: platform.recentlyViewedKey }
  )
);
