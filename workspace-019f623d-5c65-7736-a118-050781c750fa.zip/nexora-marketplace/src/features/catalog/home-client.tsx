"use client";

import Link from "next/link";
import Image from "next/image";
import {
  ArrowRight,
  BadgeCheck,
  Leaf,
  Package,
  ShieldCheck,
  Sparkles,
  Store,
  Truck,
  Zap,
} from "lucide-react";
import type { Category, HomepageModule, Product, Store as StoreType } from "@/types";
import { localize, useLocaleStore } from "@/i18n";
import { ProductRail } from "@/components/discovery/product-rail";
import { Button } from "@/components/ui/button";
import { useRecentlyViewedStore } from "@/features/catalog/recently-viewed";
import { useMemo } from "react";

type Collection = {
  id: string;
  slug: string;
  title: { en: string; ar: string };
  description: { en: string; ar: string };
  productIds: string[];
  imageUrl?: string;
};

export function HomeClient({
  brandName,
  modules,
  trending,
  deals,
  recommended,
  digital,
  servicesProducts,
  fast,
  stores,
  categories,
  collections,
}: {
  brandName: string;
  modules: HomepageModule[];
  trending: Product[];
  deals: Product[];
  recommended: Product[];
  digital: Product[];
  servicesProducts: Product[];
  fast: Product[];
  stores: StoreType[];
  categories: Array<Category & { children: Category[] }>;
  collections: Collection[];
}) {
  const t = useLocaleStore((s) => s.t);
  const locale = useLocaleStore((s) => s.locale);
  const recentIds = useRecentlyViewedStore((s) => s.ids);
  const allProducts = useMemo(
    () => [...recommended, ...trending, ...deals, ...digital, ...servicesProducts, ...fast],
    [recommended, trending, deals, digital, servicesProducts, fast]
  );
  const recentProducts = recentIds
    .map((id) => allProducts.find((p) => p.id === id))
    .filter(Boolean) as Product[];

  const editorial = modules.find((m) => m.type === "editorial");

  return (
    <div>
      {/* Intelligent search stage + editorial */}
      <section className="border-b border-[var(--border)] bg-[var(--card)]">
        <div className="container-sol grid gap-8 py-8 md:grid-cols-[1.1fr_0.9fr] md:py-12 lg:gap-12">
          <div className="flex flex-col justify-center">
            <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[var(--primary)]">
              {brandName}
            </p>
            <h1 className="mt-3 max-w-xl text-3xl font-semibold tracking-tight md:text-5xl md:leading-[1.1]">
              {editorial && editorial.type === "editorial"
                ? localize(editorial.title, locale)
                : t("brand.tagline")}
            </h1>
            <p className="mt-4 max-w-lg text-base text-[var(--muted-foreground)] md:text-lg">
              {editorial && editorial.type === "editorial" && editorial.subtitle
                ? localize(editorial.subtitle, locale)
                : t("home.searchHint")}
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              {["linen lamp", "travel pack", "ui kit", "serum", "brand strategy"].map((chip) => (
                <Link
                  key={chip}
                  href={`/search?q=${encodeURIComponent(chip)}`}
                  className="rounded-full border border-[var(--border)] bg-[var(--background)] px-3 py-1.5 text-sm text-[var(--muted-foreground)] transition hover:border-[var(--primary)] hover:text-[var(--foreground)]"
                >
                  {chip}
                </Link>
              ))}
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link href="/discover">
                  {t("nav.discover")} <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link href="/sell">{t("nav.sellOnSol")}</Link>
              </Button>
            </div>
          </div>
          <div className="relative min-h-[280px] overflow-hidden rounded-2xl border border-[var(--border)] md:min-h-[360px]">
            <Image
              src={
                (editorial && editorial.type === "editorial" && editorial.imageUrl) ||
                "/images/editorial-spring.svg"
              }
              alt=""
              fill
              className="object-cover"
              priority
              unoptimized
            />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/55 to-transparent p-5 text-white">
              <p className="text-sm font-medium">
                {editorial && editorial.type === "editorial" && editorial.cta
                  ? localize(editorial.cta.label, locale)
                  : t("home.editorialCta")}
              </p>
              <Link
                href={
                  (editorial && editorial.type === "editorial" && editorial.cta?.href) ||
                  "/collections/spring-focus"
                }
                className="mt-1 inline-flex items-center gap-1 text-sm underline-offset-4 hover:underline"
              >
                {t("common.viewAll")} <ArrowRight className="h-3.5 w-3.5 rtl:rotate-180" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Category universe */}
      <section className="section-pad">
        <div className="container-sol">
          <h2 className="mb-5 text-xl font-semibold tracking-tight md:text-2xl">
            {t("home.categoryUniverse")}
          </h2>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {categories.map((cat) => (
              <Link
                key={cat.id}
                href={`/categories/${cat.slug}`}
                className="group relative overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--card)]"
              >
                <div className="relative aspect-[5/3]">
                  <Image
                    src={cat.imageUrl || `/images/cat-home.svg`}
                    alt=""
                    fill
                    className="object-cover transition duration-300 group-hover:scale-[1.03]"
                    unoptimized
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-3 text-white">
                    <p className="font-semibold">{localize(cat.name, locale)}</p>
                    <p className="text-xs text-white/80">
                      {cat.children.length} {locale === "ar" ? "فئات فرعية" : "subcategories"}
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <ProductRail
        title={t("home.pickedForYou")}
        products={recommended}
        stores={stores}
        href="/discover?sort=rating"
      />
      <ProductRail
        title={t("home.trending")}
        products={trending}
        stores={stores}
        href="/discover?sort=best_selling"
      />

      {/* Curated collections */}
      <section className="section-pad">
        <div className="container-sol">
          <h2 className="mb-5 text-xl font-semibold tracking-tight md:text-2xl">
            {t("home.curated")}
          </h2>
          <div className="grid gap-4 md:grid-cols-2">
            {collections.map((col) => (
              <Link
                key={col.id}
                href={`/collections/${col.slug}`}
                className="group relative min-h-[220px] overflow-hidden rounded-2xl border border-[var(--border)]"
              >
                <Image
                  src={col.imageUrl || "/images/editorial-spring.svg"}
                  alt=""
                  fill
                  className="object-cover transition duration-300 group-hover:scale-[1.02]"
                  unoptimized
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black/65 via-black/35 to-transparent p-6 text-white">
                  <h3 className="text-2xl font-semibold">{localize(col.title, locale)}</h3>
                  <p className="mt-2 max-w-sm text-sm text-white/85">
                    {localize(col.description, locale)}
                  </p>
                  <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium">
                    {t("common.explore" as never) === "common.explore"
                      ? t("common.viewAll")
                      : t("common.viewAll")}
                    <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Verified stores */}
      <section className="section-pad bg-[var(--muted)]/25">
        <div className="container-sol">
          <div className="mb-5 flex items-end justify-between">
            <h2 className="text-xl font-semibold tracking-tight md:text-2xl">
              {t("home.verifiedStores")}
            </h2>
            <Link href="/stores" className="text-sm font-medium text-[var(--primary)] hover:underline">
              {t("common.viewAll")}
            </Link>
          </div>
          <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 md:mx-0 md:grid md:grid-cols-3 md:overflow-visible md:px-0 lg:grid-cols-6">
            {stores.map((store) => (
              <Link
                key={store.id}
                href={`/stores/${store.slug}`}
                className="w-[70%] shrink-0 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 md:w-auto"
              >
                <div className="relative mb-3 h-12 w-12 overflow-hidden rounded-full bg-[var(--muted)]">
                  <Image src={store.logoUrl || "/images/placeholder-product.svg"} alt="" fill unoptimized />
                </div>
                <div className="flex items-center gap-1">
                  <p className="truncate text-sm font-semibold">{store.name}</p>
                  {store.verificationStatus === "verified" ? (
                    <BadgeCheck className="h-4 w-4 shrink-0 text-[var(--primary)]" />
                  ) : null}
                </div>
                <p className="mt-1 line-clamp-2 text-xs text-[var(--muted-foreground)]">
                  {localize(store.description, locale)}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <ProductRail
        title={t("home.timeSensitive")}
        products={deals}
        stores={stores}
        href="/deals"
      />

      {/* Intent grid */}
      <section className="section-pad">
        <div className="container-sol">
          <h2 className="mb-5 text-xl font-semibold tracking-tight md:text-2xl">
            {t("home.discoveryByIntent")}
          </h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4 lg:grid-cols-7">
            {[
              { href: "/discover?sort=price_asc", label: t("home.bestValue"), icon: Sparkles },
              { href: "/discover?sort=rating", label: t("home.premium"), icon: BadgeCheck },
              { href: "/search?q=organic", label: t("home.sustainable"), icon: Leaf },
              { href: "/stores", label: t("home.local"), icon: Store },
              { href: "/discover?sort=newest", label: t("home.fastDelivery"), icon: Truck },
              { href: "/discover?type=digital", label: t("home.digital"), icon: Package },
              { href: "/discover?type=service", label: t("home.services"), icon: Zap },
            ].map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex flex-col items-start gap-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 transition hover:border-[var(--primary)] hover:shadow-sm"
              >
                <item.icon className="h-5 w-5 text-[var(--primary)]" />
                <span className="text-sm font-medium leading-snug">{item.label}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <ProductRail title={t("home.digital")} products={digital} stores={stores} href="/discover?type=digital" />
      <ProductRail title={t("home.services")} products={servicesProducts} stores={stores} href="/discover?type=service" />
      <ProductRail title={t("home.fastDelivery")} products={fast} stores={stores} href="/discover" />

      {recentProducts.length ? (
        <ProductRail title={t("home.recentlyViewed")} products={recentProducts} stores={stores} />
      ) : null}

      {/* Trust */}
      <section className="section-pad">
        <div className="container-sol">
          <h2 className="mb-5 text-xl font-semibold tracking-tight md:text-2xl">
            {t("home.trustTitle")}
          </h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: ShieldCheck, title: t("home.trustSecure") },
              { icon: BadgeCheck, title: t("home.trustVerified") },
              { icon: Package, title: t("home.trustSupport") },
              { icon: Truck, title: t("home.trustReturns") },
            ].map((item) => (
              <div
                key={item.title}
                className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-5"
              >
                <item.icon className="h-5 w-5 text-[var(--primary)]" />
                <p className="mt-3 font-medium">{item.title}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Seller CTA */}
      <section className="section-pad">
        <div className="container-sol">
          <div className="overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--primary)] px-6 py-10 text-[var(--primary-foreground)] md:px-10">
            <div className="max-w-2xl">
              <h2 className="text-2xl font-semibold tracking-tight md:text-3xl">
                {t("home.sellerCtaTitle")}
              </h2>
              <p className="mt-3 text-[var(--primary-foreground)]/85">
                {t("home.sellerCtaSubtitle")}
              </p>
              <Button asChild size="lg" variant="secondary" className="mt-6">
                <Link href="/seller/onboarding">{t("home.sellerCtaButton")}</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
