"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  BadgeCheck,
  GitCompareArrows,
  Heart,
  MessageCircle,
  Share2,
  ShieldCheck,
  Truck,
} from "lucide-react";
import type { Product, Review, ShippingMethod, Store } from "@/types";
import { PriceDisplay } from "@/components/commerce/price-display";
import { RatingDisplay } from "@/components/commerce/rating-display";
import { ProductRail } from "@/components/discovery/product-rail";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { localize, useLocaleStore } from "@/i18n";
import { useCartStore } from "@/features/cart/store";
import { useCompareStore } from "@/features/compare/store";
import { useRecentlyViewedStore } from "@/features/catalog/recently-viewed";
import { useAuthStore } from "@/features/auth/store";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { getServices } from "@/services";
import { formatMoney } from "@/lib/money";

export function ProductDetailClient({
  product,
  store,
  related,
  reviews,
  shipping,
}: {
  product: Product;
  store: Store | null;
  related: Product[];
  reviews: Review[];
  shipping: ShippingMethod[];
}) {
  const t = useLocaleStore((s) => s.t);
  const locale = useLocaleStore((s) => s.locale);
  const addItem = useCartStore((s) => s.addItem);
  const compare = useCompareStore();
  const addRecent = useRecentlyViewedStore((s) => s.add);
  const user = useAuthStore((s) => s.session?.user);
  const router = useRouter();
  const [qty, setQty] = useState(1);
  const [selected, setSelected] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    product.variantOptions.forEach((opt) => {
      init[opt.name] = opt.values[0];
    });
    return init;
  });
  const [activeImage, setActiveImage] = useState(0);

  useEffect(() => {
    addRecent(product.id);
  }, [product.id, addRecent]);

  const activeVariant = useMemo(() => {
    if (!product.variants.length) return undefined;
    return product.variants.find((v) =>
      Object.entries(selected).every(([k, val]) => v.options[k] === val)
    );
  }, [product.variants, selected]);

  const price = activeVariant?.price || product.basePrice;
  const compareAt = activeVariant?.compareAtPrice || product.compareAtPrice;
  const available = activeVariant
    ? activeVariant.quantity - activeVariant.reservedQuantity
    : product.quantity - product.reservedQuantity;
  const isOos = available <= 0 || product.status === "out_of_stock";
  const ship = shipping[0];

  return (
    <div className="pb-24 md:pb-0">
      <div className="container-sol py-6 md:py-10">
        <div className="grid gap-8 lg:grid-cols-2">
          <div>
            <div className="relative aspect-[4/5] overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--muted)]">
              <Image
                src={product.media[activeImage]?.url || product.media[0]?.url || "/images/placeholder-product.svg"}
                alt={localize(product.title, locale)}
                fill
                className="object-cover"
                priority
                unoptimized
              />
            </div>
            {product.media.length > 1 ? (
              <div className="mt-3 flex gap-2 overflow-x-auto">
                {product.media.map((m, i) => (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setActiveImage(i)}
                    className={`relative h-16 w-16 shrink-0 overflow-hidden rounded-lg border ${
                      i === activeImage ? "border-[var(--primary)]" : "border-[var(--border)]"
                    }`}
                  >
                    <Image src={m.url} alt="" fill className="object-cover" unoptimized />
                  </button>
                ))}
              </div>
            ) : null}
          </div>

          <div>
            {store ? (
              <Link
                href={`/stores/${store.slug}`}
                className="inline-flex items-center gap-1 text-sm text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
              >
                {store.name}
                {store.verificationStatus === "verified" ? (
                  <BadgeCheck className="h-4 w-4 text-[var(--primary)]" />
                ) : null}
              </Link>
            ) : null}
            <h1 className="mt-2 text-2xl font-semibold tracking-tight md:text-4xl">
              {localize(product.title, locale)}
            </h1>
            <div className="mt-3 flex flex-wrap items-center gap-3">
              <RatingDisplay rating={product.rating} count={product.reviewCount} size="md" />
              <Badge variant="outline">{product.type.replaceAll("_", " ")}</Badge>
              {isOos ? (
                <Badge variant="secondary">{t("common.outOfStock")}</Badge>
              ) : available <= product.lowStockThreshold ? (
                <Badge variant="warning">{t("common.lowStock")}</Badge>
              ) : (
                <Badge variant="success">{t("common.inStock")}</Badge>
              )}
            </div>
            <PriceDisplay price={price} compareAt={compareAt} size="lg" className="mt-5" />
            <p className="mt-4 text-[var(--muted-foreground)]">
              {localize(product.shortDescription, locale)}
            </p>

            {product.variantOptions.map((opt) => (
              <div key={opt.name} className="mt-5">
                <p className="mb-2 text-sm font-medium capitalize">
                  {opt.name}: <span className="text-[var(--muted-foreground)]">{selected[opt.name]}</span>
                </p>
                <div className="flex flex-wrap gap-2">
                  {opt.values.map((val) => (
                    <button
                      key={val}
                      type="button"
                      onClick={() => setSelected((s) => ({ ...s, [opt.name]: val }))}
                      className={`rounded-full border px-3 py-1.5 text-sm capitalize ${
                        selected[opt.name] === val
                          ? "border-[var(--primary)] bg-[var(--primary)] text-[var(--primary-foreground)]"
                          : "border-[var(--border)] hover:border-[var(--primary)]"
                      }`}
                    >
                      {val}
                    </button>
                  ))}
                </div>
              </div>
            ))}

            <div className="mt-6 flex items-center gap-3">
              <label className="text-sm font-medium">{t("product.quantity")}</label>
              <div className="inline-flex items-center rounded-md border border-[var(--border)]">
                <button
                  type="button"
                  className="h-10 w-10"
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  aria-label="Decrease quantity"
                >
                  −
                </button>
                <span className="w-10 text-center text-sm">{qty}</span>
                <button
                  type="button"
                  className="h-10 w-10"
                  onClick={() => setQty((q) => Math.min(available || 1, q + 1))}
                  aria-label="Increase quantity"
                >
                  +
                </button>
              </div>
              {!isOos ? (
                <span className="text-xs text-[var(--muted-foreground)]">
                  {t("product.inStockCount", { count: available })}
                </span>
              ) : null}
            </div>

            <div className="mt-6 hidden gap-3 md:flex">
              <Button
                size="lg"
                className="flex-1"
                disabled={isOos}
                onClick={async () => {
                  try {
                    await addItem(product.id, qty, activeVariant?.id);
                    toast.success("Added to cart");
                  } catch (e) {
                    toast.error(e instanceof Error ? e.message : "Failed");
                  }
                }}
              >
                {t("product.addToCart")}
              </Button>
              <Button
                size="lg"
                variant="secondary"
                className="flex-1"
                disabled={isOos}
                onClick={async () => {
                  try {
                    await addItem(product.id, qty, activeVariant?.id);
                    router.push("/checkout");
                  } catch (e) {
                    toast.error(e instanceof Error ? e.message : "Failed");
                  }
                }}
              >
                {t("product.buyNow")}
              </Button>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  if (compare.has(product.id)) compare.remove(product.id);
                  else compare.add(product.id);
                  toast.success("Compare list updated");
                }}
              >
                <GitCompareArrows className="h-4 w-4" /> {t("product.compareProduct")}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  if (!user) {
                    router.push("/auth/sign-in");
                    return;
                  }
                  await getServices().wishlists.addItem(user.id, product.id, activeVariant?.id);
                  toast.success("Saved");
                }}
              >
                <Heart className="h-4 w-4" /> {t("product.saveProduct")}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  if (!user || !store) {
                    router.push("/auth/sign-in");
                    return;
                  }
                  const { conversation } = await getServices().conversations.sendMessage({
                    senderId: user.id,
                    recipientId: store.ownerId,
                    body: `Hi, I have a question about ${product.title.en}.`,
                    productId: product.id,
                    storeId: store.id,
                    type: "product_inquiry",
                  });
                  router.push(`/account/messages/${conversation.id}`);
                }}
              >
                <MessageCircle className="h-4 w-4" /> {t("product.messageSeller")}
              </Button>
              {product.offersEnabled ? (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => toast.message("Open offer flow from account after sign-in")}
                >
                  {t("product.makeOffer")}
                </Button>
              ) : null}
              <Button
                variant="ghost"
                size="sm"
                onClick={async () => {
                  await navigator.clipboard.writeText(window.location.href);
                  toast.success("Link copied");
                }}
              >
                <Share2 className="h-4 w-4" /> {t("product.shareProduct")}
              </Button>
            </div>

            <div className="mt-8 grid gap-3 sm:grid-cols-3">
              <InfoTile
                icon={Truck}
                title={t("product.deliveryEstimate")}
                body={
                  ship
                    ? `${ship.minDays}–${ship.maxDays} ${t("product.days")} · ${
                        ship.price.amount === 0 ? t("common.free") : formatMoney(ship.price, locale)
                      }`
                    : "—"
                }
              />
              <InfoTile
                icon={ShieldCheck}
                title={t("product.returns")}
                body={`${product.returnDays} ${t("product.days")}`}
              />
              <InfoTile
                icon={BadgeCheck}
                title={t("product.processingTime")}
                body={`${product.processingDays} ${t("product.days")}`}
              />
            </div>
          </div>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-[1.4fr_0.8fr]">
          <div className="space-y-8">
            <section>
              <h2 className="text-lg font-semibold">{t("product.description")}</h2>
              <p className="mt-3 whitespace-pre-line text-[var(--muted-foreground)] leading-relaxed">
                {localize(product.description, locale)}
              </p>
            </section>
            <section>
              <h2 className="text-lg font-semibold">{t("product.specifications")}</h2>
              <dl className="mt-3 divide-y divide-[var(--border)] rounded-xl border border-[var(--border)]">
                {Object.entries(product.attributes).map(([k, v]) => (
                  <div key={k} className="grid grid-cols-2 gap-2 px-4 py-3 text-sm">
                    <dt className="capitalize text-[var(--muted-foreground)]">{k.replaceAll("_", " ")}</dt>
                    <dd className="font-medium">{Array.isArray(v) ? v.join(", ") : String(v)}</dd>
                  </div>
                ))}
                <div className="grid grid-cols-2 gap-2 px-4 py-3 text-sm">
                  <dt className="text-[var(--muted-foreground)]">SKU</dt>
                  <dd className="font-medium">{activeVariant?.sku || product.sku || "—"}</dd>
                </div>
                <div className="grid grid-cols-2 gap-2 px-4 py-3 text-sm">
                  <dt className="text-[var(--muted-foreground)]">Condition</dt>
                  <dd className="font-medium capitalize">{product.condition.replaceAll("_", " ")}</dd>
                </div>
              </dl>
            </section>
            <section>
              <h2 className="text-lg font-semibold">{t("product.reviews")}</h2>
              <div className="mt-4 space-y-4">
                {!reviews.length ? (
                  <p className="text-sm text-[var(--muted-foreground)]">No reviews yet.</p>
                ) : (
                  reviews.map((r) => (
                    <article key={r.id} className="rounded-xl border border-[var(--border)] p-4">
                      <div className="flex items-center justify-between gap-3">
                        <p className="font-medium">{r.buyerName}</p>
                        <RatingDisplay rating={r.productRating} />
                      </div>
                      <h3 className="mt-2 text-sm font-semibold">{localize(r.title, locale)}</h3>
                      <p className="mt-1 text-sm text-[var(--muted-foreground)]">
                        {localize(r.body, locale)}
                      </p>
                      {r.sellerResponse ? (
                        <div className="mt-3 rounded-lg bg-[var(--muted)]/50 p-3 text-sm">
                          <p className="font-medium">Seller response</p>
                          <p className="mt-1 text-[var(--muted-foreground)]">
                            {localize(r.sellerResponse.body, locale)}
                          </p>
                        </div>
                      ) : null}
                    </article>
                  ))
                )}
              </div>
            </section>
          </div>

          {store ? (
            <aside className="h-fit rounded-2xl border border-[var(--border)] bg-[var(--card)] p-5 lg:sticky lg:top-20">
              <p className="text-xs uppercase tracking-wide text-[var(--muted-foreground)]">
                {t("product.soldBy")}
              </p>
              <Link href={`/stores/${store.slug}`} className="mt-2 block text-lg font-semibold hover:underline">
                {store.name}
              </Link>
              <div className="mt-2 flex items-center gap-2 text-sm">
                <RatingDisplay rating={store.rating} count={store.reviewCount} />
              </div>
              <dl className="mt-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <dt className="text-[var(--muted-foreground)]">Response rate</dt>
                  <dd className="font-medium">{store.responseRate}%</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-[var(--muted-foreground)]">{t("product.responseTime")}</dt>
                  <dd className="font-medium">
                    {store.responseTimeHours} {t("product.hours")}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-[var(--muted-foreground)]">Location</dt>
                  <dd className="font-medium">{store.location || "—"}</dd>
                </div>
              </dl>
              <Button asChild className="mt-5 w-full" variant="outline">
                <Link href={`/stores/${store.slug}`}>{t("common.view")} store</Link>
              </Button>
            </aside>
          ) : null}
        </div>
      </div>

      <ProductRail title={t("product.related")} products={related} stores={store ? [store] : []} />

      {/* Mobile sticky purchase bar */}
      <div className="fixed inset-x-0 bottom-16 z-30 border-t border-[var(--border)] bg-[var(--background)]/95 p-3 backdrop-blur md:hidden">
        <div className="flex items-center gap-3">
          <div className="min-w-0 flex-1">
            <PriceDisplay price={price} compareAt={compareAt} size="sm" />
          </div>
          <Button
            className="flex-1"
            disabled={isOos}
            onClick={async () => {
              try {
                await addItem(product.id, qty, activeVariant?.id);
                toast.success("Added to cart");
              } catch (e) {
                toast.error(e instanceof Error ? e.message : "Failed");
              }
            }}
          >
            {t("product.addToCart")}
          </Button>
        </div>
      </div>
    </div>
  );
}

function InfoTile({
  icon: Icon,
  title,
  body,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  body: string;
}) {
  return (
    <div className="rounded-xl border border-[var(--border)] p-3">
      <Icon className="h-4 w-4 text-[var(--primary)]" />
      <p className="mt-2 text-xs text-[var(--muted-foreground)]">{title}</p>
      <p className="text-sm font-medium">{body}</p>
    </div>
  );
}
