"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import type { SearchResult, Store } from "@/types";
import { ProductCard } from "@/components/commerce/product-card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/feedback/empty-state";
import { useLocaleStore } from "@/i18n";

export function SearchClient({
  query,
  result,
  trending,
  stores,
  sort,
}: {
  query: string;
  result: SearchResult;
  trending: string[];
  stores: Store[];
  sort: string;
}) {
  const t = useLocaleStore((s) => s.t);
  const router = useRouter();
  const [q, setQ] = useState(query);
  const storeMap = new Map(stores.map((s) => [s.id, s]));

  return (
    <div className="container-sol py-6 md:py-8">
      <form
        className="flex flex-col gap-3 sm:flex-row"
        onSubmit={(e) => {
          e.preventDefault();
          router.push(`/search?q=${encodeURIComponent(q)}&sort=${sort}`);
        }}
      >
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={t("common.searchPlaceholder")}
          className="h-12"
        />
        <Button type="submit" className="h-12 sm:w-32">
          {t("common.search")}
        </Button>
      </form>

      <div className="mt-4 flex flex-wrap gap-2">
        {trending.map((term) => (
          <Link
            key={term}
            href={`/search?q=${encodeURIComponent(term)}`}
            className="rounded-full border border-[var(--border)] px-3 py-1 text-xs text-[var(--muted-foreground)] hover:border-[var(--primary)]"
          >
            {term}
          </Link>
        ))}
      </div>

      <div className="mt-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            {query ? `${t("search.resultsFor")} “${query}”` : t("search.title")}
          </h1>
          <p className="mt-1 text-sm text-[var(--muted-foreground)]">
            {result.total} {t("search.products")}
          </p>
        </div>
        <select
          className="h-10 rounded-md border border-[var(--border)] bg-[var(--background)] px-3 text-sm"
          value={sort}
          onChange={(e) =>
            router.push(`/search?q=${encodeURIComponent(query)}&sort=${e.target.value}`)
          }
        >
          <option value="relevance">{t("search.relevance")}</option>
          <option value="newest">{t("search.newest")}</option>
          <option value="price_asc">{t("search.priceAsc")}</option>
          <option value="price_desc">{t("search.priceDesc")}</option>
          <option value="rating">{t("search.rating")}</option>
          <option value="best_selling">{t("search.bestSelling")}</option>
        </select>
      </div>

      {!result.products.length ? (
        <div className="mt-8">
          <EmptyState
            title={t("search.noResultsTitle")}
            description={t("search.noResultsBody")}
            actionLabel={t("nav.discover")}
            actionHref="/discover"
          />
        </div>
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
          {result.products.map((p) => (
            <ProductCard key={p.id} product={p} store={storeMap.get(p.storeId)} />
          ))}
        </div>
      )}

      {result.stores.length ? (
        <div className="mt-10">
          <h2 className="mb-3 text-lg font-semibold">{t("search.sellers")}</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {result.stores.map((s) => (
              <Link
                key={s.id}
                href={`/stores/${s.slug}`}
                className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 hover:border-[var(--primary)]"
              >
                <p className="font-semibold">{s.name}</p>
                <p className="mt-1 text-sm text-[var(--muted-foreground)] line-clamp-2">
                  {s.description.en}
                </p>
              </Link>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}
