"use client";

import { useMemo, useState } from "react";
import type { Category, Product, Store } from "@/types";
import { ProductCard } from "@/components/commerce/product-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { localize, useLocaleStore } from "@/i18n";
import { EmptyState } from "@/components/feedback/empty-state";
import Link from "next/link";

export function DiscoverClient({
  initialProducts,
  total,
  categories,
  stores,
  initialSort,
  initialType,
}: {
  initialProducts: Product[];
  total: number;
  categories: Array<Category & { children: Category[] }>;
  stores: Store[];
  initialSort: string;
  initialType?: string;
}) {
  const t = useLocaleStore((s) => s.t);
  const locale = useLocaleStore((s) => s.locale);
  const [sort, setSort] = useState(initialSort);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [minRating, setMinRating] = useState("");
  const [inStockOnly, setInStockOnly] = useState(false);
  const [onSale, setOnSale] = useState(false);
  const [verified, setVerified] = useState(false);
  const [categoryId, setCategoryId] = useState("");
  const storeMap = useMemo(() => new Map(stores.map((s) => [s.id, s])), [stores]);

  const products = useMemo(() => {
    let list = [...initialProducts];
    if (categoryId) {
      const childIds = categories
        .flatMap((c) => [c, ...c.children])
        .filter((c) => c.id === categoryId || c.parentId === categoryId)
        .map((c) => c.id);
      list = list.filter((p) => childIds.includes(p.categoryId) || p.categoryId === categoryId);
    }
    if (minPrice) list = list.filter((p) => p.basePrice.amount >= Number(minPrice) * 100);
    if (maxPrice) list = list.filter((p) => p.basePrice.amount <= Number(maxPrice) * 100);
    if (minRating) list = list.filter((p) => p.rating >= Number(minRating));
    if (inStockOnly) list = list.filter((p) => p.quantity > 0 && p.status !== "out_of_stock");
    if (onSale)
      list = list.filter(
        (p) => !!p.compareAtPrice && p.compareAtPrice.amount > p.basePrice.amount
      );
    if (verified) {
      list = list.filter((p) => storeMap.get(p.storeId)?.verificationStatus === "verified");
    }
    switch (sort) {
      case "price_asc":
        list.sort((a, b) => a.basePrice.amount - b.basePrice.amount);
        break;
      case "price_desc":
        list.sort((a, b) => b.basePrice.amount - a.basePrice.amount);
        break;
      case "newest":
        list.sort((a, b) => (b.publishedAt || "").localeCompare(a.publishedAt || ""));
        break;
      case "rating":
        list.sort((a, b) => b.rating - a.rating);
        break;
      case "best_selling":
        list.sort((a, b) => b.salesCount - a.salesCount);
        break;
      default:
        break;
    }
    return list;
  }, [
    initialProducts,
    categoryId,
    categories,
    minPrice,
    maxPrice,
    minRating,
    inStockOnly,
    onSale,
    verified,
    sort,
    storeMap,
  ]);

  return (
    <div className="container-sol py-6 md:py-8">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight md:text-3xl">{t("nav.discover")}</h1>
          <p className="mt-1 text-sm text-[var(--muted-foreground)]">
            {products.length} / {total} {t("common.results")}
            {initialType ? ` · ${initialType}` : ""}
          </p>
        </div>
        <label className="flex items-center gap-2 text-sm">
          <span className="text-[var(--muted-foreground)]">{t("search.sortBy")}</span>
          <select
            className="h-10 rounded-md border border-[var(--border)] bg-[var(--background)] px-3"
            value={sort}
            onChange={(e) => setSort(e.target.value)}
          >
            <option value="recommended">{t("search.recommended")}</option>
            <option value="newest">{t("search.newest")}</option>
            <option value="price_asc">{t("search.priceAsc")}</option>
            <option value="price_desc">{t("search.priceDesc")}</option>
            <option value="rating">{t("search.rating")}</option>
            <option value="best_selling">{t("search.bestSelling")}</option>
          </select>
        </label>
      </div>

      <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
        <aside className="h-fit rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 lg:sticky lg:top-20">
          <h2 className="font-semibold">{t("search.filters")}</h2>
          <div className="mt-4 space-y-4">
            <div>
              <label className="text-xs font-medium text-[var(--muted-foreground)]">
                {t("nav.categories")}
              </label>
              <select
                className="mt-1 h-10 w-full rounded-md border border-[var(--border)] bg-[var(--background)] px-2 text-sm"
                value={categoryId}
                onChange={(e) => setCategoryId(e.target.value)}
              >
                <option value="">{t("common.all")}</option>
                {categories.map((c) => (
                  <optgroup key={c.id} label={localize(c.name, locale)}>
                    <option value={c.id}>{localize(c.name, locale)}</option>
                    {c.children.map((ch) => (
                      <option key={ch.id} value={ch.id}>
                        {localize(ch.name, locale)}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs text-[var(--muted-foreground)]">Min</label>
                <Input value={minPrice} onChange={(e) => setMinPrice(e.target.value)} inputMode="decimal" placeholder="0" />
              </div>
              <div>
                <label className="text-xs text-[var(--muted-foreground)]">Max</label>
                <Input value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} inputMode="decimal" placeholder="500" />
              </div>
            </div>
            <div>
              <label className="text-xs text-[var(--muted-foreground)]">{t("search.ratingMin")}</label>
              <Input value={minRating} onChange={(e) => setMinRating(e.target.value)} inputMode="decimal" placeholder="4" />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={inStockOnly} onChange={(e) => setInStockOnly(e.target.checked)} />
              {t("common.inStock")}
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={onSale} onChange={(e) => setOnSale(e.target.checked)} />
              {t("search.onSale")}
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={verified} onChange={(e) => setVerified(e.target.checked)} />
              {t("search.verifiedOnly")}
            </label>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => {
                setCategoryId("");
                setMinPrice("");
                setMaxPrice("");
                setMinRating("");
                setInStockOnly(false);
                setOnSale(false);
                setVerified(false);
              }}
            >
              {t("common.clearAll")}
            </Button>
          </div>
        </aside>

        <div>
          {!products.length ? (
            <EmptyState
              title={t("search.noResultsTitle")}
              description={t("search.noResultsBody")}
              actionLabel={t("common.clearAll")}
              onAction={() => {
                setCategoryId("");
                setMinPrice("");
                setMaxPrice("");
                setInStockOnly(false);
                setOnSale(false);
                setVerified(false);
              }}
            />
          ) : (
            <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
              {products.map((p) => (
                <ProductCard key={p.id} product={p} store={storeMap.get(p.storeId)} />
              ))}
            </div>
          )}
          <div className="mt-8 flex flex-wrap gap-2">
            <Button asChild variant="outline" size="sm">
              <Link href="/deals">{t("nav.deals")}</Link>
            </Button>
            <Button asChild variant="outline" size="sm">
              <Link href="/stores">{t("nav.stores")}</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
