"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Cart } from "@/types";
import { getServices } from "@/services";
import { platform } from "@/config/platform";
import { useAuthStore } from "@/features/auth/store";
import { money, multiplyMoney, sumMoney } from "@/lib/money";

type CartState = {
  cart: Cart | null;
  loading: boolean;
  cartKey: () => string;
  refresh: () => Promise<void>;
  addItem: (productId: string, quantity?: number, variantId?: string) => Promise<void>;
  updateItem: (itemId: string, quantity: number) => Promise<void>;
  removeItem: (itemId: string) => Promise<void>;
  applyCoupon: (code: string) => Promise<void>;
  itemCount: () => number;
  subtotalMinor: () => number;
};

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      cart: null,
      loading: false,
      cartKey: () => {
        const user = useAuthStore.getState().session?.user;
        return user ? `user:${user.id}` : platform.guestCartKey;
      },
      refresh: async () => {
        set({ loading: true });
        try {
          const cart = await getServices().cart.getCart(get().cartKey());
          set({ cart });
        } finally {
          set({ loading: false });
        }
      },
      addItem: async (productId, quantity = 1, variantId) => {
        const cart = await getServices().cart.addItem(get().cartKey(), {
          productId,
          quantity,
          variantId,
        });
        set({ cart });
      },
      updateItem: async (itemId, quantity) => {
        const cart = await getServices().cart.updateItem(get().cartKey(), itemId, quantity);
        set({ cart });
      },
      removeItem: async (itemId) => {
        const cart = await getServices().cart.removeItem(get().cartKey(), itemId);
        set({ cart });
      },
      applyCoupon: async (code) => {
        const cart = await getServices().cart.applyCoupon(get().cartKey(), code);
        set({ cart });
      },
      itemCount: () =>
        get().cart?.items.filter((i) => !i.savedForLater).reduce((s, i) => s + i.quantity, 0) || 0,
      subtotalMinor: () => {
        const items = get().cart?.items.filter((i) => !i.savedForLater) || [];
        if (!items.length) return 0;
        return sumMoney(
          items.map((i) => multiplyMoney(i.unitPrice, i.quantity)),
          items[0]?.unitPrice.currency || "USD"
        ).amount;
      },
    }),
    {
      name: "sol-cart-cache-v1",
      partialize: (s) => ({ cart: s.cart }),
    }
  )
);

export function emptyCart(): Cart {
  return {
    id: "empty",
    items: [],
    updatedAt: new Date().toISOString(),
  };
}

export function cartTotals(cart: Cart | null) {
  const items = cart?.items.filter((i) => !i.savedForLater) || [];
  const currency = items[0]?.unitPrice.currency || "USD";
  const subtotal = items.length
    ? sumMoney(
        items.map((i) => multiplyMoney(i.unitPrice, i.quantity)),
        currency
      )
    : money(0, currency);
  return { subtotal, currency, count: items.reduce((s, i) => s + i.quantity, 0) };
}
