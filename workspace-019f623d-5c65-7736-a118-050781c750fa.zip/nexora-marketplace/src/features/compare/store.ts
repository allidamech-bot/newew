"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { platform } from "@/config/platform";

type CompareState = {
  productIds: string[];
  add: (id: string) => void;
  remove: (id: string) => void;
  clear: () => void;
  has: (id: string) => boolean;
};

export const useCompareStore = create<CompareState>()(
  persist(
    (set, get) => ({
      productIds: [],
      add: (id) => {
        const current = get().productIds;
        if (current.includes(id)) return;
        if (current.length >= platform.maxCompareItems) {
          set({ productIds: [...current.slice(1), id] });
          return;
        }
        set({ productIds: [...current, id] });
      },
      remove: (id) => set({ productIds: get().productIds.filter((x) => x !== id) }),
      clear: () => set({ productIds: [] }),
      has: (id) => get().productIds.includes(id),
    }),
    { name: platform.compareKey }
  )
);
