"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Session, UserProfile } from "@/types";
import { getServices } from "@/services";
import { platform } from "@/config/platform";

type AuthState = {
  session: Session | null;
  hydrated: boolean;
  setHydrated: (v: boolean) => void;
  signIn: (email: string, password: string) => Promise<UserProfile>;
  signUp: (input: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
  }) => Promise<UserProfile>;
  signOut: () => Promise<void>;
  user: () => UserProfile | null;
  hasRole: (...roles: string[]) => boolean;
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      session: null,
      hydrated: false,
      setHydrated: (v) => set({ hydrated: v }),
      signIn: async (email, password) => {
        const session = await getServices().auth.signIn(email, password);
        set({ session });
        try {
          await getServices().cart.mergeGuestCart(platform.guestCartKey, session.user.id);
        } catch {
          // merge best-effort
        }
        return session.user;
      },
      signUp: async (input) => {
        const session = await getServices().auth.signUp(input);
        set({ session });
        return session.user;
      },
      signOut: async () => {
        const token = get().session?.accessToken;
        if (token) await getServices().auth.signOut(token);
        set({ session: null });
      },
      user: () => get().session?.user ?? null,
      hasRole: (...roles) => {
        const user = get().session?.user;
        if (!user) return roles.includes("guest");
        return roles.some((r) => user.roles.includes(r as never));
      },
    }),
    {
      name: "sol-auth-v1",
      partialize: (s) => ({ session: s.session }),
      onRehydrateStorage: () => (state) => {
        state?.setHydrated(true);
      },
    }
  )
);
