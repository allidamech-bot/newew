import { z } from "zod";

export const productWizardSchema = z.object({
  type: z.enum(["physical", "digital", "service", "made_to_order", "preorder"]),
  titleEn: z.string().min(3, "English title is required"),
  titleAr: z.string().min(2, "Arabic title is required"),
  descriptionEn: z.string().min(20, "Description must be at least 20 characters"),
  descriptionAr: z.string().min(10, "Arabic description is required"),
  categoryId: z.string().min(1, "Category is required"),
  price: z.coerce.number().min(0, "Price must be >= 0"),
  quantity: z.coerce.number().int().min(0),
  sku: z.string().optional(),
  weightGrams: z.coerce.number().min(0).optional(),
  requiresShipping: z.boolean(),
  offersEnabled: z.boolean(),
  seoTitle: z.string().optional(),
  seoDescription: z.string().optional(),
  digitalFileRef: z.string().optional(),
  serviceDurationMinutes: z.coerce.number().int().min(0).optional(),
  processingDays: z.coerce.number().int().min(0).default(2),
  returnDays: z.coerce.number().int().min(0).default(14),
  attributes: z.record(z.string(), z.union([z.string(), z.number(), z.boolean(), z.array(z.string())])).default({}),
  media: z
    .array(
      z.object({
        id: z.string(),
        url: z.string().min(1),
        alt: z.string().optional(),
        isCover: z.boolean().optional(),
      })
    )
    .min(1, "At least one media item is required"),
  variantAxes: z
    .array(
      z.object({
        name: z.string().min(1),
        values: z.array(z.string().min(1)).min(1),
      })
    )
    .default([]),
  variants: z
    .array(
      z.object({
        id: z.string(),
        options: z.record(z.string(), z.string()),
        sku: z.string().min(1),
        price: z.coerce.number().min(0),
        quantity: z.coerce.number().int().min(0),
        enabled: z.boolean(),
        mediaUrl: z.string().optional(),
      })
    )
    .default([]),
});

export type ProductWizardValues = z.infer<typeof productWizardSchema>;

export function generateVariantCombinations(
  axes: Array<{ name: string; values: string[] }>
): Array<Record<string, string>> {
  if (!axes.length) return [];
  return axes.reduce<Array<Record<string, string>>>(
    (acc, axis) => {
      if (!acc.length) {
        return axis.values.map((value) => ({ [axis.name]: value }));
      }
      const next: Array<Record<string, string>> = [];
      for (const current of acc) {
        for (const value of axis.values) {
          next.push({ ...current, [axis.name]: value });
        }
      }
      return next;
    },
    []
  );
}

export function productQualityScore(values: Partial<ProductWizardValues>): {
  score: number;
  missing: string[];
} {
  const checks: Array<[boolean, string]> = [
    [!!values.titleEn && values.titleEn.length >= 3, "English title"],
    [!!values.titleAr && values.titleAr.length >= 2, "Arabic title"],
    [!!values.descriptionEn && values.descriptionEn.length >= 40, "Rich description"],
    [!!values.categoryId, "Category"],
    [!!values.media?.length, "Media"],
    [typeof values.price === "number" && values.price > 0, "Price"],
    [!!values.sku, "SKU"],
    [!!values.seoTitle, "SEO title"],
    [(values.media || []).some((m) => m.alt), "Media alt text"],
    [Object.keys(values.attributes || {}).length > 0, "Attributes"],
  ];
  const missing = checks.filter(([ok]) => !ok).map(([, label]) => label);
  const score = Math.round(((checks.length - missing.length) / checks.length) * 100);
  return { score, missing };
}
