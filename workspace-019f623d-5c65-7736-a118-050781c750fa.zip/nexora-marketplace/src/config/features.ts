/**
 * Feature flags — mock source. Later loadable from database.
 */
export type FeatureFlagKey =
  | "offers"
  | "digitalProducts"
  | "services"
  | "storeFollows"
  | "productComparison"
  | "reviews"
  | "messaging"
  | "cashOnDelivery"
  | "sellerRegistration"
  | "productModeration"
  | "multipleWarehouses"
  | "multipleCurrencies"
  | "newCheckout"
  | "newHomepage"
  | "maintenanceMode"
  | "voiceSearch"
  | "imageSearch"
  | "socialAuth"
  | "twoFactorAuth"
  | "subscriptions"
  | "bookings";

export const defaultFeatureFlags: Record<FeatureFlagKey, boolean> = {
  offers: true,
  digitalProducts: true,
  services: true,
  storeFollows: true,
  productComparison: true,
  reviews: true,
  messaging: true,
  cashOnDelivery: true,
  sellerRegistration: true,
  productModeration: true,
  multipleWarehouses: true,
  multipleCurrencies: true,
  newCheckout: true,
  newHomepage: true,
  maintenanceMode: false,
  voiceSearch: false,
  imageSearch: false,
  socialAuth: true,
  twoFactorAuth: false,
  subscriptions: false,
  bookings: false,
};

export function isFeatureEnabled(
  key: FeatureFlagKey,
  overrides?: Partial<Record<FeatureFlagKey, boolean>>
): boolean {
  return overrides?.[key] ?? defaultFeatureFlags[key];
}
