/**
 * Centralized brand configuration.
 * Replace values here (or via platform settings) to rebrand the product.
 */
export const brand = {
  name: "NEXORA",
  legalName: "NEXORA Marketplace",
  tagline: {
    en: "Discover more. Trade smarter.",
    ar: "اكتشف أكثر، وتسوّق بذكاء",
  },
  description: {
    en: "NEXORA is a next-generation multi-vendor marketplace for physical products, digital goods, and services — built for intelligent discovery and trusted trade.",
    ar: "نيكسورا منصة سوق متعددة البائعين للجيل القادم للمنتجات المادية والرقمية والخدمات — مصممة للاكتشاف الذكي والتجارة الموثوقة.",
  },
  domain: "nexora.marketplace",
  supportEmail: "support@nexora.marketplace",
  contactEmail: "hello@nexora.marketplace",
  social: {
    twitter: "https://twitter.com/nexoramarket",
    instagram: "https://instagram.com/nexoramarket",
    linkedin: "https://linkedin.com/company/nexoramarket",
  },
  logo: {
    mark: "nexora-mark",
    alt: {
      en: "NEXORA logo",
      ar: "شعار نيكسورا",
    },
  },
  colors: {
    primary: "indigo",
  },
} as const;

export type BrandConfig = typeof brand;
export type Locale = "en" | "ar";
