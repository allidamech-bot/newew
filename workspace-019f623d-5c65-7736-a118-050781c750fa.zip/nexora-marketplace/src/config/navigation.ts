import type { Locale } from "./brand";

export type NavItem = {
  id: string;
  href: string;
  labelKey: string;
  icon?: string;
  roles?: Array<"guest" | "buyer" | "seller" | "moderator" | "admin" | "super_admin">;
  featureFlag?: string;
};

export const publicNav: NavItem[] = [
  { id: "discover", href: "/discover", labelKey: "nav.discover" },
  { id: "categories", href: "/categories", labelKey: "nav.categories" },
  { id: "deals", href: "/deals", labelKey: "nav.deals" },
  { id: "stores", href: "/stores", labelKey: "nav.stores" },
];

export const buyerBottomNav: NavItem[] = [
  { id: "home", href: "/", labelKey: "nav.home", icon: "home" },
  { id: "discover", href: "/discover", labelKey: "nav.discover", icon: "compass" },
  { id: "cart", href: "/cart", labelKey: "nav.cart", icon: "shopping-bag" },
  { id: "messages", href: "/account/messages", labelKey: "nav.messages", icon: "message-circle", roles: ["buyer", "seller"] },
  { id: "account", href: "/account", labelKey: "nav.account", icon: "user" },
];

export const sellerBottomNav: NavItem[] = [
  { id: "dashboard", href: "/seller", labelKey: "seller.dashboard", icon: "layout-dashboard" },
  { id: "products", href: "/seller/products", labelKey: "seller.products", icon: "package" },
  { id: "add", href: "/seller/products/new", labelKey: "seller.add", icon: "plus" },
  { id: "orders", href: "/seller/orders", labelKey: "seller.orders", icon: "clipboard-list" },
  { id: "store", href: "/seller/store", labelKey: "seller.store", icon: "store" },
];

export const accountNav: NavItem[] = [
  { id: "overview", href: "/account", labelKey: "account.overview" },
  { id: "orders", href: "/account/orders", labelKey: "account.orders" },
  { id: "returns", href: "/account/returns", labelKey: "account.returns" },
  { id: "disputes", href: "/account/disputes", labelKey: "account.disputes" },
  { id: "messages", href: "/account/messages", labelKey: "account.messages" },
  { id: "notifications", href: "/account/notifications", labelKey: "account.notifications" },
  { id: "wishlists", href: "/account/wishlists", labelKey: "account.wishlists" },
  { id: "following", href: "/account/following", labelKey: "account.following" },
  { id: "reviews", href: "/account/reviews", labelKey: "account.reviews" },
  { id: "addresses", href: "/account/addresses", labelKey: "account.addresses" },
  { id: "security", href: "/account/security", labelKey: "account.security" },
  { id: "preferences", href: "/account/preferences", labelKey: "account.preferences" },
  { id: "privacy", href: "/account/privacy", labelKey: "account.privacy" },
];

export const sellerNav: NavItem[] = [
  { id: "dashboard", href: "/seller", labelKey: "seller.dashboard" },
  { id: "products", href: "/seller/products", labelKey: "seller.products" },
  { id: "inventory", href: "/seller/inventory", labelKey: "seller.inventory" },
  { id: "orders", href: "/seller/orders", labelKey: "seller.orders" },
  { id: "returns", href: "/seller/returns", labelKey: "seller.returns" },
  { id: "messages", href: "/seller/messages", labelKey: "seller.messages" },
  { id: "reviews", href: "/seller/reviews", labelKey: "seller.reviews" },
  { id: "promotions", href: "/seller/promotions", labelKey: "seller.promotions" },
  { id: "analytics", href: "/seller/analytics", labelKey: "seller.analytics" },
  { id: "customers", href: "/seller/customers", labelKey: "seller.customers" },
  { id: "staff", href: "/seller/staff", labelKey: "seller.staff" },
  { id: "shipping", href: "/seller/shipping", labelKey: "seller.shipping" },
  { id: "store", href: "/seller/store", labelKey: "seller.store" },
  { id: "settings", href: "/seller/settings", labelKey: "seller.settings" },
];

export const adminNav: NavItem[] = [
  { id: "overview", href: "/admin", labelKey: "admin.overview" },
  { id: "users", href: "/admin/users", labelKey: "admin.users" },
  { id: "sellers", href: "/admin/sellers", labelKey: "admin.sellers" },
  { id: "stores", href: "/admin/stores", labelKey: "admin.stores" },
  { id: "products", href: "/admin/products", labelKey: "admin.products" },
  { id: "categories", href: "/admin/categories", labelKey: "admin.categories" },
  { id: "orders", href: "/admin/orders", labelKey: "admin.orders" },
  { id: "disputes", href: "/admin/disputes", labelKey: "admin.disputes" },
  { id: "reports", href: "/admin/reports", labelKey: "admin.reports" },
  { id: "reviews", href: "/admin/reviews", labelKey: "admin.reviews" },
  { id: "promotions", href: "/admin/promotions", labelKey: "admin.promotions" },
  { id: "cms", href: "/admin/cms", labelKey: "admin.cms" },
  { id: "flags", href: "/admin/feature-flags", labelKey: "admin.featureFlags" },
  { id: "settings", href: "/admin/settings", labelKey: "admin.settings" },
  { id: "audit", href: "/admin/audit", labelKey: "admin.audit" },
  { id: "analytics", href: "/admin/analytics", labelKey: "admin.analytics" },
];

export const footerNav = {
  shop: [
    { href: "/discover", labelKey: "nav.discover" },
    { href: "/deals", labelKey: "nav.deals" },
    { href: "/categories", labelKey: "nav.categories" },
    { href: "/stores", labelKey: "nav.stores" },
  ],
  sell: [
    { href: "/sell", labelKey: "nav.sellOnSol" },
    { href: "/seller/onboarding", labelKey: "nav.becomeSeller" },
    { href: "/help/seller", labelKey: "nav.sellerHelp" },
  ],
  support: [
    { href: "/help", labelKey: "nav.help" },
    { href: "/contact", labelKey: "nav.contact" },
    { href: "/trust-and-safety", labelKey: "nav.trust" },
    { href: "/accessibility", labelKey: "nav.accessibility" },
  ],
  company: [
    { href: "/about", labelKey: "nav.about" },
    { href: "/policies/terms", labelKey: "nav.terms" },
    { href: "/policies/privacy", labelKey: "nav.privacy" },
    { href: "/policies/returns", labelKey: "nav.returns" },
  ],
};

export function directionForLocale(locale: Locale): "ltr" | "rtl" {
  return locale === "ar" ? "rtl" : "ltr";
}
