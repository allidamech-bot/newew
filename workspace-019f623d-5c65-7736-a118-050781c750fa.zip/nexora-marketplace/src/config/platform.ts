import { brand } from "./brand";

export const platform = {
  brand,
  appName: brand.name,
  defaultLocale: "en" as const,
  supportedLocales: ["en", "ar"] as const,
  defaultCurrency: "USD" as const,
  supportedCurrencies: ["USD", "EUR", "TRY", "AED", "SAR"] as const,
  baseCurrency: "USD" as const,
  dataProvider: (process.env.NEXT_PUBLIC_DATA_PROVIDER || "mock") as
    | "mock"
    | "supabase",
  maxCompareItems: 4,
  maxWishlistItems: 200,
  maxCartItems: 50,
  maxProductImages: 12,
  maxVariantCombinations: 100,
  lowStockThresholdDefault: 5,
  returnWindowDaysDefault: 14,
  reviewEditWindowDays: 7,
  offerDefaultExpiryHours: 48,
  guestCartKey: "nexora-guest-cart-v1",
  compareKey: "nexora-compare-v1",
  recentlyViewedKey: "nexora-recently-viewed-v1",
  localeKey: "nexora-locale-v1",
  themeKey: "nexora-theme-v1",
  pagination: {
    defaultPageSize: 24,
    maxPageSize: 100,
  },
  commission: {
    defaultPercent: 8,
  },
  shipping: {
    freeThresholdDefault: 75,
  },
  contact: {
    email: brand.supportEmail,
    phone: "+1 (555) 010-7656",
  },
  urls: {
    app: process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000",
  },
} as const;

export type PlatformConfig = typeof platform;
export type SupportedLocale = (typeof platform.supportedLocales)[number];
export type SupportedCurrency = (typeof platform.supportedCurrencies)[number];
