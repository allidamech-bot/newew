"use client";

import Link from "next/link";
import type { Product, Store } from "@/types";
import { ProductCard } from "@/components/commerce/product-card";
import { useLocaleStore } from "@/i18n";

export function ProductRail({
  title,
  products,
  stores,
  href,
}: {
  title: string;
  products: Product[];
  stores?: Store[];
  href?: string;
}) {
  const t = useLocaleStore((s) => s.t);
  const storeMap = new Map((stores || []).map((s) => [s.id, s]));

  if (!products.length) return null;

  return (
    <section className="section-pad">
      <div className="container-sol">
        <div className="mb-4 flex items-end justify-between gap-3">
          <h2 className="text-xl font-semibold tracking-tight md:text-2xl">{title}</h2>
          {href ? (
            <Link href={href} className="text-sm font-medium text-[var(--primary)] hover:underline">
              {t("common.viewAll")}
            </Link>
          ) : null}
        </div>
        <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 pb-2 md:mx-0 md:grid md:grid-cols-4 md:overflow-visible md:px-0 lg:grid-cols-5">
          {products.map((p) => (
            <div key={p.id} className="w-[72%] max-w-[240px] shrink-0 md:w-auto md:max-w-none">
              <ProductCard product={p} store={storeMap.get(p.storeId)} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
