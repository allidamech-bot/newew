import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export function RatingDisplay({
  rating,
  count,
  size = "sm",
  className,
}: {
  rating: number;
  count?: number;
  size?: "sm" | "md";
  className?: string;
}) {
  return (
    <div className={cn("inline-flex items-center gap-1 text-[var(--muted-foreground)]", className)}>
      <Star
        className={cn(
          "fill-amber-400 text-amber-400",
          size === "sm" ? "h-3.5 w-3.5" : "h-4 w-4"
        )}
        aria-hidden
      />
      <span className={cn("font-medium text-[var(--foreground)]", size === "sm" ? "text-xs" : "text-sm")}>
        {rating.toFixed(1)}
      </span>
      {typeof count === "number" ? (
        <span className={cn(size === "sm" ? "text-xs" : "text-sm")}>({count})</span>
      ) : null}
    </div>
  );
}
