"use client";

import { formatMoney, discountPercent, type Money } from "@/lib/money";
import { useLocaleStore } from "@/i18n";
import { cn } from "@/lib/utils";

export function PriceDisplay({
  price,
  compareAt,
  className,
  size = "md",
}: {
  price: Money;
  compareAt?: Money;
  className?: string;
  size?: "sm" | "md" | "lg";
}) {
  const locale = useLocaleStore((s) => s.locale);
  const off = compareAt ? discountPercent(compareAt, price) : 0;
  return (
    <div className={cn("flex flex-wrap items-baseline gap-2", className)}>
      <span
        className={cn(
          "font-semibold tracking-tight text-[var(--foreground)]",
          size === "sm" && "text-sm",
          size === "md" && "text-base",
          size === "lg" && "text-2xl"
        )}
      >
        {formatMoney(price, locale)}
      </span>
      {compareAt && compareAt.amount > price.amount ? (
        <>
          <span className="text-sm text-[var(--muted-foreground)] line-through">
            {formatMoney(compareAt, locale)}
          </span>
          {off > 0 ? (
            <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-900 dark:bg-amber-950 dark:text-amber-100">
              −{off}%
            </span>
          ) : null}
        </>
      ) : null}
    </div>
  );
}
