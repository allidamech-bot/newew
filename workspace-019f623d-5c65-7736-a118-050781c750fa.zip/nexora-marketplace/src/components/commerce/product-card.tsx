"use client";

import Link from "next/link";
import Image from "next/image";
import { Heart, GitCompareArrows } from "lucide-react";
import type { Product, Store } from "@/types";
import { PriceDisplay } from "./price-display";
import { RatingDisplay } from "./rating-display";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { localize, useLocaleStore } from "@/i18n";
import { useCompareStore } from "@/features/compare/store";
import { useCartStore } from "@/features/cart/store";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function ProductCard({
  product,
  store,
  variant = "standard",
  className,
}: {
  product: Product;
  store?: Store | null;
  variant?: "standard" | "compact" | "horizontal" | "deal";
  className?: string;
}) {
  const locale = useLocaleStore((s) => s.locale);
  const t = useLocaleStore((s) => s.t);
  const compare = useCompareStore();
  const addItem = useCartStore((s) => s.addItem);
  const title = localize(product.title, locale);
  const isOos = product.quantity <= 0 || product.status === "out_of_stock";
  const onSale =
    !!product.compareAtPrice && product.compareAtPrice.amount > product.basePrice.amount;

  if (variant === "horizontal") {
    return (
      <article
        className={cn(
          "flex gap-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-3",
          className
        )}
      >
        <Link href={`/product/${product.slug}`} className="relative h-24 w-24 shrink-0 overflow-hidden rounded-lg bg-[var(--muted)]">
          <ProductImage product={product} />
        </Link>
        <div className="min-w-0 flex-1">
          <Link href={`/product/${product.slug}`} className="line-clamp-2 font-medium hover:underline">
            {title}
          </Link>
          <PriceDisplay price={product.basePrice} compareAt={product.compareAtPrice} size="sm" className="mt-1" />
          <RatingDisplay rating={product.rating} count={product.reviewCount} className="mt-1" />
        </div>
      </article>
    );
  }

  return (
    <article
      className={cn(
        "group flex h-full flex-col overflow-hidden rounded-xl border border-[var(--border)] bg-[var(--card)] transition-shadow hover:shadow-md",
        className
      )}
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-[var(--muted)]">
        <Link href={`/product/${product.slug}`} className="absolute inset-0">
          <ProductImage product={product} />
        </Link>
        <div className="absolute start-2 top-2 flex flex-col gap-1">
          {onSale ? <Badge variant="warning">{t("common.sale")}</Badge> : null}
          {isOos ? <Badge variant="secondary">{t("common.outOfStock")}</Badge> : null}
          {product.quantity > 0 && product.quantity <= product.lowStockThreshold ? (
            <Badge variant="outline">{t("common.lowStock")}</Badge>
          ) : null}
        </div>
        <div className="absolute end-2 top-2 flex flex-col gap-1 opacity-100 sm:opacity-0 sm:transition-opacity sm:group-hover:opacity-100">
          <Button
            size="icon"
            variant="secondary"
            className="h-9 w-9 bg-white/90 shadow-sm dark:bg-black/60"
            aria-label={t("product.saveProduct")}
            onClick={async (e) => {
              e.preventDefault();
              toast.message("Saved to wishlist (sign in to sync)");
            }}
          >
            <Heart className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="secondary"
            className="h-9 w-9 bg-white/90 shadow-sm dark:bg-black/60"
            aria-label={t("product.compareProduct")}
            onClick={(e) => {
              e.preventDefault();
              if (compare.has(product.id)) compare.remove(product.id);
              else compare.add(product.id);
              toast.success(compare.has(product.id) ? "Removed from compare" : "Added to compare");
            }}
          >
            <GitCompareArrows className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <div className="flex flex-1 flex-col gap-2 p-3.5">
        {store ? (
          <Link
            href={`/stores/${store.slug}`}
            className="text-xs text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
          >
            {store.name}
            {store.verificationStatus === "verified" ? " · ✓" : ""}
          </Link>
        ) : null}
        <Link href={`/product/${product.slug}`} className="line-clamp-2 text-sm font-medium leading-snug hover:underline">
          {title}
        </Link>
        <RatingDisplay rating={product.rating} count={product.reviewCount} />
        <PriceDisplay price={product.basePrice} compareAt={product.compareAtPrice} />
        <div className="mt-auto pt-2">
          <Button
            className="w-full"
            size="sm"
            disabled={isOos}
            onClick={async () => {
              try {
                await addItem(product.id, 1, product.variants[0]?.id);
                toast.success("Added to cart");
              } catch (e) {
                toast.error(e instanceof Error ? e.message : "Could not add to cart");
              }
            }}
          >
            {t("common.addToCart")}
          </Button>
        </div>
      </div>
    </article>
  );
}

function ProductImage({ product }: { product: Product }) {
  const src = product.media[0]?.url || "/images/placeholder-product.svg";
  return (
    <Image
      src={src}
      alt={product.title.en}
      fill
      className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
      sizes="(max-width:768px) 50vw, 25vw"
      unoptimized
    />
  );
}
