"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Compass,
  Home,
  LayoutDashboard,
  MessageCircle,
  Package,
  Plus,
  ClipboardList,
  ShoppingBag,
  Store,
  User,
} from "lucide-react";
import { useLocaleStore } from "@/i18n";
import { useAuthStore } from "@/features/auth/store";
import { useCartStore } from "@/features/cart/store";
import { cn } from "@/lib/utils";

const icons = {
  home: Home,
  compass: Compass,
  "shopping-bag": ShoppingBag,
  "message-circle": MessageCircle,
  user: User,
  "layout-dashboard": LayoutDashboard,
  package: Package,
  plus: Plus,
  "clipboard-list": ClipboardList,
  store: Store,
};

export function MobileBottomNav() {
  const pathname = usePathname();
  const t = useLocaleStore((s) => s.t);
  const hasRole = useAuthStore((s) => s.hasRole);
  const itemCount = useCartStore((s) => s.itemCount());
  const sellerMode =
    pathname.startsWith("/seller") || pathname.startsWith("/admin");

  if (
    pathname.startsWith("/auth") ||
    pathname.startsWith("/checkout") ||
    pathname.startsWith("/admin")
  ) {
    return null;
  }

  type NavEntry = {
    href: string;
    label: string;
    icon: keyof typeof icons;
    badge?: number;
  };

  const buyerItems: NavEntry[] = [
    { href: "/", label: t("nav.home"), icon: "home" },
    { href: "/discover", label: t("nav.discover"), icon: "compass" },
    { href: "/cart", label: t("nav.cart"), icon: "shopping-bag", badge: itemCount },
    { href: "/account/messages", label: t("nav.messages"), icon: "message-circle" },
    { href: "/account", label: t("nav.account"), icon: "user" },
  ];

  const sellerItems: NavEntry[] = [
    { href: "/seller", label: t("seller.dashboard"), icon: "layout-dashboard" },
    { href: "/seller/products", label: t("seller.products"), icon: "package" },
    { href: "/seller/products/new", label: t("seller.add"), icon: "plus" },
    { href: "/seller/orders", label: t("seller.orders"), icon: "clipboard-list" },
    { href: "/seller/store", label: t("seller.store"), icon: "store" },
  ];

  const items: NavEntry[] =
    sellerMode && hasRole("seller", "admin", "super_admin") ? sellerItems : buyerItems;

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-[var(--border)] bg-[var(--background)]/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden"
      aria-label="Mobile"
    >
      <ul className="grid h-16 grid-cols-5">
        {items.map((item) => {
          const Icon = icons[item.icon] || Home;
          const active =
            item.href === "/"
              ? pathname === "/"
              : pathname === item.href || pathname.startsWith(item.href + "/");
          const badge = item.badge ?? 0;
          return (
            <li key={item.href}>
              <Link
                href={item.href}
                className={cn(
                  "relative flex h-full flex-col items-center justify-center gap-0.5 text-[10px] font-medium",
                  active ? "text-[var(--primary)]" : "text-[var(--muted-foreground)]"
                )}
              >
                <span className="relative">
                  <Icon className="h-5 w-5" />
                  {badge > 0 ? (
                    <span className="absolute -end-2 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--primary)] px-1 text-[9px] text-white">
                      {badge}
                    </span>
                  ) : null}
                </span>
                <span>{item.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
