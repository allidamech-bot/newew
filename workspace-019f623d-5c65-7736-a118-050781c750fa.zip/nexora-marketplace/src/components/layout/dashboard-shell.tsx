"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { Logo } from "./logo";
import { Button } from "@/components/ui/button";
import { useAuthStore } from "@/features/auth/store";
import { useLocaleStore } from "@/i18n";
import { cn } from "@/lib/utils";
import { useEffect } from "react";

export function DashboardShell({
  title,
  nav,
  children,
  requiredRoles,
}: {
  title: string;
  nav: Array<{ href: string; label: string }>;
  children: React.ReactNode;
  requiredRoles?: string[];
}) {
  const pathname = usePathname();
  const user = useAuthStore((s) => s.session?.user);
  const hydrated = useAuthStore((s) => s.hydrated);
  const signOut = useAuthStore((s) => s.signOut);
  const router = useRouter();
  const t = useLocaleStore((s) => s.t);

  useEffect(() => {
    if (!hydrated) return;
    if (!user) {
      router.replace("/auth/sign-in");
      return;
    }
    if (
      requiredRoles?.length &&
      !requiredRoles.some((r) => user.roles.includes(r as never))
    ) {
      router.replace("/account");
    }
  }, [hydrated, user, requiredRoles, router]);

  if (!hydrated || !user) {
    return (
      <div className="flex min-h-dvh items-center justify-center text-sm text-[var(--muted-foreground)]">
        {t("common.loading")}
      </div>
    );
  }

  return (
    <div className="min-h-dvh md:grid md:grid-cols-[240px_1fr]">
      <aside className="hidden border-e border-[var(--border)] bg-[var(--card)] md:flex md:flex-col">
        <div className="border-b border-[var(--border)] p-4">
          <Logo />
          <p className="mt-2 text-xs text-[var(--muted-foreground)]">{title}</p>
        </div>
        <nav className="flex-1 space-y-0.5 p-3">
          {nav.map((item) => {
            const active = pathname === item.href || pathname.startsWith(item.href + "/");
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "block rounded-md px-3 py-2 text-sm font-medium",
                  active
                    ? "bg-[var(--primary)] text-[var(--primary-foreground)]"
                    : "text-[var(--muted-foreground)] hover:bg-[var(--muted)] hover:text-[var(--foreground)]"
                )}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-[var(--border)] p-3">
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={async () => {
              await signOut();
              router.push("/");
            }}
          >
            {t("nav.signOut")}
          </Button>
        </div>
      </aside>
      <div className="min-w-0">
        <header className="sticky top-0 z-20 flex h-14 items-center justify-between border-b border-[var(--border)] bg-[var(--background)]/90 px-4 backdrop-blur">
          <div className="md:hidden">
            <Logo compact />
          </div>
          <p className="text-sm font-medium">{user.displayName}</p>
          <div className="flex gap-2">
            <Button asChild variant="outline" size="sm">
              <Link href="/">Storefront</Link>
            </Button>
          </div>
        </header>
        <div className="p-4 md:p-6 pb-24 md:pb-6">{children}</div>
      </div>
    </div>
  );
}
