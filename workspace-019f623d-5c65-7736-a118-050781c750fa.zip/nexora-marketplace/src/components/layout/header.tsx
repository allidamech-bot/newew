"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Bell,
  Heart,
  Menu,
  MessageCircle,
  Moon,
  Search,
  ShoppingBag,
  Sun,
  User,
  GitCompareArrows,
} from "lucide-react";
import { useTheme } from "next-themes";
import { Logo } from "./logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { publicNav } from "@/config/navigation";
import { useLocaleStore } from "@/i18n";
import { useAuthStore } from "@/features/auth/store";
import { useCartStore } from "@/features/cart/store";
import { useCompareStore } from "@/features/compare/store";
import { useState } from "react";
import { cn } from "@/lib/utils";

export function Header() {
  const t = useLocaleStore((s) => s.t);
  const locale = useLocaleStore((s) => s.locale);
  const setLocale = useLocaleStore((s) => s.setLocale);
  const { theme, setTheme } = useTheme();
  const user = useAuthStore((s) => s.session?.user);
  const itemCount = useCartStore((s) => s.itemCount());
  const compareCount = useCompareStore((s) => s.productIds.length);
  const router = useRouter();
  const [q, setQ] = useState("");
  const [mobileSearch, setMobileSearch] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-[var(--border)] bg-[var(--background)]/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-[1400px] items-center gap-3 px-4 md:h-16 md:gap-6">
        <Logo />
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
          {publicNav.map((item) => (
            <Link
              key={item.id}
              href={item.href}
              className="rounded-md px-3 py-2 text-sm font-medium text-[var(--muted-foreground)] transition-colors hover:bg-[var(--muted)] hover:text-[var(--foreground)]"
            >
              {t(item.labelKey as never)}
            </Link>
          ))}
        </nav>

        <form
          className="mx-auto hidden min-w-0 flex-1 md:block md:max-w-xl"
          onSubmit={(e) => {
            e.preventDefault();
            router.push(q ? `/search?q=${encodeURIComponent(q)}` : "/discover");
          }}
        >
          <label className="relative block">
            <span className="sr-only">{t("nav.search")}</span>
            <Search className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[var(--muted-foreground)]" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("common.searchPlaceholder")}
              className="h-11 rounded-full border-[var(--border)] bg-[var(--muted)]/50 ps-10"
            />
          </label>
        </form>

        <div className="ms-auto flex items-center gap-0.5 sm:gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            aria-label={t("common.search")}
            onClick={() => setMobileSearch((v) => !v)}
          >
            <Search className="h-5 w-5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label={t("nav.language")}
            onClick={() => setLocale(locale === "en" ? "ar" : "en")}
          >
            <span className="text-xs font-semibold">{locale === "en" ? "ع" : "EN"}</span>
          </Button>
          <Button
            variant="ghost"
            size="icon"
            aria-label={t("nav.theme")}
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            <Sun className="h-5 w-5 rotate-0 scale-100 dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-5 w-5 rotate-90 scale-0 dark:rotate-0 dark:scale-100" />
          </Button>
          <Button asChild variant="ghost" size="icon" className="relative hidden sm:inline-flex">
            <Link href="/compare" aria-label={t("nav.compare")}>
              <GitCompareArrows className="h-5 w-5" />
              {compareCount > 0 ? <CountBadge count={compareCount} /> : null}
            </Link>
          </Button>
          <Button asChild variant="ghost" size="icon" className="hidden sm:inline-flex">
            <Link href="/account/wishlists" aria-label={t("nav.wishlist")}>
              <Heart className="h-5 w-5" />
            </Link>
          </Button>
          <Button asChild variant="ghost" size="icon" className="relative hidden md:inline-flex">
            <Link href="/account/notifications" aria-label={t("nav.notifications")}>
              <Bell className="h-5 w-5" />
            </Link>
          </Button>
          <Button asChild variant="ghost" size="icon" className="relative hidden md:inline-flex">
            <Link href="/account/messages" aria-label={t("nav.messages")}>
              <MessageCircle className="h-5 w-5" />
            </Link>
          </Button>
          <Button asChild variant="ghost" size="icon" className="relative">
            <Link href="/cart" aria-label={t("nav.cart")}>
              <ShoppingBag className="h-5 w-5" />
              {itemCount > 0 ? <CountBadge count={itemCount} /> : null}
            </Link>
          </Button>
          <Button asChild variant="ghost" size="icon">
            <Link href={user ? "/account" : "/auth/sign-in"} aria-label={t("nav.account")}>
              <User className="h-5 w-5" />
            </Link>
          </Button>
          <Button asChild variant="ghost" size="icon" className="lg:hidden">
            <Link href="/categories" aria-label={t("nav.categories")}>
              <Menu className="h-5 w-5" />
            </Link>
          </Button>
        </div>
      </div>
      {mobileSearch ? (
        <div className="border-t border-[var(--border)] px-4 py-3 md:hidden">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setMobileSearch(false);
              router.push(q ? `/search?q=${encodeURIComponent(q)}` : "/discover");
            }}
          >
            <Input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder={t("common.searchPlaceholder")}
            />
          </form>
        </div>
      ) : null}
    </header>
  );
}

function CountBadge({ count }: { count: number }) {
  return (
    <span
      className={cn(
        "absolute -end-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[var(--primary)] px-1 text-[10px] font-semibold text-[var(--primary-foreground)]"
      )}
    >
      {count > 99 ? "99+" : count}
    </span>
  );
}
