"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect } from "react";
import { useAuthStore } from "@/features/auth/store";
import { accountNavItems } from "@/features/account/account-nav";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

export function AccountShell({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  const user = useAuthStore((s) => s.session?.user);
  const hydrated = useAuthStore((s) => s.hydrated);
  const signOut = useAuthStore((s) => s.signOut);
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    if (hydrated && !user) router.replace("/auth/sign-in");
  }, [hydrated, user, router]);

  if (!hydrated || !user) {
    return (
      <div className="container-sol py-16 text-sm text-[var(--muted-foreground)]">Loading account…</div>
    );
  }

  return (
    <div className="container-sol py-6 md:py-8">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight md:text-3xl">{title}</h1>
          <p className="mt-1 text-sm text-[var(--muted-foreground)]">{user.displayName} · {user.email}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {user.roles.includes("seller") ? (
            <Button asChild variant="outline" size="sm">
              <Link href="/seller">Seller workspace</Link>
            </Button>
          ) : (
            <Button asChild variant="outline" size="sm">
              <Link href="/seller/onboarding">Become a seller</Link>
            </Button>
          )}
          {(user.roles.includes("admin") || user.roles.includes("super_admin") || user.roles.includes("moderator")) && (
            <Button asChild variant="outline" size="sm">
              <Link href="/admin">Admin</Link>
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={async () => {
              await signOut();
              router.push("/");
            }}
          >
            Sign out
          </Button>
        </div>
      </div>
      <div className="grid gap-6 lg:grid-cols-[220px_1fr]">
        <aside className="h-fit rounded-xl border border-[var(--border)] bg-[var(--card)] p-2 lg:sticky lg:top-20">
          <nav className="flex gap-1 overflow-x-auto lg:flex-col">
            {accountNavItems.map((item) => {
              const active =
                item.href === "/account"
                  ? pathname === "/account"
                  : pathname === item.href || pathname.startsWith(item.href + "/");
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "whitespace-nowrap rounded-md px-3 py-2 text-sm font-medium",
                    active
                      ? "bg-[var(--primary)] text-[var(--primary-foreground)]"
                      : "text-[var(--muted-foreground)] hover:bg-[var(--muted)] hover:text-[var(--foreground)]"
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </aside>
        <div className="min-w-0">{children}</div>
      </div>
    </div>
  );
}
