"use client";

import { Header } from "./header";
import { Footer } from "./footer";
import { MobileBottomNav } from "./mobile-nav";
import { useLocaleStore } from "@/i18n";
import { usePathname } from "next/navigation";

export function AppShell({ children }: { children: React.ReactNode }) {
  const t = useLocaleStore((s) => s.t);
  const pathname = usePathname();
  const minimal =
    pathname.startsWith("/checkout") ||
    pathname.startsWith("/auth");

  if (minimal) {
    return (
      <div className="min-h-dvh bg-[var(--background)] text-[var(--foreground)]">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-[var(--primary)] focus:px-3 focus:py-2 focus:text-[var(--primary-foreground)]"
        >
          {t("nav.skipToContent")}
        </a>
        <main id="main">{children}</main>
      </div>
    );
  }

  const isDashboard = pathname.startsWith("/seller") || pathname.startsWith("/admin");

  return (
    <div className="min-h-dvh bg-[var(--background)] text-[var(--foreground)]">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-[var(--primary)] focus:px-3 focus:py-2 focus:text-[var(--primary-foreground)]"
      >
        {t("nav.skipToContent")}
      </a>
      {!isDashboard ? <Header /> : null}
      <main id="main" className={isDashboard ? "" : "pb-20 md:pb-0"}>
        {children}
      </main>
      {!isDashboard ? <Footer /> : null}
      <MobileBottomNav />
    </div>
  );
}
