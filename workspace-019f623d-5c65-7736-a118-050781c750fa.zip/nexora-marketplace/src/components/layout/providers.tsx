"use client";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { ThemeProvider } from "./theme-provider";
import { Toaster } from "sonner";
import { useLocaleStore } from "@/i18n";
import { useCartStore } from "@/features/cart/store";

export function Providers({
  children,
  initialLocale,
}: {
  children: React.ReactNode;
  initialLocale?: "en" | "ar";
}) {
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 30_000,
            refetchOnWindowFocus: false,
            retry: 1,
          },
        },
      })
  );
  const locale = useLocaleStore((s) => s.locale);
  const setLocale = useLocaleStore((s) => s.setLocale);
  const refreshCart = useCartStore((s) => s.refresh);

  useEffect(() => {
    if (initialLocale) setLocale(initialLocale);
  }, [initialLocale, setLocale]);

  useEffect(() => {
    document.cookie = `nexora-locale=${locale}; path=/; max-age=31536000; samesite=lax`;
    document.documentElement.lang = locale;
    document.documentElement.dir = locale === "ar" ? "rtl" : "ltr";
    document.documentElement.setAttribute("dir", locale === "ar" ? "rtl" : "ltr");
  }, [locale]);

  useEffect(() => {
    void refreshCart();
  }, [refreshCart]);

  return (
    <QueryClientProvider client={client}>
      <ThemeProvider>
        {children}
        <Toaster richColors position="top-center" closeButton />
      </ThemeProvider>
    </QueryClientProvider>
  );
}
