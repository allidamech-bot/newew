"use client";

import Link from "next/link";
import { Logo } from "./logo";
import { footerNav } from "@/config/navigation";
import { brand } from "@/config/brand";
import { useLocaleStore } from "@/i18n";

export function Footer() {
  const t = useLocaleStore((s) => s.t);
  const locale = useLocaleStore((s) => s.locale);
  const groups = [
    { title: t("footer.shop"), items: footerNav.shop },
    { title: t("footer.sell"), items: footerNav.sell },
    { title: t("footer.support"), items: footerNav.support },
    { title: t("footer.company"), items: footerNav.company },
  ];

  return (
    <footer className="mt-16 border-t border-[var(--border)] bg-[var(--muted)]/30">
      <div className="mx-auto grid max-w-[1400px] gap-10 px-4 py-12 md:grid-cols-[1.2fr_2fr]">
        <div>
          <Logo />
          <p className="mt-3 max-w-sm text-sm text-[var(--muted-foreground)]">
            {brand.tagline[locale]}
          </p>
          <p className="mt-4 text-xs text-[var(--muted-foreground)]">
            {brand.supportEmail}
          </p>
        </div>
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
          {groups.map((group) => (
            <div key={group.title}>
              <h3 className="text-sm font-semibold">{group.title}</h3>
              <ul className="mt-3 space-y-2">
                {group.items.map((item) => (
                  <li key={item.href}>
                    <Link
                      href={item.href}
                      className="text-sm text-[var(--muted-foreground)] hover:text-[var(--foreground)]"
                    >
                      {t(item.labelKey as never)}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
      <div className="border-t border-[var(--border)] py-4 text-center text-xs text-[var(--muted-foreground)]">
        © {new Date().getFullYear()} {brand.name}. {t("footer.rights")}
      </div>
    </footer>
  );
}
