import Link from "next/link";
import { brand } from "@/config/brand";
import { cn } from "@/lib/utils";

export function Logo({ className, compact }: { className?: string; compact?: boolean }) {
  return (
    <Link
      href="/"
      className={cn("inline-flex items-center gap-2.5 font-semibold tracking-tight", className)}
      aria-label={brand.name}
    >
      <span className="relative flex h-8 w-8 items-center justify-center" aria-hidden>
        <svg viewBox="0 0 32 32" className="h-8 w-8">
          <rect width="32" height="32" rx="8" className="fill-[var(--primary)]" />
          <path
            d="M8 21c3.2-7 6.2-10.5 9.5-10.5 2.6 0 4.2 1.8 4.2 4.1 0 3.8-3.8 6.3-8.7 8.1"
            fill="none"
            stroke="white"
            strokeWidth="2.2"
            strokeLinecap="round"
          />
          <path d="M18.5 9.5h5.2" stroke="white" strokeWidth="2.2" strokeLinecap="round" />
          <circle cx="23.2" cy="9.5" r="1.6" className="fill-white" />
        </svg>
      </span>
      {!compact ? <span className="text-lg">{brand.name}</span> : null}
    </Link>
  );
}
