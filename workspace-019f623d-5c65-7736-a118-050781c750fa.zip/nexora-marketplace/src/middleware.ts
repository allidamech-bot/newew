import { NextResponse, type NextRequest } from "next/server";
import { updateSession } from "@/lib/supabase/middleware";

const protectedPrefixes = ["/account", "/checkout", "/seller", "/admin"];
const sellerPrefixes = ["/seller"];
const adminPrefixes = ["/admin"];

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const needsAuth = protectedPrefixes.some((p) => pathname === p || pathname.startsWith(p + "/"));

  // Security headers for all responses
  const applyHeaders = (res: NextResponse) => {
    res.headers.set("X-Frame-Options", "DENY");
    res.headers.set("X-Content-Type-Options", "nosniff");
    res.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
    res.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    res.headers.set(
      "Content-Security-Policy",
      "default-src 'self'; img-src 'self' data: blob: https:; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; connect-src 'self' https:; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    );
    return res;
  };

  const provider = process.env.NEXT_PUBLIC_DATA_PROVIDER || "mock";

  if (provider !== "supabase") {
    // Mock mode: allow client shells to enforce roles after hydration.
    // Still attach security headers.
    return applyHeaders(NextResponse.next());
  }

  const { response, user, supabase } = await updateSession(request);
  applyHeaders(response);

  if (!needsAuth) return response;

  if (!user) {
    const url = request.nextUrl.clone();
    url.pathname = "/auth/sign-in";
    url.searchParams.set("next", pathname);
    return applyHeaders(NextResponse.redirect(url));
  }

  // Load roles for route authorization
  if (sellerPrefixes.some((p) => pathname === p || pathname.startsWith(p + "/"))) {
    if (pathname.startsWith("/seller/onboarding")) return response;
    const { data } = await supabase!
      .from("user_roles")
      .select("roles(key)")
      .eq("user_id", user.id);
    const roles = (data || [])
      .map((row) => {
        const nested = row.roles as { key?: string } | { key?: string }[] | null;
        if (Array.isArray(nested)) return nested[0]?.key;
        return nested?.key;
      })
      .filter(Boolean) as string[];
    if (!roles.some((r) => ["seller", "store_staff", "admin", "super_admin"].includes(r))) {
      const url = request.nextUrl.clone();
      url.pathname = "/seller/onboarding";
      return applyHeaders(NextResponse.redirect(url));
    }
  }

  if (adminPrefixes.some((p) => pathname === p || pathname.startsWith(p + "/"))) {
    const { data } = await supabase!
      .from("user_roles")
      .select("roles(key)")
      .eq("user_id", user.id);
    const roles = (data || [])
      .map((row) => {
        const nested = row.roles as { key?: string } | { key?: string }[] | null;
        if (Array.isArray(nested)) return nested[0]?.key;
        return nested?.key;
      })
      .filter(Boolean) as string[];
    if (!roles.some((r) => ["admin", "super_admin", "moderator"].includes(r))) {
      const url = request.nextUrl.clone();
      url.pathname = "/account";
      return applyHeaders(NextResponse.redirect(url));
    }
  }

  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|images/|.*\\..*).*)"],
};
