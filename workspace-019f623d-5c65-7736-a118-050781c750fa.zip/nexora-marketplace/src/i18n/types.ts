/** Deeply maps a translation tree so leaf values are plain strings (not string literals). */
export type DeepStringify<T> = T extends string
  ? string
  : T extends readonly unknown[]
    ? { [K in keyof T]: DeepStringify<T[K]> }
    : T extends object
      ? { [K in keyof T]: DeepStringify<T[K]> }
      : T;
