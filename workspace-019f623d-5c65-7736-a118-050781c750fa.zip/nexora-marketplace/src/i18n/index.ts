"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { en } from "./en/common";
import { ar } from "./ar/common";
import type { DeepStringify } from "./types";
import type { Locale } from "@/config/brand";
import { platform } from "@/config/platform";

export type TranslationKeys = DeepStringify<typeof en>;

const dictionaries: Record<Locale, TranslationKeys> = { en, ar };

type NestedKeyOf<T, Prefix extends string = ""> = T extends object
  ? {
      [K in keyof T & string]: T[K] extends object
        ? NestedKeyOf<T[K], Prefix extends "" ? K : `${Prefix}.${K}`>
        : Prefix extends ""
          ? K
          : `${Prefix}.${K}`;
    }[keyof T & string]
  : never;

export type I18nKey = NestedKeyOf<TranslationKeys>;

function getByPath(obj: unknown, path: string): string | undefined {
  const parts = path.split(".");
  let current: unknown = obj;
  for (const part of parts) {
    if (current == null || typeof current !== "object") return undefined;
    current = (current as Record<string, unknown>)[part];
  }
  return typeof current === "string" ? current : undefined;
}

type LocaleState = {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: I18nKey, vars?: Record<string, string | number>) => string;
  dir: () => "ltr" | "rtl";
};

export const useLocaleStore = create<LocaleState>()(
  persist(
    (set, get) => ({
      locale: platform.defaultLocale,
      setLocale: (locale) => {
        set({ locale });
        if (typeof document !== "undefined") {
          document.documentElement.lang = locale;
          document.documentElement.dir = locale === "ar" ? "rtl" : "ltr";
        }
      },
      t: (key, vars) => {
        const locale = get().locale;
        const dict = dictionaries[locale] ?? dictionaries.en;
        let value = getByPath(dict, key) ?? getByPath(dictionaries.en, key) ?? key;
        if (vars) {
          for (const [k, v] of Object.entries(vars)) {
            value = value.replace(new RegExp(`\\{${k}\\}`, "g"), String(v));
          }
        }
        return value;
      },
      dir: () => (get().locale === "ar" ? "rtl" : "ltr"),
    }),
    { name: platform.localeKey, partialize: (s) => ({ locale: s.locale }) }
  )
);

export function tStatic(locale: Locale, key: I18nKey, vars?: Record<string, string | number>) {
  const dict = dictionaries[locale] ?? dictionaries.en;
  let value = getByPath(dict, key) ?? getByPath(dictionaries.en, key) ?? key;
  if (vars) {
    for (const [k, v] of Object.entries(vars)) {
      value = value.replace(new RegExp(`\\{${k}\\}`, "g"), String(v));
    }
  }
  return value;
}

export function localize<T extends { en: string; ar: string }>(
  value: T,
  locale: Locale
): string {
  return value[locale] || value.en;
}

export { dictionaries };
