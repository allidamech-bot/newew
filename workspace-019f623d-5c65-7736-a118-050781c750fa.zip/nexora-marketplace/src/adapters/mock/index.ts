import { AppError } from "@/lib/errors";
import { fromMajor, money, multiplyMoney, percentOf, sumMoney, toMajor } from "@/lib/money";
import { createId, getOrCreateCart, mockDb, persistMockDb } from "@/mocks/db";
import {
  fulfillReservedStock,
  getAvailableForSale,
  manualAdjustOnHand,
  recordDamagedReturn,
  releaseCheckoutReservation,
  reserveForCheckout,
  restockReturned,
  syncSeedInventoryFromProducts,
} from "@/mocks/inventory-ops";
import {
  assertOrderTransition,
  FULFILLED_STATUSES,
  PRE_FULFILLMENT_STATUSES,
  type OrderTransitionActor,
} from "@/lib/inventory";
import type {
  AnalyticsRepository,
  AuditRepository,
  AuthRepository,
  BrandRepository,
  CartRepository,
  CatalogRepository,
  CategoryRepository,
  CmsRepository,
  ConversationRepository,
  DisputeRepository,
  InventoryRepository,
  ModerationRepository,
  NotificationRepository,
  OfferRepository,
  OrderRepository,
  PaymentProvider,
  ProfileRepository,
  PromotionRepository,
  ReturnsRepository,
  ReviewRepository,
  SearchProvider,
  ShippingProvider,
  StoreRepository,
  WishlistRepository,
  MediaStorageProvider,
} from "@/repositories/types";
import type {
  CartItem,
  Category,
  Order,
  OrderStatus,
  Product,
  Session,
  UserProfile,
} from "@/types";
import { slugify } from "@/lib/utils";
import { mockAdminManagementRepository, mockSellerManagementRepository } from "./management";
import type { MarketplaceServices } from "@/services/contract";

const delay = async () => {
  await new Promise((r) => setTimeout(r, 20 + Math.random() * 40));
};

// Normalize seed inventory to on_hand/reserved model once at module load.
syncSeedInventoryFromProducts();

function touch() {
  persistMockDb();
}

function actorFromRoles(roles: string[] | undefined): OrderTransitionActor {
  if (!roles?.length) return "system";
  if (roles.includes("admin") || roles.includes("super_admin")) return "admin";
  if (roles.includes("moderator")) return "moderator";
  if (roles.includes("seller")) return "seller";
  if (roles.includes("store_staff")) return "store_staff";
  if (roles.includes("buyer")) return "buyer";
  return "system";
}

function paginate<T>(items: T[], page = 1, pageSize = 24) {
  const start = (page - 1) * pageSize;
  const slice = items.slice(start, start + pageSize);
  return {
    items: slice,
    total: items.length,
    page,
    pageSize,
    hasMore: start + pageSize < items.length,
  };
}

export const mockAuthRepository: AuthRepository = {
  async signIn(email, password) {
    await delay();
    const user = mockDb.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user || mockDb.demoPasswords[user.email] !== password) {
      throw new AppError("UNAUTHORIZED", "Invalid email or password", { status: 401 });
    }
    if (user.status === "suspended") {
      throw new AppError("FORBIDDEN", "Account suspended", { status: 403 });
    }
    const session: Session = {
      user,
      accessToken: createId("tok"),
      expiresAt: new Date(Date.now() + 1000 * 60 * 60 * 24).toISOString(),
    };
    mockDb.sessions.set(session.accessToken, session);
    return session;
  },
  async signUp({ email, password, firstName, lastName }) {
    await delay();
    if (mockDb.users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
      throw new AppError("CONFLICT", "An account with this email already exists", { status: 409 });
    }
    if (password.length < 8) {
      throw new AppError("VALIDATION", "Password too short", {
        fieldErrors: { password: ["At least 8 characters"] },
      });
    }
    const user: UserProfile = {
      id: createId("user"),
      email,
      displayName: `${firstName} ${lastName}`.trim(),
      firstName,
      lastName,
      roles: ["buyer"],
      locale: "en",
      currency: "USD",
      status: "active",
      emailVerified: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    mockDb.users.push(user);
    mockDb.demoPasswords[email] = password;
    return this.signIn(email, password);
  },
  async signOut(token) {
    await delay();
    mockDb.sessions.delete(token);
  },
  async getSession(token) {
    await delay();
    return mockDb.sessions.get(token) ?? null;
  },
  async requestPasswordReset(email) {
    await delay();
    const user = mockDb.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user) return { ok: true };
    return { ok: true };
  },
  async listDemoAccounts() {
    return [
      { email: "buyer@sol.demo", role: "buyer" },
      { email: "seller@sol.demo", role: "seller" },
      { email: "staff@sol.demo", role: "store_staff" },
      { email: "moderator@sol.demo", role: "moderator" },
      { email: "admin@sol.demo", role: "admin" },
      { email: "super@sol.demo", role: "super_admin" },
    ];
  },
};

export const mockProfileRepository: ProfileRepository = {
  async getById(id) {
    await delay();
    return mockDb.users.find((u) => u.id === id) ?? null;
  },
  async update(id, patch) {
    await delay();
    const idx = mockDb.users.findIndex((u) => u.id === id);
    if (idx < 0) throw new AppError("NOT_FOUND", "User not found");
    mockDb.users[idx] = {
      ...mockDb.users[idx],
      ...patch,
      id,
      updatedAt: new Date().toISOString(),
    };
    return mockDb.users[idx];
  },
  async listAddresses(userId) {
    await delay();
    return mockDb.addresses.filter((a) => a.userId === userId);
  },
  async createAddress(address) {
    await delay();
    const created = { ...address, id: createId("addr") };
    if (created.isDefault) {
      mockDb.addresses = mockDb.addresses.map((a) =>
        a.userId === created.userId ? { ...a, isDefault: false } : a
      );
    }
    mockDb.addresses.push(created);
    return created;
  },
  async updateAddress(id, patch) {
    await delay();
    const idx = mockDb.addresses.findIndex((a) => a.id === id);
    if (idx < 0) throw new AppError("NOT_FOUND", "Address not found");
    mockDb.addresses[idx] = { ...mockDb.addresses[idx], ...patch, id };
    return mockDb.addresses[idx];
  },
  async deleteAddress(id) {
    await delay();
    mockDb.addresses = mockDb.addresses.filter((a) => a.id !== id);
  },
};

export const mockCatalogRepository: CatalogRepository = {
  async listProducts(params) {
    await delay();
    let items = mockDb.products.filter((p) => p.status === "published" || p.status === "out_of_stock");
    const filters = params?.filters;
    if (filters?.categoryId) {
      const childIds = mockDb.categories
        .filter((c) => c.parentId === filters.categoryId || c.id === filters.categoryId)
        .map((c) => c.id);
      items = items.filter((p) => childIds.includes(p.categoryId) || p.categoryId === filters.categoryId);
    }
    if (filters?.storeId) items = items.filter((p) => p.storeId === filters.storeId);
    if (filters?.minPrice != null) items = items.filter((p) => toMajor(p.basePrice) >= filters.minPrice!);
    if (filters?.maxPrice != null) items = items.filter((p) => toMajor(p.basePrice) <= filters.maxPrice!);
    if (filters?.minRating != null) items = items.filter((p) => p.rating >= filters.minRating!);
    if (filters?.inStockOnly) items = items.filter((p) => p.quantity > 0 && p.status !== "out_of_stock");
    if (filters?.onSale) items = items.filter((p) => !!p.compareAtPrice && p.compareAtPrice.amount > p.basePrice.amount);
    if (filters?.productTypes?.length) items = items.filter((p) => filters.productTypes!.includes(p.type));
    if (filters?.verifiedSellersOnly) {
      const verified = new Set(
        mockDb.stores.filter((s) => s.verificationStatus === "verified").map((s) => s.id)
      );
      items = items.filter((p) => verified.has(p.storeId));
    }
    if (params?.query) {
      const q = params.query.toLowerCase();
      items = items.filter(
        (p) =>
          p.title.en.toLowerCase().includes(q) ||
          p.title.ar.includes(q) ||
          p.tags.some((t) => t.includes(q)) ||
          p.description.en.toLowerCase().includes(q)
      );
    }
    switch (params?.sort) {
      case "price_asc":
        items = [...items].sort((a, b) => a.basePrice.amount - b.basePrice.amount);
        break;
      case "price_desc":
        items = [...items].sort((a, b) => b.basePrice.amount - a.basePrice.amount);
        break;
      case "newest":
        items = [...items].sort((a, b) => (b.publishedAt || b.createdAt).localeCompare(a.publishedAt || a.createdAt));
        break;
      case "rating":
        items = [...items].sort((a, b) => b.rating - a.rating);
        break;
      case "best_selling":
        items = [...items].sort((a, b) => b.salesCount - a.salesCount);
        break;
      case "discount":
        items = [...items].sort((a, b) => {
          const da = a.compareAtPrice ? a.compareAtPrice.amount - a.basePrice.amount : 0;
          const db = b.compareAtPrice ? b.compareAtPrice.amount - b.basePrice.amount : 0;
          return db - da;
        });
        break;
      default:
        items = [...items].sort((a, b) => b.salesCount * b.rating - a.salesCount * a.rating);
    }
    return paginate(items, params?.page, params?.pageSize);
  },
  async getProductBySlug(slug) {
    await delay();
    return mockDb.products.find((p) => p.slug === slug) ?? null;
  },
  async getProductById(id) {
    await delay();
    return mockDb.products.find((p) => p.id === id) ?? null;
  },
  async listRelated(productId, limit = 8) {
    await delay();
    const product = mockDb.products.find((p) => p.id === productId);
    if (!product) return [];
    return mockDb.products
      .filter(
        (p) =>
          p.id !== productId &&
          p.status === "published" &&
          (p.categoryId === product.categoryId || p.storeId === product.storeId)
      )
      .slice(0, limit);
  },
  async createProduct(input) {
    await delay();
    const product: Product = {
      id: createId("prod"),
      storeId: input.storeId,
      sellerId: input.sellerId,
      categoryId: input.categoryId || "cat-home",
      type: input.type,
      slug: input.slug || slugify(input.title.en),
      title: input.title,
      description: input.description || { en: "", ar: "" },
      shortDescription: input.shortDescription || { en: "", ar: "" },
      status: input.status || "draft",
      moderationStatus: "pending",
      visibility: "public",
      condition: input.condition || "new",
      basePrice: input.basePrice || fromMajor(0),
      currency: "USD",
      quantity: input.quantity ?? 0,
      reservedQuantity: 0,
      lowStockThreshold: 5,
      inventoryPolicy: "deny",
      requiresShipping: input.type === "physical" || input.type === "made_to_order" || input.type === "preorder",
      tags: input.tags || [],
      media: input.media || [],
      attributes: input.attributes || {},
      variantOptions: input.variantOptions || [],
      variants: input.variants || [],
      rating: 0,
      reviewCount: 0,
      salesCount: 0,
      featured: false,
      offersEnabled: !!input.offersEnabled,
      processingDays: input.processingDays ?? 2,
      returnDays: 14,
      relatedProductIds: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    mockDb.products.unshift(product);
    return product;
  },
  async updateProduct(id, patch) {
    await delay();
    const idx = mockDb.products.findIndex((p) => p.id === id);
    if (idx < 0) throw new AppError("NOT_FOUND", "Product not found");
    mockDb.products[idx] = {
      ...mockDb.products[idx],
      ...patch,
      id,
      updatedAt: new Date().toISOString(),
    };
    return mockDb.products[idx];
  },
  async listByStore(storeId, params) {
    await delay();
    const items = mockDb.products.filter((p) => p.storeId === storeId);
    return paginate(items, params?.page, params?.pageSize);
  },
};

export const mockCategoryRepository: CategoryRepository = {
  async list() {
    await delay();
    return mockDb.categories.filter((c) => c.visible);
  },
  async getBySlug(slug) {
    await delay();
    return mockDb.categories.find((c) => c.slug === slug) ?? null;
  },
  async getTree() {
    await delay();
    const roots = mockDb.categories.filter((c) => !c.parentId && c.visible);
    return roots.map((root) => ({
      ...root,
      children: mockDb.categories.filter((c) => c.parentId === root.id && c.visible),
    }));
  },
  async listAttributes(categoryId) {
    await delay();
    const cat = mockDb.categories.find((c) => c.id === categoryId);
    if (!cat) return [];
    return mockDb.attributes.filter((a) => cat.attributeIds.includes(a.id));
  },
  async listAllAttributes() {
    await delay();
    return mockDb.attributes;
  },
  async createCategory(input) {
    await delay();
    const cat: Category = {
      id: createId("cat"),
      parentId: input.parentId ?? null,
      slug: input.slug,
      name: input.name,
      description: input.description || { en: "", ar: "" },
      sortOrder: input.sortOrder ?? 99,
      featured: !!input.featured,
      visible: input.visible ?? true,
      productTypes: input.productTypes || ["physical"],
      attributeIds: input.attributeIds || [],
    };
    mockDb.categories.push(cat);
    return cat;
  },
  async updateCategory(id, patch) {
    await delay();
    const idx = mockDb.categories.findIndex((c) => c.id === id);
    if (idx < 0) throw new AppError("NOT_FOUND", "Category not found");
    mockDb.categories[idx] = { ...mockDb.categories[idx], ...patch, id };
    return mockDb.categories[idx];
  },
};

export const mockStoreRepository: StoreRepository = {
  async list(params) {
    await delay();
    let items = mockDb.stores.filter((s) => s.status === "active");
    if (params?.query) {
      const q = params.query.toLowerCase();
      items = items.filter(
        (s) => s.name.toLowerCase().includes(q) || s.description.en.toLowerCase().includes(q)
      );
    }
    return paginate(items, params?.page, params?.pageSize);
  },
  async getBySlug(slug) {
    await delay();
    return mockDb.stores.find((s) => s.slug === slug) ?? null;
  },
  async getById(id) {
    await delay();
    return mockDb.stores.find((s) => s.id === id) ?? null;
  },
  async listByOwner(ownerId) {
    await delay();
    return mockDb.stores.filter((s) => s.ownerId === ownerId);
  },
  async follow(userId, storeId) {
    await delay();
    if (!mockDb.follows.some((f) => f.userId === userId && f.storeId === storeId)) {
      mockDb.follows.push({ userId, storeId, createdAt: new Date().toISOString() });
      const store = mockDb.stores.find((s) => s.id === storeId);
      if (store) store.followersCount += 1;
    }
  },
  async unfollow(userId, storeId) {
    await delay();
    mockDb.follows = mockDb.follows.filter((f) => !(f.userId === userId && f.storeId === storeId));
  },
  async listFollowed(userId) {
    await delay();
    const ids = mockDb.follows.filter((f) => f.userId === userId).map((f) => f.storeId);
    return mockDb.stores.filter((s) => ids.includes(s.id));
  },
  async updateStore(id, patch) {
    await delay();
    const idx = mockDb.stores.findIndex((s) => s.id === id);
    if (idx < 0) throw new AppError("NOT_FOUND", "Store not found");
    mockDb.stores[idx] = { ...mockDb.stores[idx], ...patch, id };
    return mockDb.stores[idx];
  },
};

export const mockBrandRepository: BrandRepository = {
  async list() {
    await delay();
    return mockDb.brands;
  },
};

export const mockCartRepository: CartRepository = {
  async getCart(key) {
    await delay();
    return getOrCreateCart(key);
  },
  async addItem(key, item) {
    await delay();
    const cart = getOrCreateCart(key);
    const product = mockDb.products.find((p) => p.id === item.productId);
    if (!product || (product.status !== "published" && product.status !== "out_of_stock")) {
      throw new AppError("PRODUCT_UNAVAILABLE", "Product unavailable");
    }
    const variant = item.variantId
      ? product.variants.find((v) => v.id === item.variantId)
      : undefined;
    if (item.variantId && !variant) {
      throw new AppError("PRODUCT_UNAVAILABLE", "Variant unavailable");
    }
    const available = getAvailableForSale(product.id, item.variantId);
    if (available <= 0) throw new AppError("INVENTORY_CONFLICT", "Out of stock");
    const existing = cart.items.find(
      (i) => i.productId === item.productId && i.variantId === item.variantId && !i.savedForLater
    );
    const unitPrice = variant?.price || product.basePrice;
    const maxQuantity = Math.max(1, available);
    if (existing) {
      existing.quantity = Math.min(maxQuantity, existing.quantity + item.quantity);
      existing.unitPrice = unitPrice;
    } else {
      const cartItem: CartItem = {
        id: createId("ci"),
        productId: product.id,
        variantId: variant?.id,
        storeId: product.storeId,
        quantity: Math.min(maxQuantity, item.quantity),
        unitPrice,
        title: product.title,
        imageUrl: product.media[0]?.url,
        maxQuantity,
        notes: item.notes,
      };
      cart.items.push(cartItem);
    }
    cart.updatedAt = new Date().toISOString();
    return cart;
  },
  async updateItem(key, itemId, quantity) {
    await delay();
    const cart = getOrCreateCart(key);
    const item = cart.items.find((i) => i.id === itemId);
    if (!item) throw new AppError("NOT_FOUND", "Cart item not found");
    if (quantity <= 0) {
      cart.items = cart.items.filter((i) => i.id !== itemId);
    } else {
      item.quantity = Math.min(item.maxQuantity, quantity);
    }
    cart.updatedAt = new Date().toISOString();
    return cart;
  },
  async removeItem(key, itemId) {
    await delay();
    const cart = getOrCreateCart(key);
    cart.items = cart.items.filter((i) => i.id !== itemId);
    cart.updatedAt = new Date().toISOString();
    return cart;
  },
  async applyCoupon(key, code) {
    await delay();
    const cart = getOrCreateCart(key);
    const promo = mockDb.promotions.find(
      (p) => p.code?.toLowerCase() === code.toLowerCase() && p.active
    );
    if (!promo) throw new AppError("VALIDATION", "Invalid coupon code");
    cart.couponCode = promo.code;
    cart.updatedAt = new Date().toISOString();
    return cart;
  },
  async clearCoupon(key) {
    await delay();
    const cart = getOrCreateCart(key);
    cart.couponCode = undefined;
    cart.updatedAt = new Date().toISOString();
    return cart;
  },
  async mergeGuestCart(guestKey, userId) {
    await delay();
    const guest = getOrCreateCart(guestKey);
    const userCart = getOrCreateCart(`user:${userId}`, userId);
    for (const item of guest.items) {
      const existing = userCart.items.find(
        (i) => i.productId === item.productId && i.variantId === item.variantId
      );
      if (existing) {
        existing.quantity = Math.min(existing.maxQuantity, existing.quantity + item.quantity);
      } else {
        userCart.items.push({ ...item, id: createId("ci") });
      }
    }
    guest.items = [];
    userCart.updatedAt = new Date().toISOString();
    return userCart;
  },
  async saveForLater(key, itemId) {
    await delay();
    const cart = getOrCreateCart(key);
    const item = cart.items.find((i) => i.id === itemId);
    if (item) item.savedForLater = true;
    cart.updatedAt = new Date().toISOString();
    return cart;
  },
};

export const mockOrderRepository: OrderRepository = {
  async createFromCart(input) {
    await delay();
    if (mockDb.idempotency.has(input.idempotencyKey)) {
      const existingId = mockDb.idempotency.get(input.idempotencyKey)!;
      return mockDb.orders.filter((o) => o.groupId === existingId);
    }
    const cart = getOrCreateCart(input.cartKey, input.buyerId);
    const activeItems = cart.items.filter((i) => !i.savedForLater);
    if (!activeItems.length) throw new AppError("VALIDATION", "Cart is empty");
    const address = mockDb.addresses.find((a) => a.id === input.addressId && a.userId === input.buyerId);
    if (!address) throw new AppError("VALIDATION", "Address required");

    const byStore = activeItems.reduce<Record<string, CartItem[]>>((acc, item) => {
      (acc[item.storeId] ??= []).push(item);
      return acc;
    }, {});

    const groupId = createId("grp");
    const created: Order[] = [];
    const now = new Date().toISOString();

    for (const [storeId, items] of Object.entries(byStore)) {
      const store = mockDb.stores.find((s) => s.id === storeId);
      if (!store || store.status !== "active") {
        throw new AppError("PRODUCT_UNAVAILABLE", "A store is unavailable");
      }

      // Validate + reserve (reserved++ only; on_hand unchanged)
      for (const item of items) {
        const product = mockDb.products.find((p) => p.id === item.productId);
        if (
          !product ||
          product.status !== "published" ||
          product.moderationStatus !== "approved" ||
          product.visibility !== "public"
        ) {
          throw new AppError("PRODUCT_UNAVAILABLE", "A product is unavailable");
        }
        if (product.sellerId === input.buyerId || store.ownerId === input.buyerId) {
          throw new AppError("FORBIDDEN", "Sellers cannot purchase their own products");
        }
        const variant = item.variantId
          ? product.variants.find((v) => v.id === item.variantId)
          : undefined;
        if (item.variantId && (!variant || !variant.enabled)) {
          throw new AppError("PRODUCT_UNAVAILABLE", "Variant unavailable");
        }
        const currentUnit = variant?.price || product.basePrice;
        if (currentUnit.amount !== item.unitPrice.amount || currentUnit.currency !== item.unitPrice.currency) {
          throw new AppError("PRICE_CHANGED", `${product.title.en} price changed`);
        }
        const available = getAvailableForSale(product.id, item.variantId);
        if (available < item.quantity) {
          throw new AppError("INVENTORY_CONFLICT", `${product.title.en} has insufficient stock`);
        }
        reserveForCheckout(
          product.id,
          item.variantId,
          item.quantity,
          input.buyerId,
          `reserve for checkout group ${groupId}`
        );
      }

      const lineTotals = items.map((i) => multiplyMoney(i.unitPrice, i.quantity));
      const subtotal = sumMoney(lineTotals, "USD");
      let discount = money(0);
      if (cart.couponCode) {
        const promo = mockDb.promotions.find((p) => p.code === cart.couponCode && p.active);
        if (!promo) throw new AppError("VALIDATION", "Coupon is no longer valid");
        if (promo.minOrder && subtotal.amount < promo.minOrder.amount) {
          throw new AppError("VALIDATION", "Order does not meet coupon minimum");
        }
        if (promo.type === "percentage") {
          discount = percentOf(subtotal, promo.value);
          if (promo.maxDiscount && discount.amount > promo.maxDiscount.amount) {
            discount = promo.maxDiscount;
          }
        } else if (promo.type === "fixed") {
          discount = money(Math.min(subtotal.amount, Math.round(promo.value * 100)));
        }
        promo.usageCount += 1;
      }
      const shippingMethod =
        mockDb.shippingMethods.find((m) => m.id === input.shippingMethodId) ||
        mockDb.shippingMethods[0];
      let shipping = shippingMethod.price;
      if (shippingMethod.freeAbove && subtotal.amount >= shippingMethod.freeAbove.amount) {
        shipping = money(0);
      }
      if (
        items.every((i) => {
          const p = mockDb.products.find((x) => x.id === i.productId);
          return p && !p.requiresShipping;
        })
      ) {
        shipping = money(0);
      }
      const taxable = money(Math.max(0, subtotal.amount - discount.amount + shipping.amount));
      const tax = percentOf(taxable, 8);
      const total = money(taxable.amount + tax.amount);
      const order: Order = {
        id: createId("ord"),
        orderNumber: `NXR-${100000 + mockDb.orders.length + created.length + 1}`,
        groupId,
        buyerId: input.buyerId,
        storeId,
        sellerId: store.ownerId,
        status: "paid",
        paymentStatus: "paid",
        items: items.map((i) => {
          const product = mockDb.products.find((p) => p.id === i.productId)!;
          const variant = i.variantId
            ? product.variants.find((v) => v.id === i.variantId)
            : undefined;
          return {
            id: createId("oi"),
            productId: i.productId,
            variantId: i.variantId,
            title: i.title,
            imageUrl: i.imageUrl,
            quantity: i.quantity,
            unitPrice: i.unitPrice,
            total: multiplyMoney(i.unitPrice, i.quantity),
            sku: variant?.sku || product.sku,
            attributesSnapshot: Object.fromEntries(
              Object.entries(product.attributes).map(([k, v]) => [k, String(v)])
            ),
          };
        }),
        subtotal,
        discount,
        shipping,
        tax,
        fees: money(0),
        total,
        currency: "USD",
        shippingAddress: structuredClone(address),
        shippingMethod: shippingMethod.name.en,
        couponCode: cart.couponCode,
        timeline: [
          { status: "paid", at: now, note: "Payment confirmed" },
          { status: "confirmed", at: now, note: "Order confirmed" },
        ],
        createdAt: now,
        updatedAt: now,
      };
      created.push(order);
      mockDb.orders.unshift(order);
      mockDb.notifications.unshift({
        id: createId("ntf"),
        userId: store.ownerId,
        category: "orders",
        title: { en: "New order", ar: "طلب جديد" },
        body: {
          en: `${order.orderNumber} needs fulfillment.`,
          ar: `${order.orderNumber} يحتاج تنفيذاً.`,
        },
        href: `/seller/orders/${order.id}`,
        read: false,
        createdAt: now,
      });
    }

    cart.items = cart.items.filter((i) => i.savedForLater);
    cart.couponCode = undefined;
    cart.updatedAt = now;
    mockDb.idempotency.set(input.idempotencyKey, groupId);
    mockDb.notifications.unshift({
      id: createId("ntf"),
      userId: input.buyerId,
      category: "orders",
      title: { en: "Order confirmed", ar: "تم تأكيد الطلب" },
      body: {
        en: `Your order group is confirmed.`,
        ar: `تم تأكيد مجموعة طلبك.`,
      },
      href: `/account/orders`,
      read: false,
      createdAt: now,
    });
    touch();
    return created;
  },
  async listByBuyer(buyerId) {
    await delay();
    return mockDb.orders.filter((o) => o.buyerId === buyerId);
  },
  async listByStore(storeId) {
    await delay();
    return mockDb.orders.filter((o) => o.storeId === storeId);
  },
  async getById(id) {
    await delay();
    return mockDb.orders.find((o) => o.id === id) ?? null;
  },
  async updateStatus(id, status, note) {
    await delay();
    const idx = mockDb.orders.findIndex((o) => o.id === id);
    if (idx < 0) throw new AppError("NOT_FOUND", "Order not found");
    const order = mockDb.orders[idx];
    const actor: OrderTransitionActor =
      note?.includes("buyer") ? "buyer" : note?.includes("system") ? "system" : "seller";
    assertOrderTransition(order.status, status, actor);

    const prev = order.status;
    // Fulfillment: when moving into shipped/partially_shipped first time, consume reserved stock
    if (
      (status === "shipped" || status === "partially_shipped") &&
      PRE_FULFILLMENT_STATUSES.has(prev)
    ) {
      for (const item of order.items) {
        fulfillReservedStock(
          item.productId,
          item.variantId,
          item.quantity,
          order.sellerId,
          `fulfill order ${order.orderNumber}`
        );
      }
    }

    // Cancellation before fulfillment: release reserved only
    if (status === "cancelled" && PRE_FULFILLMENT_STATUSES.has(prev)) {
      for (const item of order.items) {
        releaseCheckoutReservation(
          item.productId,
          item.variantId,
          item.quantity,
          order.buyerId,
          `cancel order ${order.orderNumber}`
        );
      }
    }

    order.status = status;
    order.updatedAt = new Date().toISOString();
    order.timeline.push({ status, at: order.updatedAt, note });
    if (status === "shipped" && !order.trackingNumber) {
      order.trackingNumber = `TRK${Date.now().toString().slice(-8)}`;
    }
    if (status === "delivered" || status === "completed") {
      order.deliveredAt = order.deliveredAt || order.updatedAt;
    }
    mockDb.notifications.unshift({
      id: createId("ntf"),
      userId: order.buyerId,
      category: "orders",
      title: { en: "Order updated", ar: "تم تحديث الطلب" },
      body: {
        en: `${order.orderNumber} is now ${status.replaceAll("_", " ")}.`,
        ar: `${order.orderNumber} أصبح ${status}.`,
      },
      href: `/account/orders/${order.id}`,
      read: false,
      createdAt: order.updatedAt,
    });
    touch();
    return order;
  },
  async cancel(id, buyerId) {
    await delay();
    const order = mockDb.orders.find((o) => o.id === id && o.buyerId === buyerId);
    if (!order) throw new AppError("NOT_FOUND", "Order not found");
    if (!PRE_FULFILLMENT_STATUSES.has(order.status) && order.status !== "cancellation_requested") {
      throw new AppError("CONFLICT", "Order cannot be cancelled after fulfillment");
    }
    // Idempotent: already cancelled
    if (order.status === "cancelled") return order;
    return this.updateStatus(id, "cancelled", "Cancelled by buyer");
  },
};

export const mockReviewRepository: ReviewRepository = {
  async listByProduct(productId) {
    await delay();
    return mockDb.reviews.filter((r) => r.productId === productId && r.moderationStatus === "approved");
  },
  async listByStore(storeId) {
    await delay();
    return mockDb.reviews.filter((r) => r.storeId === storeId && r.moderationStatus === "approved");
  },
  async listByBuyer(buyerId) {
    await delay();
    return mockDb.reviews.filter((r) => r.buyerId === buyerId);
  },
  async create(input) {
    await delay();
    const existing = mockDb.reviews.find((r) => r.orderItemId === input.orderItemId);
    if (existing) throw new AppError("CONFLICT", "Review already exists for this item");
    const review = {
      ...input,
      id: createId("rev"),
      helpfulCount: 0,
      moderationStatus: "approved" as const,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    mockDb.reviews.unshift(review);
    return review;
  },
  async respond(reviewId, body) {
    await delay();
    const review = mockDb.reviews.find((r) => r.id === reviewId);
    if (!review) throw new AppError("NOT_FOUND", "Review not found");
    review.sellerResponse = { body, createdAt: new Date().toISOString() };
    review.updatedAt = new Date().toISOString();
    return review;
  },
};

export const mockConversationRepository: ConversationRepository = {
  async listForUser(userId) {
    await delay();
    return mockDb.conversations
      .filter((c) => c.participantIds.includes(userId) && c.status !== "blocked")
      .sort((a, b) => b.lastMessageAt.localeCompare(a.lastMessageAt));
  },
  async get(id) {
    await delay();
    return mockDb.conversations.find((c) => c.id === id) ?? null;
  },
  async listMessages(conversationId) {
    await delay();
    return mockDb.messages
      .filter((m) => m.conversationId === conversationId)
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  },
  async sendMessage(input) {
    await delay();
    let conversation = input.conversationId
      ? mockDb.conversations.find((c) => c.id === input.conversationId)
      : undefined;
    if (!conversation) {
      conversation = {
        id: createId("conv"),
        type: input.type || "general",
        participantIds: [input.senderId, input.recipientId],
        storeId: input.storeId,
        productId: input.productId,
        orderId: input.orderId,
        subject: input.productId
          ? "Product inquiry"
          : input.orderId
            ? "Order support"
            : "Conversation",
        lastMessageAt: new Date().toISOString(),
        lastMessagePreview: input.body.slice(0, 120),
        unreadBy: { [input.recipientId]: 1, [input.senderId]: 0 },
        status: "open",
        createdAt: new Date().toISOString(),
      };
      mockDb.conversations.unshift(conversation);
    } else {
      conversation.lastMessageAt = new Date().toISOString();
      conversation.lastMessagePreview = input.body.slice(0, 120);
      conversation.unreadBy[input.recipientId] = (conversation.unreadBy[input.recipientId] || 0) + 1;
    }
    const message = {
      id: createId("msg"),
      conversationId: conversation.id,
      senderId: input.senderId,
      body: input.body,
      createdAt: new Date().toISOString(),
      readBy: [input.senderId],
    };
    mockDb.messages.push(message);
    mockDb.notifications.unshift({
      id: createId("ntf"),
      userId: input.recipientId,
      category: "messages",
      title: { en: "New message", ar: "رسالة جديدة" },
      body: { en: input.body.slice(0, 80), ar: input.body.slice(0, 80) },
      href: `/account/messages/${conversation.id}`,
      read: false,
      createdAt: message.createdAt,
    });
    return { conversation, message };
  },
  async markRead(conversationId, userId) {
    await delay();
    const conv = mockDb.conversations.find((c) => c.id === conversationId);
    if (conv) conv.unreadBy[userId] = 0;
    mockDb.messages
      .filter((m) => m.conversationId === conversationId)
      .forEach((m) => {
        if (!m.readBy.includes(userId)) m.readBy.push(userId);
      });
  },
};

export const mockNotificationRepository: NotificationRepository = {
  async list(userId) {
    await delay();
    return mockDb.notifications
      .filter((n) => n.userId === userId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  },
  async markRead(id, userId) {
    await delay();
    const n = mockDb.notifications.find((x) => x.id === id && x.userId === userId);
    if (n) n.read = true;
  },
  async markAllRead(userId) {
    await delay();
    mockDb.notifications.forEach((n) => {
      if (n.userId === userId) n.read = true;
    });
  },
};

export const mockWishlistRepository: WishlistRepository = {
  async list(userId) {
    await delay();
    return mockDb.wishlists.filter((w) => w.userId === userId);
  },
  async addItem(userId, productId, variantId) {
    await delay();
    let wl = mockDb.wishlists.find((w) => w.userId === userId && w.isDefault);
    if (!wl) {
      wl = {
        id: createId("wl"),
        userId,
        name: "Saved",
        isDefault: true,
        isPrivate: true,
        itemIds: [],
        createdAt: new Date().toISOString(),
      };
      mockDb.wishlists.push(wl);
    }
    if (!mockDb.wishlistItems.some((i) => i.wishlistId === wl!.id && i.productId === productId)) {
      const item = {
        id: createId("wli"),
        wishlistId: wl.id,
        productId,
        variantId,
        createdAt: new Date().toISOString(),
      };
      mockDb.wishlistItems.push(item);
      wl.itemIds.push(item.id);
    }
  },
  async removeItem(userId, productId) {
    await delay();
    const wls = mockDb.wishlists.filter((w) => w.userId === userId);
    for (const wl of wls) {
      const items = mockDb.wishlistItems.filter(
        (i) => i.wishlistId === wl.id && i.productId === productId
      );
      for (const item of items) {
        mockDb.wishlistItems = mockDb.wishlistItems.filter((i) => i.id !== item.id);
        wl.itemIds = wl.itemIds.filter((id) => id !== item.id);
      }
    }
  },
  async listProductIds(userId) {
    await delay();
    const wls = mockDb.wishlists.filter((w) => w.userId === userId).map((w) => w.id);
    return mockDb.wishlistItems.filter((i) => wls.includes(i.wishlistId)).map((i) => i.productId);
  },
};

export const mockPromotionRepository: PromotionRepository = {
  async listActive() {
    await delay();
    const now = Date.now();
    return mockDb.promotions.filter(
      (p) => p.active && new Date(p.startsAt).getTime() <= now && new Date(p.endsAt).getTime() >= now
    );
  },
  async validateCoupon(code, subtotalMinor) {
    await delay();
    const promo = mockDb.promotions.find(
      (p) => p.code?.toLowerCase() === code.toLowerCase() && p.active
    );
    if (!promo) return null;
    if (promo.minOrder && subtotalMinor < promo.minOrder.amount) return null;
    return promo;
  },
};

export const mockSearchProvider: SearchProvider = {
  async search(query, filters, sort, page = 1, pageSize = 24) {
    const result = await mockCatalogRepository.listProducts({
      query,
      filters,
      sort,
      page,
      pageSize,
    });
    const storeResult = await mockStoreRepository.list({ query, page: 1, pageSize: 6 });
    const prices = result.items.map((p) => toMajor(p.basePrice));
    return {
      products: result.items,
      stores: storeResult.items,
      total: result.total,
      facets: {
        categories: Object.entries(
          result.items.reduce<Record<string, number>>((acc, p) => {
            acc[p.categoryId] = (acc[p.categoryId] || 0) + 1;
            return acc;
          }, {})
        ).map(([id, count]) => ({ id, count })),
        brands: Object.entries(
          result.items.reduce<Record<string, number>>((acc, p) => {
            if (p.brandId) acc[p.brandId] = (acc[p.brandId] || 0) + 1;
            return acc;
          }, {})
        ).map(([id, count]) => ({ id, count })),
        priceRange: {
          min: prices.length ? Math.min(...prices) : 0,
          max: prices.length ? Math.max(...prices) : 0,
        },
      },
    };
  },
  async suggest(query) {
    await delay();
    const q = query.toLowerCase();
    const fromProducts = mockDb.products
      .filter((p) => p.title.en.toLowerCase().includes(q))
      .map((p) => p.title.en)
      .slice(0, 5);
    const fromTrending = mockDb.trendingSearches.filter((t) => t.includes(q));
    return Array.from(new Set([...fromTrending, ...fromProducts])).slice(0, 8);
  },
  async trending() {
    await delay();
    return mockDb.trendingSearches;
  },
};

export const mockInventoryRepository: InventoryRepository = {
  async listByStore(storeId) {
    await delay();
    return mockDb.inventory.filter((i) => i.storeId === storeId);
  },
  async adjust({ productId, variantId, delta, actorId, note }) {
    await delay();
    return manualAdjustOnHand(productId, variantId, delta, actorId, note);
  },
};

export const mockShippingProvider: ShippingProvider = {
  async listMethods(_storeId, productType) {
    await delay();
    if (productType === "digital") return mockDb.shippingMethods.filter((m) => m.type === "digital");
    if (productType === "service") return mockDb.shippingMethods.filter((m) => m.type === "service");
    return mockDb.shippingMethods.filter((m) => m.type === "flat" || m.type === "weight" || m.type === "pickup");
  },
  async estimate({ subtotalMinor, methodId }) {
    await delay();
    const method = mockDb.shippingMethods.find((m) => m.id === methodId) || mockDb.shippingMethods[0];
    let price = method.price.amount;
    if (method.freeAbove && subtotalMinor >= method.freeAbove.amount) price = 0;
    return { priceMinor: price, minDays: method.minDays, maxDays: method.maxDays };
  },
};

export const mockPaymentProvider: PaymentProvider = {
  async createIntent({ amountMinor, method, idempotencyKey }) {
    await delay();
    if (amountMinor <= 0) throw new AppError("VALIDATION", "Invalid amount");
    if (method === "card_fail") {
      return { id: createId("pi"), status: "failed" };
    }
    return {
      id: createId("pi"),
      status: "requires_confirmation",
      clientSecret: `secret_${idempotencyKey}`,
    };
  },
  async confirm(intentId) {
    await delay();
    if (!intentId) return { status: "failed" };
    return { status: "succeeded" };
  },
};

export const mockMediaStorage: MediaStorageProvider = {
  async upload({ bucket, path, dataUrl }) {
    await delay();
    return { bucket, path, url: dataUrl || `/images/placeholder.svg` };
  },
  async getPublicUrl(bucket, path) {
    return `/storage/${bucket}/${path}`;
  },
};

export const mockModerationRepository: ModerationRepository = {
  async listReports() {
    await delay();
    return mockDb.reports;
  },
  async updateReport(id, status) {
    await delay();
    const report = mockDb.reports.find((r) => r.id === id);
    if (!report) throw new AppError("NOT_FOUND", "Report not found");
    report.status = status;
    return report;
  },
  async listPendingProducts() {
    await delay();
    return mockDb.products.filter(
      (p) => p.moderationStatus === "pending" || p.status === "pending_review"
    );
  },
  async moderateProduct(id, status, note) {
    await delay();
    const product = mockDb.products.find((p) => p.id === id);
    if (!product) throw new AppError("NOT_FOUND", "Product not found");
    product.moderationStatus = status;
    if (status === "approved") {
      product.status = "published";
      product.publishedAt = new Date().toISOString();
    }
    if (status === "rejected") product.status = "rejected";
    if (status === "changes_requested") product.status = "changes_requested";
    mockDb.auditLogs.unshift({
      id: createId("audit"),
      actorId: "system",
      action: `product.${status}`,
      entityType: "product",
      entityId: id,
      metadata: note ? { note } : undefined,
      createdAt: new Date().toISOString(),
    });
    return product;
  },
  async listSellerApplications() {
    await delay();
    return mockDb.sellerApplications;
  },
  async reviewApplication(id, status, note) {
    await delay();
    const app = mockDb.sellerApplications.find((a) => a.id === id);
    if (!app) throw new AppError("NOT_FOUND", "Application not found");
    app.status = status;
    app.updatedAt = new Date().toISOString();
    app.timeline.push({ status, at: app.updatedAt, note });
    if (status === "approved") {
      const user = mockDb.users.find((u) => u.id === app.userId);
      if (user && !user.roles.includes("seller")) user.roles.push("seller");
      let store = mockDb.stores.find((s) => s.ownerId === app.userId || s.slug === app.storeSlug);
      if (!store && app.storeName && app.storeSlug) {
        const storeId = createId("store");
        store = {
          id: storeId,
          ownerId: app.userId,
          name: app.storeName,
          slug: app.storeSlug,
          description: { en: app.storeName, ar: app.storeName },
          verificationStatus: "verified",
          status: "active",
          rating: 0,
          reviewCount: 0,
          salesCount: 0,
          followersCount: 0,
          responseRate: 100,
          responseTimeHours: 12,
          location: "Remote",
          categories: app.categories,
          createdAt: new Date().toISOString(),
        };
        mockDb.stores.unshift(store);
        mockDb.warehouses.push({
          id: `wh-${storeId}`,
          storeId,
          name: `${app.storeName} Main`,
          location: "Primary",
          isDefault: true,
        });
      } else if (store) {
        store.status = "active";
        store.verificationStatus = "verified";
      }
      touch();
    }
    return app;
  },
};

export const mockReturnsRepository: ReturnsRepository = {
  async listByBuyer(buyerId) {
    await delay();
    return mockDb.returns.filter((r) => r.buyerId === buyerId);
  },
  async listByStore(storeId) {
    await delay();
    return mockDb.returns.filter((r) => r.storeId === storeId);
  },
  async create(input) {
    await delay();
    const ret = {
      ...input,
      id: createId("ret"),
      status: "requested" as const,
      timeline: [{ status: "requested", at: new Date().toISOString() }],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    mockDb.returns.unshift(ret);
    return ret;
  },
  async updateStatus(id, status, note) {
    await delay();
    const ret = mockDb.returns.find((r) => r.id === id);
    if (!ret) throw new AppError("NOT_FOUND", "Return not found");
    ret.status = status;
    ret.updatedAt = new Date().toISOString();
    ret.timeline.push({ status, at: ret.updatedAt, note });
    return ret;
  },
};

export const mockDisputeRepository: DisputeRepository = {
  async list() {
    await delay();
    return mockDb.disputes;
  },
  async listByBuyer(buyerId) {
    await delay();
    return mockDb.disputes.filter((d) => d.buyerId === buyerId);
  },
  async create(input) {
    await delay();
    const dispute = {
      ...input,
      id: createId("disp"),
      status: "open" as const,
      timeline: [{ status: "open", at: new Date().toISOString() }],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    mockDb.disputes.unshift(dispute);
    return dispute;
  },
  async updateStatus(id, status, note) {
    await delay();
    const d = mockDb.disputes.find((x) => x.id === id);
    if (!d) throw new AppError("NOT_FOUND", "Dispute not found");
    d.status = status;
    d.updatedAt = new Date().toISOString();
    d.timeline.push({ status, at: d.updatedAt, note });
    return d;
  },
};

export const mockOfferRepository: OfferRepository = {
  async listForUser(userId) {
    await delay();
    return mockDb.offers.filter((o) => o.buyerId === userId || o.sellerId === userId);
  },
  async create(input) {
    await delay();
    const offer = {
      ...input,
      id: createId("offer"),
      status: "pending" as const,
      history: [
        {
          by: input.buyerId,
          price: input.offeredPrice,
          message: input.message,
          at: new Date().toISOString(),
        },
      ],
      createdAt: new Date().toISOString(),
    };
    mockDb.offers.unshift(offer);
    return offer;
  },
  async respond(id, action, priceMinor, message, by) {
    await delay();
    const offer = mockDb.offers.find((o) => o.id === id);
    if (!offer) throw new AppError("NOT_FOUND", "Offer not found");
    if (new Date(offer.expiresAt).getTime() < Date.now()) {
      offer.status = "expired";
      throw new AppError("CONFLICT", "Offer expired");
    }
    if (action === "accept") offer.status = "accepted";
    if (action === "decline") offer.status = "declined";
    if (action === "counter") {
      offer.status = "countered";
      if (priceMinor != null) {
        offer.offeredPrice = money(priceMinor, offer.offeredPrice.currency);
        offer.history.push({
          by: by || offer.sellerId,
          price: offer.offeredPrice,
          message,
          at: new Date().toISOString(),
        });
      }
    }
    return offer;
  },
};

export const mockAnalyticsRepository: AnalyticsRepository = {
  async track() {
    // no-op mock sink
  },
  async sellerMetrics(storeId) {
    await delay();
    const storeOrders = mockDb.orders.filter((o) => o.storeId === storeId);
    const revenueMinor = storeOrders.reduce((s, o) => s + o.total.amount, 0);
    const unitsSold = storeOrders.reduce(
      (s, o) => s + o.items.reduce((x, i) => x + i.quantity, 0),
      0
    );
    const store = mockDb.stores.find((s) => s.id === storeId);
    const lowStock = mockDb.inventory.filter(
      (i) => i.storeId === storeId && i.onHand - i.reserved <= i.lowStockThreshold
    ).length;
    const topProducts = mockDb.products
      .filter((p) => p.storeId === storeId)
      .sort((a, b) => b.salesCount - a.salesCount)
      .slice(0, 5)
      .map((p) => ({ productId: p.id, title: p.title.en, sales: p.salesCount }));
    const salesTrend = Array.from({ length: 14 }).map((_, i) => ({
      date: new Date(Date.now() - (13 - i) * 86400000).toISOString().slice(0, 10),
      revenueMinor: Math.round(revenueMinor / 20 + Math.random() * 5000),
    }));
    return {
      revenueMinor,
      orders: storeOrders.length,
      unitsSold,
      aovMinor: storeOrders.length ? Math.round(revenueMinor / storeOrders.length) : 0,
      conversion: 3.2,
      productViews: 4200,
      storeViews: 1800,
      followers: store?.followersCount || 0,
      lowStock,
      pendingOrders: storeOrders.filter((o) =>
        ["paid", "confirmed", "preparing"].includes(o.status)
      ).length,
      topProducts,
      salesTrend,
    };
  },
  async platformMetrics() {
    await delay();
    return {
      gmvMinor: mockDb.orders.reduce((s, o) => s + o.total.amount, 0),
      orders: mockDb.orders.length,
      activeBuyers: mockDb.users.filter((u) => u.roles.includes("buyer")).length,
      activeSellers: mockDb.stores.filter((s) => s.status === "active").length,
      openDisputes: mockDb.disputes.filter((d) => d.status === "open" || d.status === "under_review").length,
      openReports: mockDb.reports.filter((r) => r.status === "open").length,
      pendingProducts: mockDb.products.filter((p) => p.moderationStatus === "pending").length,
      pendingApplications: mockDb.sellerApplications.filter((a) =>
        ["submitted", "under_review"].includes(a.status)
      ).length,
    };
  },
};

export const mockCmsRepository: CmsRepository = {
  async homepageModules() {
    await delay();
    return mockDb.homepageModules.filter((m) => m.visible);
  },
  async collections() {
    await delay();
    return mockDb.collections;
  },
  async getCollection(slug) {
    await delay();
    return mockDb.collections.find((c) => c.slug === slug) ?? null;
  },
  async helpCategories() {
    await delay();
    return mockDb.helpCategories;
  },
  async helpArticles(categorySlug) {
    await delay();
    if (!categorySlug) return mockDb.helpArticles;
    const cat = mockDb.helpCategories.find((c) => c.slug === categorySlug);
    if (!cat) return [];
    return mockDb.helpArticles.filter((a) => a.categoryId === cat.id);
  },
  async helpArticle(slug) {
    await delay();
    return mockDb.helpArticles.find((a) => a.slug === slug) ?? null;
  },
  async createTicket({ userId, subject, body }) {
    await delay();
    const ticket = {
      id: createId("tkt"),
      userId,
      subject,
      status: "open" as const,
      priority: "normal" as const,
      messages: [
        {
          id: createId("tm"),
          senderId: userId,
          body,
          createdAt: new Date().toISOString(),
        },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    mockDb.supportTickets.unshift(ticket);
    return ticket;
  },
  async listTickets(userId) {
    await delay();
    return mockDb.supportTickets.filter((t) => t.userId === userId);
  },
};

export const mockAuditRepository: AuditRepository = {
  async list(limit = 50) {
    await delay();
    return mockDb.auditLogs.slice(0, limit);
  },
  async write(entry) {
    await delay();
    mockDb.auditLogs.unshift({
      id: createId("audit"),
      actorId: entry.actorId,
      action: entry.action,
      entityType: entry.entityType,
      entityId: entry.entityId,
      metadata: entry.metadata as { note: string } | undefined,
      createdAt: new Date().toISOString(),
    });
  },
};

export const mockServices = {
  auth: mockAuthRepository,
  profile: mockProfileRepository,
  catalog: mockCatalogRepository,
  categories: mockCategoryRepository,
  stores: mockStoreRepository,
  brands: mockBrandRepository,
  cart: mockCartRepository,
  orders: mockOrderRepository,
  reviews: mockReviewRepository,
  conversations: mockConversationRepository,
  notifications: mockNotificationRepository,
  wishlists: mockWishlistRepository,
  promotions: mockPromotionRepository,
  search: mockSearchProvider,
  inventory: mockInventoryRepository,
  shipping: mockShippingProvider,
  payments: mockPaymentProvider,
  media: mockMediaStorage,
  moderation: mockModerationRepository,
  returns: mockReturnsRepository,
  disputes: mockDisputeRepository,
  offers: mockOfferRepository,
  analytics: mockAnalyticsRepository,
  cms: mockCmsRepository,
  audit: mockAuditRepository,
  sellerManagement: mockSellerManagementRepository,
  adminManagement: mockAdminManagementRepository,
  sellerApplications: {
    async listByUser(userId: string) {
      await delay();
      return mockDb.sellerApplications.filter((a) => a.userId === userId);
    },
    async upsertDraft(input: {
      userId: string;
      sellerType: "individual" | "business";
      storeName: string;
      storeSlug: string;
      categories: string[];
      contactEmail: string;
      contactPhone: string;
      address: Record<string, string>;
      documents?: Array<{ type: string; path: string; status: string }>;
    }) {
      await delay();
      let app = mockDb.sellerApplications.find(
        (a) => a.userId === input.userId && ["draft", "more_info_required"].includes(a.status)
      );
      if (!app) {
        app = {
          id: createId("app"),
          userId: input.userId,
          status: "draft",
          sellerType: input.sellerType,
          storeName: input.storeName,
          storeSlug: input.storeSlug,
          categories: input.categories,
          contactEmail: input.contactEmail,
          contactPhone: input.contactPhone,
          address: input.address,
          documents: input.documents || [],
          timeline: [{ status: "draft", at: new Date().toISOString() }],
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        mockDb.sellerApplications.unshift(app);
      } else {
        Object.assign(app, { ...input, updatedAt: new Date().toISOString() });
      }
      touch();
      return app;
    },
    async submit(userId: string) {
      await delay();
      const app = mockDb.sellerApplications.find(
        (a) => a.userId === userId && ["draft", "more_info_required"].includes(a.status)
      );
      if (!app) throw new AppError("NOT_FOUND", "No draft application found");
      if (!app.storeName || !app.storeSlug) {
        throw new AppError("VALIDATION", "Store name and slug are required");
      }
      app.status = "submitted";
      app.updatedAt = new Date().toISOString();
      app.timeline.push({ status: "submitted", at: app.updatedAt });
      touch();
      return app;
    },
  },
};

export const mockServicesSatisfies = mockServices as MarketplaceServices;
