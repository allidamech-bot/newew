import type { PlatformSettings } from "@/types";
import { AppError } from "@/lib/errors";
import { money } from "@/lib/money";
import { createId, mockDb, persistMockDb } from "@/mocks/db";
import type {
  AdminManagementRepository,
  CommissionRecord,
  HomepageModuleRecord,
  NotificationCampaign,
  RefundRecord,
  SecurityEvent,
  SellerManagementRepository,
  StoreStaffMember,
  TransactionRecord,
  WarehouseTransfer,
} from "@/repositories/management";
import type { Promotion, ShippingMethod, Warehouse } from "@/types";

function touch() {
  persistMockDb();
}

// Ensure extended collections exist on mockDb
type ExtDb = typeof mockDb & {
  storeMembers: StoreStaffMember[];
  warehouseTransfers: WarehouseTransfer[];
  campaigns: NotificationCampaign[];
  securityEvents: SecurityEvent[];
  refunds: RefundRecord[];
  commissions: CommissionRecord[];
  homepageModuleRecords: HomepageModuleRecord[];
};

const db = mockDb as ExtDb;
if (!db.storeMembers) db.storeMembers = [];
if (!db.warehouseTransfers) db.warehouseTransfers = [];
if (!db.campaigns) db.campaigns = [];
if (!db.securityEvents) {
  db.securityEvents = [
    {
      id: "sec-1",
      userId: "user-admin-1",
      eventType: "admin.login",
      ip: "127.0.0.1",
      createdAt: new Date().toISOString(),
    },
  ];
}
if (!db.refunds) db.refunds = [];
if (!db.commissions) {
  db.commissions = mockDb.orders.map((o) => ({
    id: createId("comm"),
    orderId: o.id,
    storeId: o.storeId,
    ratePercent: 8,
    amount: money(Math.round(o.total.amount * 0.08), o.currency),
    createdAt: o.createdAt,
  }));
}
if (!db.homepageModuleRecords) {
  db.homepageModuleRecords = mockDb.homepageModules.map((m, idx) => ({
    id: m.id,
    type: (m as {type?: string}).type || 'editorial',
    title: "title" in m && m.title ? m.title : { en: (m as {type?: string}).type || 'module', ar: (m as {type?: string}).type || 'module' },
    subtitle: "subtitle" in m ? m.subtitle : undefined,
    visible: m.visible,
    sortOrder: idx,
  }));
}

export const mockSellerManagementRepository: SellerManagementRepository = {
  async listPromotions(storeId) {
    return mockDb.promotions.filter((p) => p.storeId === storeId || p.platformWide);
  },
  async createPromotion(input) {
    const promo: Promotion = {
      ...input,
      id: createId("promo"),
      usageCount: 0,
    };
    mockDb.promotions.unshift(promo);
    mockDb.auditLogs.unshift({
      id: createId("audit"),
      actorId: "seller",
      action: "promotion.create",
      entityType: "promotion",
      entityId: promo.id,
      createdAt: new Date().toISOString(),
    });
    touch();
    return promo;
  },
  async updatePromotion(id, patch) {
    const idx = mockDb.promotions.findIndex((p) => p.id === id);
    if (idx < 0) throw new AppError("NOT_FOUND", "Promotion not found");
    mockDb.promotions[idx] = { ...mockDb.promotions[idx], ...patch, id };
    touch();
    return mockDb.promotions[idx];
  },
  async listShippingMethods(storeId) {
    return mockDb.shippingMethods.filter((m) => !m.storeId || m.storeId === storeId);
  },
  async createShippingMethod(input) {
    const method: ShippingMethod = { ...input, id: createId("ship") };
    mockDb.shippingMethods.push(method);
    touch();
    return method;
  },
  async updateShippingMethod(id, patch) {
    const idx = mockDb.shippingMethods.findIndex((m) => m.id === id);
    if (idx < 0) throw new AppError("NOT_FOUND", "Shipping method not found");
    mockDb.shippingMethods[idx] = { ...mockDb.shippingMethods[idx], ...patch, id };
    touch();
    return mockDb.shippingMethods[idx];
  },
  async listStaff(storeId) {
    return db.storeMembers.filter((m) => m.storeId === storeId && m.status !== "removed") as StoreStaffMember[];
  },
  async inviteStaff(input) {
    const member: StoreStaffMember = {
      id: createId("staff"),
      storeId: input.storeId,
      userId: createId("user"),
      email: input.email,
      name: input.name,
      role: input.role,
      permissions: input.permissions,
      status: "invited",
      createdAt: new Date().toISOString(),
    };
    db.storeMembers.unshift(member);
    mockDb.auditLogs.unshift({
      id: createId("audit"),
      actorId: "seller",
      action: "staff.invite",
      entityType: "store_member",
      entityId: member.id,
      metadata: { email: input.email, role: input.role },
      createdAt: new Date().toISOString(),
    });
    touch();
    return member;
  },
  async updateStaff(id, patch) {
    const idx = db.storeMembers.findIndex((m) => m.id === id);
    if (idx < 0) throw new AppError("NOT_FOUND", "Staff member not found");
    db.storeMembers[idx] = { ...db.storeMembers[idx], ...patch, id };
    touch();
    return db.storeMembers[idx];
  },
  async removeStaff(id) {
    const member = db.storeMembers.find((m) => m.id === id);
    if (!member) throw new AppError("NOT_FOUND", "Staff member not found");
    member.status = "removed";
    touch();
  },
  async listWarehouses(storeId) {
    return mockDb.warehouses.filter((w) => w.storeId === storeId);
  },
  async createWarehouse(input) {
    const warehouse: Warehouse = { ...input, id: createId("wh") };
    if (warehouse.isDefault) {
      mockDb.warehouses = mockDb.warehouses.map((w) =>
        w.storeId === warehouse.storeId ? { ...w, isDefault: false } : w
      );
    }
    mockDb.warehouses.push(warehouse);
    touch();
    return warehouse;
  },
  async transferStock(input) {
    const transfer: WarehouseTransfer = {
      ...input,
      id: createId("xfer"),
      createdAt: new Date().toISOString(),
    };
    db.warehouseTransfers.unshift(transfer);
    mockDb.auditLogs.unshift({
      id: createId("audit"),
      actorId: input.createdBy,
      action: "inventory.transfer",
      entityType: "warehouse_transfer",
      entityId: transfer.id,
      metadata: {
        from: input.fromWarehouseId,
        to: input.toWarehouseId,
        qty: input.quantity,
      },
      createdAt: transfer.createdAt,
    });
    touch();
    return transfer;
  },
  async listTransfers(storeId) {
    return db.warehouseTransfers.filter((t) => t.storeId === storeId);
  },
  async listAudit(storeId) {
    return mockDb.auditLogs
      .filter(
        (l) =>
          l.entityId.includes(storeId) ||
          l.metadata?.storeId === storeId ||
          l.action.startsWith("promotion") ||
          l.action.startsWith("staff") ||
          l.action.startsWith("inventory")
      )
      .slice(0, 100);
  },
};

export const mockAdminManagementRepository: AdminManagementRepository = {
  async listUsers() {
    return mockDb.users;
  },
  async updateUserStatus(userId, status) {
    const user = mockDb.users.find((u) => u.id === userId);
    if (!user) throw new AppError("NOT_FOUND", "User not found");
    user.status = status;
    user.updatedAt = new Date().toISOString();
    mockDb.auditLogs.unshift({
      id: createId("audit"),
      actorId: "admin",
      action: `user.${status}`,
      entityType: "user",
      entityId: userId,
      createdAt: new Date().toISOString(),
    });
    db.securityEvents.unshift({
      id: createId("sec"),
      userId,
      eventType: `user.status.${status}`,
      createdAt: new Date().toISOString(),
    });
    touch();
    return user;
  },
  async updateUserRoles(userId, roles) {
    const user = mockDb.users.find((u) => u.id === userId);
    if (!user) throw new AppError("NOT_FOUND", "User not found");
    user.roles = roles;
    user.updatedAt = new Date().toISOString();
    mockDb.auditLogs.unshift({
      id: createId("audit"),
      actorId: "admin",
      action: "user.roles.update",
      entityType: "user",
      entityId: userId,
      metadata: { roles },
      createdAt: new Date().toISOString(),
    });
    touch();
    return user;
  },
  async updateStoreStatus(storeId, status) {
    const store = mockDb.stores.find((s) => s.id === storeId);
    if (!store) throw new AppError("NOT_FOUND", "Store not found");
    store.status = status;
    mockDb.auditLogs.unshift({
      id: createId("audit"),
      actorId: "admin",
      action: `store.${status}`,
      entityType: "store",
      entityId: storeId,
      createdAt: new Date().toISOString(),
    });
    touch();
  },
  async listTransactions() {
    return mockDb.orders.map(
      (o): TransactionRecord => ({
        id: `txn-${o.id}`,
        orderId: o.id,
        orderNumber: o.orderNumber,
        buyerId: o.buyerId,
        storeId: o.storeId,
        amount: o.total,
        method: "card",
        status: o.paymentStatus,
        createdAt: o.createdAt,
      })
    );
  },
  async listCommissions() {
    return db.commissions;
  },
  async listRefunds() {
    return db.refunds;
  },
  async createRefund(input) {
    const refund: RefundRecord = {
      ...input,
      id: createId("ref"),
      status: "succeeded",
      createdAt: new Date().toISOString(),
    };
    db.refunds.unshift(refund);
    mockDb.auditLogs.unshift({
      id: createId("audit"),
      actorId: "admin",
      action: "refund.create",
      entityType: "refund",
      entityId: refund.id,
      createdAt: refund.createdAt,
    });
    touch();
    return refund;
  },
  async listCampaigns() {
    return db.campaigns;
  },
  async upsertCampaign(input) {
    if (input.id) {
      const idx = db.campaigns.findIndex((c) => c.id === input.id);
      if (idx >= 0) {
        db.campaigns[idx] = {
          ...db.campaigns[idx],
          ...input,
          id: input.id,
        } as NotificationCampaign;
        touch();
        return db.campaigns[idx];
      }
    }
    const campaign: NotificationCampaign = {
      id: createId("camp"),
      title: input.title,
      body: input.body,
      audience: input.audience || "all",
      channel: input.channel || "in_app",
      status: input.status || "draft",
      scheduledAt: input.scheduledAt,
      createdAt: new Date().toISOString(),
    };
    db.campaigns.unshift(campaign);
    touch();
    return campaign;
  },
  async sendCampaign(id) {
    const campaign = db.campaigns.find((c) => c.id === id);
    if (!campaign) throw new AppError("NOT_FOUND", "Campaign not found");
    campaign.status = "sent";
    campaign.sentAt = new Date().toISOString();
    const targets =
      campaign.audience === "sellers"
        ? mockDb.users.filter((u) => u.roles.includes("seller"))
        : mockDb.users;
    for (const user of targets) {
      mockDb.notifications.unshift({
        id: createId("ntf"),
        userId: user.id,
        category: "platform",
        title: campaign.title,
        body: campaign.body,
        read: false,
        createdAt: campaign.sentAt,
      });
    }
    touch();
    return campaign;
  },
  async listSecurityEvents() {
    return db.securityEvents;
  },
  async getSettings() {
    return mockDb.platformSettings as unknown as PlatformSettings;
  },
  async updateSettings(patch, actorId) {
    mockDb.platformSettings = { ...mockDb.platformSettings, ...patch, defaultLocale: patch.defaultLocale || mockDb.platformSettings.defaultLocale } as typeof mockDb.platformSettings;
    mockDb.auditLogs.unshift({
      id: createId("audit"),
      actorId,
      action: "platform_settings.update",
      entityType: "platform_settings",
      entityId: "global",
      metadata: patch as Record<string, unknown>,
      createdAt: new Date().toISOString(),
    });
    db.securityEvents.unshift({
      id: createId("sec"),
      userId: actorId,
      eventType: "settings.change",
      metadata: patch as Record<string, unknown>,
      createdAt: new Date().toISOString(),
    });
    touch();
    return mockDb.platformSettings;
  },
  async listHomepageModules() {
    return [...db.homepageModuleRecords].sort((a, b) => a.sortOrder - b.sortOrder);
  },
  async upsertHomepageModule(input) {
    if (input.id) {
      const idx = db.homepageModuleRecords.findIndex((m) => m.id === input.id);
      if (idx >= 0) {
        db.homepageModuleRecords[idx] = {
          ...db.homepageModuleRecords[idx],
          ...input,
          id: input.id,
        } as HomepageModuleRecord;
        touch();
        return db.homepageModuleRecords[idx];
      }
    }
    const mod: HomepageModuleRecord = {
      id: createId("mod"),
      type: input.type,
      title: input.title,
      subtitle: input.subtitle,
      visible: input.visible ?? true,
      sortOrder: input.sortOrder ?? db.homepageModuleRecords.length,
      config: input.config,
    };
    db.homepageModuleRecords.push(mod);
    touch();
    return mod;
  },
  async reorderHomepageModules(ids) {
    ids.forEach((id, index) => {
      const mod = db.homepageModuleRecords.find((m) => m.id === id);
      if (mod) mod.sortOrder = index;
    });
    touch();
    return this.listHomepageModules();
  },
  async listSupportTickets() {
    return mockDb.supportTickets;
  },
  async replySupportTicket(ticketId, senderId, body) {
    const ticket = mockDb.supportTickets.find((t) => t.id === ticketId);
    if (!ticket) throw new AppError("NOT_FOUND", "Ticket not found");
    ticket.messages.push({
      id: createId("tm"),
      senderId,
      body,
      createdAt: new Date().toISOString(),
    });
    ticket.status = senderId === ticket.userId ? "waiting_for_user" : "in_progress";
    ticket.updatedAt = new Date().toISOString();
    touch();
    return ticket;
  },
};
