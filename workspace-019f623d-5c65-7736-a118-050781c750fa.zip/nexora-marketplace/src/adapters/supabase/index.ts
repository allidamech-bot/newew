/* eslint-disable @typescript-eslint/no-explicit-any */
import { AppError } from "@/lib/errors";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";
import type { Session, UserProfile } from "@/types";

function requireClient() {
  const client = createSupabaseBrowserClient();
  if (!client) {
    throw new AppError(
      "SERVER_ERROR",
      "Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY.",
      { status: 503 }
    );
  }
  return client;
}

async function rolesFor(userId: string): Promise<UserProfile["roles"]> {
  const supabase = requireClient();
  const { data } = await supabase.from("user_roles").select("roles(key)").eq("user_id", userId);
  const roles = (data || [])
    .map((row: any) => {
      const nested = row.roles;
      if (Array.isArray(nested)) return nested[0]?.key;
      return nested?.key;
    })
    .filter(Boolean) as UserProfile["roles"];
  return roles.length ? roles : ["buyer"];
}

function mapProfile(row: any, roles: UserProfile["roles"] = ["buyer"]): UserProfile {
  return {
    id: String(row.id),
    email: String(row.email),
    displayName: String(row.display_name || row.email),
    firstName: row.first_name ? String(row.first_name) : undefined,
    lastName: row.last_name ? String(row.last_name) : undefined,
    roles,
    locale: (row.locale as "en" | "ar") || "en",
    currency: String(row.currency || "USD"),
    status: (row.status as UserProfile["status"]) || "active",
    emailVerified: Boolean(row.email_verified),
    createdAt: String(row.created_at || new Date().toISOString()),
    updatedAt: String(row.updated_at || new Date().toISOString()),
  };
}

const rpc = async (name: string, args?: Record<string, unknown>) => {
  const supabase = requireClient();
  const { data, error } = await supabase.rpc(name, args || {});
  if (error) throw new AppError("SERVER_ERROR", error.message);
  return data;
};

export const supabaseServices: any = {
  auth: {
    async signIn(email: string, password: string) {
      const supabase = requireClient();
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error || !data.user || !data.session) {
        throw new AppError("UNAUTHORIZED", error?.message || "Invalid credentials", { status: 401 });
      }
      const { data: profile } = await supabase.from("profiles").select("*").eq("id", data.user.id).maybeSingle();
      const session: Session = {
        user: mapProfile(profile || { id: data.user.id, email: data.user.email }, await rolesFor(data.user.id)),
        accessToken: data.session.access_token,
        expiresAt: new Date((data.session.expires_at || 0) * 1000).toISOString(),
      };
      return session;
    },
    async signUp(input: { email: string; password: string; firstName: string; lastName: string }) {
      const supabase = requireClient();
      const { data, error } = await supabase.auth.signUp({
        email: input.email,
        password: input.password,
        options: { data: { first_name: input.firstName, last_name: input.lastName } },
      });
      if (error || !data.user) throw new AppError("VALIDATION", error?.message || "Sign up failed");
      await supabase.from("profiles").upsert({
        id: data.user.id,
        email: input.email,
        display_name: `${input.firstName} ${input.lastName}`.trim(),
        first_name: input.firstName,
        last_name: input.lastName,
      });
      if (!data.session) throw new AppError("UNAUTHORIZED", "Verify your email", { status: 401 });
      return this.signIn(input.email, input.password);
    },
    async signOut() {
      await requireClient().auth.signOut();
    },
    async getSession() {
      const supabase = requireClient();
      const { data } = await supabase.auth.getSession();
      if (!data.session?.user) return null;
      const { data: profile } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", data.session.user.id)
        .maybeSingle();
      return {
        user: mapProfile(
          profile || { id: data.session.user.id, email: data.session.user.email },
          await rolesFor(data.session.user.id)
        ),
        accessToken: data.session.access_token,
        expiresAt: new Date((data.session.expires_at || 0) * 1000).toISOString(),
      };
    },
    async requestPasswordReset(email: string) {
      await requireClient().auth.resetPasswordForEmail(email);
      return { ok: true };
    },
    async listDemoAccounts() {
      return [];
    },
  },
  profile: {
    async getById(id: string) {
      const supabase = requireClient();
      const { data } = await supabase.from("profiles").select("*").eq("id", id).maybeSingle();
      return data ? mapProfile(data, await rolesFor(id)) : null;
    },
    async update(id: string, patch: Partial<UserProfile>) {
      const supabase = requireClient();
      const { data, error } = await supabase
        .from("profiles")
        .update({
          display_name: patch.displayName,
          first_name: patch.firstName,
          last_name: patch.lastName,
          phone: patch.phone,
        })
        .eq("id", id)
        .select("*")
        .single();
      if (error) throw new AppError("SERVER_ERROR", error.message);
      return mapProfile(data, await rolesFor(id));
    },
    async listAddresses(userId: string) {
      const supabase = requireClient();
      const { data, error } = await supabase.from("addresses").select("*").eq("user_id", userId);
      if (error) throw new AppError("SERVER_ERROR", error.message);
      return (data || []).map((a: any) => ({
        id: String(a.id),
        userId: String(a.user_id),
        label: String(a.label),
        fullName: String(a.full_name),
        phone: String(a.phone),
        line1: String(a.line1),
        city: String(a.city),
        postalCode: String(a.postal_code),
        country: String(a.country),
        isDefault: Boolean(a.is_default),
      }));
    },
    async createAddress(address: any) {
      const supabase = requireClient();
      const { data, error } = await supabase
        .from("addresses")
        .insert({
          user_id: address.userId,
          label: address.label,
          full_name: address.fullName,
          phone: address.phone,
          line1: address.line1,
          city: address.city,
          postal_code: address.postalCode,
          country: address.country,
          is_default: address.isDefault,
        })
        .select("*")
        .single();
      if (error) throw new AppError("SERVER_ERROR", error.message);
      return { ...address, id: String(data.id) };
    },
    async updateAddress(id: string, patch: any) {
      return { id, ...patch };
    },
    async deleteAddress(id: string) {
      const supabase = requireClient();
      await supabase.from("addresses").delete().eq("id", id);
    },
  },
  catalog: {
    async listProducts(params: any = {}) {
      const supabase = requireClient();
      let q = supabase.from("products").select("*").limit(params.pageSize || 24);
      if (params.filters?.storeId) q = q.eq("store_id", params.filters.storeId);
      if (params.filters?.categoryId) q = q.eq("category_id", params.filters.categoryId);
      const { data, error } = await q;
      if (error) throw new AppError("SERVER_ERROR", error.message);
      const items = (data || []).map((row: any) => ({
        id: String(row.id),
        storeId: String(row.store_id),
        sellerId: String(row.seller_id),
        categoryId: String(row.category_id),
        type: row.type,
        slug: String(row.slug),
        title: { en: String(row.slug), ar: String(row.slug) },
        description: { en: "", ar: "" },
        shortDescription: { en: "", ar: "" },
        status: row.status,
        moderationStatus: row.moderation_status || "pending",
        visibility: "public",
        condition: "new",
        basePrice: { amount: Number(row.base_price_minor || 0), currency: "USD" },
        currency: "USD",
        quantity: Number(row.quantity || 0),
        reservedQuantity: Number(row.reserved_quantity || 0),
        lowStockThreshold: 5,
        inventoryPolicy: "deny",
        requiresShipping: Boolean(row.requires_shipping),
        tags: [],
        media: [],
        attributes: {},
        variantOptions: [],
        variants: [],
        rating: Number(row.rating || 0),
        reviewCount: Number(row.review_count || 0),
        salesCount: Number(row.sales_count || 0),
        featured: Boolean(row.featured),
        offersEnabled: Boolean(row.offers_enabled),
        processingDays: 2,
        returnDays: 14,
        relatedProductIds: [],
        createdAt: String(row.created_at),
        updatedAt: String(row.updated_at),
      }));
      return { items, total: items.length, page: params.page || 1, pageSize: params.pageSize || 24, hasMore: false };
    },
    async getProductBySlug(slug: string) {
      const list = await this.listProducts({ pageSize: 100 });
      return list.items.find((p: any) => p.slug === slug) || null;
    },
    async getProductById(id: string) {
      const list = await this.listProducts({ pageSize: 100 });
      return list.items.find((p: any) => p.id === id) || null;
    },
    async listRelated(productId: string, limit = 8) {
      const list = await this.listProducts({ pageSize: limit + 1 });
      return list.items.filter((p: any) => p.id !== productId).slice(0, limit);
    },
    async createProduct(input: any) {
      const supabase = requireClient();
      const { data, error } = await supabase
        .from("products")
        .insert({
          store_id: input.storeId,
          seller_id: input.sellerId,
          category_id: input.categoryId,
          type: input.type,
          slug: input.slug,
          status: input.status || "draft",
          moderation_status: "pending",
          base_price_minor: input.basePrice?.amount || 0,
          quantity: input.quantity || 0,
          requires_shipping: input.requiresShipping ?? true,
        })
        .select("*")
        .single();
      if (error) throw new AppError("SERVER_ERROR", error.message);
      return this.getProductById(String(data.id));
    },
    async updateProduct(id: string, patch: any) {
      const supabase = requireClient();
      const { error } = await supabase
        .from("products")
        .update({
          status: patch.status,
          moderation_status: patch.moderationStatus,
          quantity: patch.quantity,
          base_price_minor: patch.basePrice?.amount,
        })
        .eq("id", id);
      if (error) throw new AppError("SERVER_ERROR", error.message);
      return this.getProductById(id);
    },
    async listByStore(storeId: string, params: any = {}) {
      return this.listProducts({ ...params, filters: { ...(params.filters || {}), storeId } });
    },
  },
  orders: {
    async createFromCart(input: any) {
      return rpc("create_checkout_order_group", {
        p_cart_key: input.cartKey,
        p_buyer_id: input.buyerId,
        p_address_id: input.addressId,
        p_shipping_method_id: input.shippingMethodId,
        p_payment_method: input.paymentMethod,
        p_idempotency_key: input.idempotencyKey,
      });
    },
    async listByBuyer(buyerId: string) {
      const supabase = requireClient();
      const { data, error } = await supabase.from("orders").select("*").eq("buyer_id", buyerId);
      if (error) throw new AppError("SERVER_ERROR", error.message);
      return data || [];
    },
    async listByStore(storeId: string) {
      const supabase = requireClient();
      const { data, error } = await supabase.from("orders").select("*").eq("store_id", storeId);
      if (error) throw new AppError("SERVER_ERROR", error.message);
      return data || [];
    },
    async getById(id: string) {
      const supabase = requireClient();
      const { data, error } = await supabase.from("orders").select("*").eq("id", id).maybeSingle();
      if (error) throw new AppError("SERVER_ERROR", error.message);
      return data || null;
    },
    async updateStatus(id: string, status: string, note?: string) {
      return rpc("transition_order_status", { p_order_id: id, p_status: status, p_note: note || null });
    },
    async cancel(id: string, buyerId: string) {
      return this.updateStatus(id, "cancelled", `Cancelled by ${buyerId}`);
    },
  },
  cart: {
    getCart: async (key: string) => rpc("get_or_create_cart", { p_cart_key: key }),
    addItem: async (key: string, item: any) =>
      rpc("cart_add_item", {
        p_cart_key: key,
        p_product_id: item.productId,
        p_variant_id: item.variantId || null,
        p_quantity: item.quantity,
      }),
    updateItem: async (key: string, itemId: string, quantity: number) =>
      rpc("cart_update_item", { p_cart_key: key, p_item_id: itemId, p_quantity: quantity }),
    removeItem: async (key: string, itemId: string) =>
      rpc("cart_update_item", { p_cart_key: key, p_item_id: itemId, p_quantity: 0 }),
    applyCoupon: async (key: string, code: string) => rpc("cart_apply_coupon", { p_cart_key: key, p_code: code }),
    clearCoupon: async (key: string) => rpc("cart_apply_coupon", { p_cart_key: key, p_code: "" }),
    mergeGuestCart: async (guestKey: string, userId: string) =>
      rpc("merge_guest_cart", { p_guest_key: guestKey, p_user_id: userId }),
    saveForLater: async (key: string, itemId: string) =>
      rpc("cart_save_for_later", { p_cart_key: key, p_item_id: itemId }),
  },
  categories: {
    list: async () => [],
    getBySlug: async () => null,
    getTree: async () => [],
    listAttributes: async () => [],
    listAllAttributes: async () => [],
    createCategory: async (input: any) => input,
    updateCategory: async (id: string, patch: any) => ({ id, ...patch }),
  },
  stores: {
    list: async () => ({ items: [], total: 0, page: 1, pageSize: 24, hasMore: false }),
    getBySlug: async () => null,
    getById: async () => null,
    listByOwner: async () => [],
    follow: async () => undefined,
    unfollow: async () => undefined,
    listFollowed: async () => [],
    updateStore: async (id: string, patch: any) => ({ id, ...patch }),
  },
  brands: { list: async () => [] },
  reviews: {
    listByProduct: async () => [],
    listByStore: async () => [],
    listByBuyer: async () => [],
    create: async (input: any) => rpc("submit_review", { p_payload: input }),
    respond: async (id: string, body: any) => ({ id, sellerResponse: { body, createdAt: new Date().toISOString() } }),
  },
  conversations: {
    listForUser: async (userId: string) => rpc("list_user_conversations", { p_user_id: userId }),
    get: async () => null,
    listMessages: async () => [],
    sendMessage: async (input: any) => rpc("send_secure_message", { p_payload: input }),
    markRead: async () => undefined,
  },
  notifications: {
    list: async () => [],
    markRead: async () => undefined,
    markAllRead: async (userId: string) => rpc("mark_notifications_read", { p_user_id: userId }),
  },
  wishlists: {
    list: async () => [],
    addItem: async () => undefined,
    removeItem: async () => undefined,
    listProductIds: async () => [],
  },
  promotions: {
    listActive: async () => [],
    validateCoupon: async (code: string, subtotalMinor: number) =>
      rpc("validate_coupon", { p_code: code, p_subtotal_minor: subtotalMinor }),
  },
  search: {
    search: async () => ({ products: [], stores: [], total: 0, facets: { categories: [], brands: [], priceRange: { min: 0, max: 0 } } }),
    suggest: async () => [],
    trending: async () => [],
  },
  inventory: {
    listByStore: async () => [],
    adjust: async (input: any) =>
      rpc("adjust_inventory", {
        p_product_id: input.productId,
        p_variant_id: input.variantId || null,
        p_delta: input.delta,
        p_actor_id: input.actorId,
        p_note: input.note || null,
      }),
  },
  shipping: {
    listMethods: async () => [],
    estimate: async () => ({ priceMinor: 0, minDays: 0, maxDays: 0 }),
  },
  payments: {
    createIntent: async (input: any) =>
      rpc("create_payment_intent", {
        p_amount_minor: input.amountMinor,
        p_currency: input.currency,
        p_method: input.method,
        p_idempotency_key: input.idempotencyKey,
      }),
    confirm: async (intentId: string) => rpc("confirm_payment_intent", { p_intent_id: intentId }),
  },
  media: {
    upload: async ({ bucket, path, dataUrl }: any) => ({ bucket, path, url: dataUrl }),
    getPublicUrl: async (bucket: string, path: string) => `${bucket}/${path}`,
  },
  moderation: {
    listReports: async () => [],
    updateReport: async (id: string, status: string) => ({ id, status }),
    listPendingProducts: async () => [],
    moderateProduct: async (id: string, status: string, note?: string) =>
      rpc("moderate_product", { p_product_id: id, p_status: status, p_note: note || null }),
    listSellerApplications: async () => [],
    reviewApplication: async (id: string, status: string, note?: string) =>
      rpc("review_seller_application", { p_application_id: id, p_status: status, p_note: note || null }),
  },
  returns: {
    listByBuyer: async () => [],
    listByStore: async () => [],
    create: async (input: any) => rpc("create_return_request", { p_payload: input }),
    updateStatus: async (id: string, status: string, note?: string) =>
      rpc("update_return_status", { p_return_id: id, p_status: status, p_note: note || null }),
  },
  disputes: {
    list: async () => [],
    listByBuyer: async () => [],
    create: async (input: any) => rpc("create_dispute", { p_payload: input }),
    updateStatus: async (id: string, status: string, note?: string) =>
      rpc("update_dispute_status", { p_dispute_id: id, p_status: status, p_note: note || null }),
  },
  offers: {
    listForUser: async () => [],
    create: async (input: any) => input,
    respond: async (id: string, action: string) => rpc("respond_to_offer", { p_offer_id: id, p_action: action }),
  },
  analytics: {
    track: async () => undefined,
    sellerMetrics: async (storeId: string) => rpc("seller_metrics", { p_store_id: storeId }),
    platformMetrics: async () => rpc("platform_metrics"),
  },
  cms: {
    homepageModules: async () => [],
    collections: async () => [],
    getCollection: async () => null,
    helpCategories: async () => [],
    helpArticles: async () => [],
    helpArticle: async () => null,
    createTicket: async (input: any) => input,
    listTickets: async () => [],
  },
  audit: {
    list: async () => [],
    write: async () => undefined,
  },
  sellerManagement: {
    listPromotions: async () => [],
    createPromotion: async (input: any) => input,
    updatePromotion: async (id: string, patch: any) => ({ id, ...patch }),
    listShippingMethods: async () => [],
    createShippingMethod: async (input: any) => input,
    updateShippingMethod: async (id: string, patch: any) => ({ id, ...patch }),
    listStaff: async () => [],
    inviteStaff: async (input: any) => input,
    updateStaff: async (id: string, patch: any) => ({ id, ...patch }),
    removeStaff: async () => undefined,
    listWarehouses: async () => [],
    createWarehouse: async (input: any) => input,
    transferStock: async (input: any) => input,
    listTransfers: async () => [],
    listAudit: async () => [],
  },
  adminManagement: {
    listUsers: async () => [],
    updateUserStatus: async (userId: string, status: string) => ({ id: userId, status }),
    updateUserRoles: async (userId: string, roles: string[]) => ({ id: userId, roles }),
    updateStoreStatus: async () => undefined,
    listTransactions: async () => [],
    listCommissions: async () => [],
    listRefunds: async () => [],
    createRefund: async (input: any) => input,
    listCampaigns: async () => [],
    upsertCampaign: async (input: any) => input,
    sendCampaign: async (id: string) => ({ id }),
    listSecurityEvents: async () => [],
    getSettings: async () => ({
      maintenanceMode: false,
      sellerRegistrationOpen: true,
      defaultCommissionPercent: 8,
      returnWindowDays: 14,
      requireProductModeration: true,
      allowGuestCheckout: false,
      supportedLocales: ["en", "ar"],
      defaultLocale: "en",
      defaultCurrency: "USD",
    }),
    updateSettings: async (patch: any) => patch,
    listHomepageModules: async () => [],
    upsertHomepageModule: async (input: any) => input,
    reorderHomepageModules: async () => [],
    listSupportTickets: async () => [],
    replySupportTicket: async (ticketId: string) => ({ id: ticketId }),
  },
  sellerApplications: {
    listByUser: async () => [],
    upsertDraft: async (input: any) => input,
    submit: async () => {
      throw new AppError("SERVER_ERROR", "Use review_seller_application RPC flow");
    },
  },
};
