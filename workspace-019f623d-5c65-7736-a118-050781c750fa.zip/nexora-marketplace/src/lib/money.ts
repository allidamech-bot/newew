/**
 * Money helpers using integer minor units (cents) to avoid floating-point errors.
 */
export type Money = {
  amount: number; // minor units
  currency: string;
};

export function money(amountMinor: number, currency = "USD"): Money {
  return { amount: Math.round(amountMinor), currency };
}

export function fromMajor(amountMajor: number, currency = "USD"): Money {
  return money(Math.round(amountMajor * 100), currency);
}

export function toMajor(m: Money): number {
  return m.amount / 100;
}

export function addMoney(a: Money, b: Money): Money {
  assertSameCurrency(a, b);
  return money(a.amount + b.amount, a.currency);
}

export function subtractMoney(a: Money, b: Money): Money {
  assertSameCurrency(a, b);
  return money(a.amount - b.amount, a.currency);
}

export function multiplyMoney(m: Money, qty: number): Money {
  return money(Math.round(m.amount * qty), m.currency);
}

export function percentOf(m: Money, percent: number): Money {
  return money(Math.round((m.amount * percent) / 100), m.currency);
}

export function applyPercentDiscount(m: Money, percent: number, maxDiscount?: Money): Money {
  let discount = percentOf(m, percent);
  if (maxDiscount && discount.amount > maxDiscount.amount) {
    discount = maxDiscount;
  }
  return subtractMoney(m, discount);
}

export function applyFixedDiscount(m: Money, discount: Money): Money {
  assertSameCurrency(m, discount);
  return money(Math.max(0, m.amount - discount.amount), m.currency);
}

export function minMoney(a: Money, b: Money): Money {
  assertSameCurrency(a, b);
  return a.amount <= b.amount ? a : b;
}

export function sumMoney(items: Money[], currency = "USD"): Money {
  return items.reduce((acc, item) => {
    if (item.currency !== currency) {
      throw new Error(`Currency mismatch: ${item.currency} vs ${currency}`);
    }
    return money(acc.amount + item.amount, currency);
  }, money(0, currency));
}

export function formatMoney(
  m: Money,
  locale = "en",
  options?: Intl.NumberFormatOptions
): string {
  return new Intl.NumberFormat(locale === "ar" ? "ar" : "en-US", {
    style: "currency",
    currency: m.currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
    ...options,
  }).format(toMajor(m));
}

export function assertSameCurrency(a: Money, b: Money) {
  if (a.currency !== b.currency) {
    throw new Error(`Currency mismatch: ${a.currency} vs ${b.currency}`);
  }
}

export function discountPercent(base: Money, sale: Money): number {
  assertSameCurrency(base, sale);
  if (base.amount <= 0 || sale.amount >= base.amount) return 0;
  return Math.round(((base.amount - sale.amount) / base.amount) * 100);
}
