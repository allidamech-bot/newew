export type AppErrorCode =
  | "NETWORK_UNAVAILABLE"
  | "TIMEOUT"
  | "VALIDATION"
  | "UNAUTHORIZED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "CONFLICT"
  | "RATE_LIMITED"
  | "SERVER_ERROR"
  | "STORAGE_FAILURE"
  | "INVENTORY_CONFLICT"
  | "PRICE_CHANGED"
  | "PRODUCT_UNAVAILABLE"
  | "SESSION_EXPIRED"
  | "PAYMENT_FAILED"
  | "DUPLICATE_SUBMISSION"
  | "UNSUPPORTED_FILE"
  | "UPLOAD_FAILURE"
  | "UNKNOWN";

export class AppError extends Error {
  code: AppErrorCode;
  status?: number;
  details?: Record<string, unknown>;
  fieldErrors?: Record<string, string[]>;

  constructor(
    code: AppErrorCode,
    message: string,
    options?: {
      status?: number;
      details?: Record<string, unknown>;
      fieldErrors?: Record<string, string[]>;
      cause?: unknown;
    }
  ) {
    super(message, { cause: options?.cause });
    this.name = "AppError";
    this.code = code;
    this.status = options?.status;
    this.details = options?.details;
    this.fieldErrors = options?.fieldErrors;
  }
}

export function isAppError(error: unknown): error is AppError {
  return error instanceof AppError;
}

export function toAppError(error: unknown): AppError {
  if (isAppError(error)) return error;
  if (error instanceof Error) {
    return new AppError("UNKNOWN", error.message, { cause: error });
  }
  return new AppError("UNKNOWN", "An unexpected error occurred");
}

export const errorMessages: Record<
  AppErrorCode,
  { en: string; ar: string }
> = {
  NETWORK_UNAVAILABLE: {
    en: "Network unavailable. Check your connection and try again.",
    ar: "الشبكة غير متاحة. تحقق من اتصالك وحاول مرة أخرى.",
  },
  TIMEOUT: {
    en: "The request timed out. Please try again.",
    ar: "انتهت مهلة الطلب. يرجى المحاولة مرة أخرى.",
  },
  VALIDATION: {
    en: "Please check the highlighted fields.",
    ar: "يرجى التحقق من الحقول المميزة.",
  },
  UNAUTHORIZED: {
    en: "Please sign in to continue.",
    ar: "يرجى تسجيل الدخول للمتابعة.",
  },
  FORBIDDEN: {
    en: "You do not have permission to perform this action.",
    ar: "ليس لديك صلاحية لتنفيذ هذا الإجراء.",
  },
  NOT_FOUND: {
    en: "We could not find what you were looking for.",
    ar: "تعذر العثور على ما تبحث عنه.",
  },
  CONFLICT: {
    en: "This action conflicts with the current state. Refresh and try again.",
    ar: "يتعارض هذا الإجراء مع الحالة الحالية. حدّث الصفحة وحاول مرة أخرى.",
  },
  RATE_LIMITED: {
    en: "Too many requests. Please wait a moment.",
    ar: "طلبات كثيرة جداً. يرجى الانتظار قليلاً.",
  },
  SERVER_ERROR: {
    en: "Something went wrong on our side. Please try again.",
    ar: "حدث خطأ من جانبنا. يرجى المحاولة مرة أخرى.",
  },
  STORAGE_FAILURE: {
    en: "File storage failed. Please try again.",
    ar: "فشل تخزين الملف. يرجى المحاولة مرة أخرى.",
  },
  INVENTORY_CONFLICT: {
    en: "Inventory changed. Adjust quantities and try again.",
    ar: "تغير المخزون. عدّل الكميات وحاول مرة أخرى.",
  },
  PRICE_CHANGED: {
    en: "A price has changed. Review your cart and continue.",
    ar: "تغير أحد الأسعار. راجع سلتك وتابع.",
  },
  PRODUCT_UNAVAILABLE: {
    en: "This product is no longer available.",
    ar: "هذا المنتج لم يعد متاحاً.",
  },
  SESSION_EXPIRED: {
    en: "Your session expired. Please sign in again.",
    ar: "انتهت جلستك. يرجى تسجيل الدخول مرة أخرى.",
  },
  PAYMENT_FAILED: {
    en: "Payment could not be completed. Try another method.",
    ar: "تعذر إتمام الدفع. جرّب طريقة أخرى.",
  },
  DUPLICATE_SUBMISSION: {
    en: "This request was already submitted.",
    ar: "تم إرسال هذا الطلب مسبقاً.",
  },
  UNSUPPORTED_FILE: {
    en: "This file type is not supported.",
    ar: "نوع الملف هذا غير مدعوم.",
  },
  UPLOAD_FAILURE: {
    en: "Upload failed. Please try again.",
    ar: "فشل الرفع. يرجى المحاولة مرة أخرى.",
  },
  UNKNOWN: {
    en: "Something went wrong. Please try again.",
    ar: "حدث خطأ ما. يرجى المحاولة مرة أخرى.",
  },
};
