/**
 * Versioned browser persistence for mock-mode state survival across refresh.
 * Server-side no-ops keep SSR safe.
 */

const PREFIX = "nexora-mock-db-v2:";

export function canUseStorage(): boolean {
  return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
}

export function loadPersistedJson<T>(key: string): T | null {
  if (!canUseStorage()) return null;
  try {
    const raw = window.localStorage.getItem(PREFIX + key);
    if (!raw) return null;
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function savePersistedJson(key: string, value: unknown): void {
  if (!canUseStorage()) return;
  try {
    window.localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    // Quota / private mode — ignore
  }
}

export function clearPersisted(key: string): void {
  if (!canUseStorage()) return;
  window.localStorage.removeItem(PREFIX + key);
}
