import type { OrderStatus, Product, Review } from "@/types";

const ORDER_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  pending_payment: ["payment_processing", "paid", "cancelled", "failed"],
  payment_processing: ["paid", "failed", "cancelled"],
  paid: ["confirmed", "cancellation_requested", "cancelled"],
  confirmed: ["preparing", "cancellation_requested", "cancelled"],
  preparing: ["partially_shipped", "shipped", "cancellation_requested", "cancelled"],
  partially_shipped: ["shipped", "out_for_delivery"],
  shipped: ["out_for_delivery", "delivered"],
  out_for_delivery: ["delivered"],
  delivered: ["completed", "return_requested"],
  completed: ["return_requested"],
  cancellation_requested: ["cancelled", "confirmed", "preparing"],
  cancelled: [],
  return_requested: ["partially_returned", "returned", "disputed"],
  partially_returned: ["returned", "refund_pending"],
  returned: ["refund_pending", "refunded"],
  refund_pending: ["partially_refunded", "refunded"],
  partially_refunded: ["refunded"],
  refunded: [],
  disputed: ["completed", "refunded", "cancelled"],
  failed: [],
};

export function canTransitionOrder(from: OrderStatus, to: OrderStatus): boolean {
  if (from === to) return true;
  return (ORDER_TRANSITIONS[from] || []).includes(to);
}

export function isCancellable(status: OrderStatus): boolean {
  return ["pending_payment", "payment_processing", "paid", "confirmed", "preparing"].includes(
    status
  );
}

export function isReturnEligible(input: {
  status: OrderStatus;
  deliveredAt?: string;
  returnDays: number;
  now?: Date;
}): boolean {
  if (!["delivered", "completed"].includes(input.status)) return false;
  if (!input.deliveredAt) return false;
  const now = input.now ?? new Date();
  const delivered = new Date(input.deliveredAt).getTime();
  const windowMs = input.returnDays * 24 * 60 * 60 * 1000;
  return now.getTime() - delivered <= windowMs;
}

export function canReviewOrderItem(input: {
  buyerId: string;
  sellerId: string;
  orderStatus: OrderStatus;
  existingReview?: Review | null;
}): boolean {
  if (input.buyerId === input.sellerId) return false;
  if (input.existingReview) return false;
  return ["delivered", "completed"].includes(input.orderStatus);
}

export function availableQuantity(product: Product, variantId?: string): number {
  if (variantId) {
    const variant = product.variants.find((v) => v.id === variantId);
    if (!variant || !variant.enabled) return 0;
    return Math.max(0, variant.quantity - variant.reservedQuantity);
  }
  return Math.max(0, product.quantity - product.reservedQuantity);
}

export function assertPositiveQuantity(qty: number) {
  if (!Number.isFinite(qty) || qty <= 0) {
    throw new Error("Quantity must be a positive number");
  }
}
