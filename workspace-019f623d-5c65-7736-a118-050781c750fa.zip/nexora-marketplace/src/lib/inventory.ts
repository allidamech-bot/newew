/**
 * Canonical inventory model for NEXORA.
 *
 * on_hand  = physical stock owned by the seller
 * reserved = stock committed to active orders (not yet fulfilled)
 * available = on_hand - reserved
 *
 * Lifecycle:
 * - checkout reservation: reserved += qty          (on_hand unchanged)
 * - cancel before fulfill: reserved -= qty         (on_hand unchanged)
 * - fulfillment:           on_hand -= qty; reserved -= qty
 * - restockable return:    on_hand += qty
 * - damaged/non-restock:   movement only, no sellable stock change
 */

import { AppError } from "@/lib/errors";
import type { InventoryItem, Product, ProductVariant } from "@/types";

export type InventorySnapshot = {
  onHand: number;
  reserved: number;
};

export function availableStock(onHand: number, reserved: number): number {
  return Math.max(0, onHand - reserved);
}

export function assertInventoryInvariants(snap: InventorySnapshot, label = "inventory") {
  if (!Number.isFinite(snap.onHand) || snap.onHand < 0) {
    throw new AppError("INVENTORY_CONFLICT", `${label}: on_hand must be >= 0`);
  }
  if (!Number.isFinite(snap.reserved) || snap.reserved < 0) {
    throw new AppError("INVENTORY_CONFLICT", `${label}: reserved must be >= 0`);
  }
  if (snap.reserved > snap.onHand) {
    throw new AppError("INVENTORY_CONFLICT", `${label}: reserved cannot exceed on_hand`);
  }
}

export function assertPositiveQuantity(qty: number) {
  if (!Number.isInteger(qty) || qty <= 0) {
    throw new AppError("VALIDATION", "Quantity must be a positive integer");
  }
}

/** Checkout: increase reserved only. */
export function reserveStock(snap: InventorySnapshot, qty: number): InventorySnapshot {
  assertPositiveQuantity(qty);
  assertInventoryInvariants(snap, "before reserve");
  const available = availableStock(snap.onHand, snap.reserved);
  if (qty > available) {
    throw new AppError("INVENTORY_CONFLICT", "Insufficient available stock to reserve");
  }
  const next = { onHand: snap.onHand, reserved: snap.reserved + qty };
  assertInventoryInvariants(next, "after reserve");
  return next;
}

/** Cancel before fulfillment: decrease reserved only. */
export function releaseReservation(snap: InventorySnapshot, qty: number): InventorySnapshot {
  assertPositiveQuantity(qty);
  assertInventoryInvariants(snap, "before release");
  if (qty > snap.reserved) {
    throw new AppError("INVENTORY_CONFLICT", "Cannot release more than reserved");
  }
  const next = { onHand: snap.onHand, reserved: snap.reserved - qty };
  assertInventoryInvariants(next, "after release");
  return next;
}

/** Fulfillment: decrease both on_hand and reserved exactly once. */
export function fulfillStock(snap: InventorySnapshot, qty: number): InventorySnapshot {
  assertPositiveQuantity(qty);
  assertInventoryInvariants(snap, "before fulfill");
  if (qty > snap.reserved) {
    throw new AppError("INVENTORY_CONFLICT", "Cannot fulfill more than reserved");
  }
  if (qty > snap.onHand) {
    throw new AppError("INVENTORY_CONFLICT", "Cannot fulfill more than on_hand");
  }
  const next = { onHand: snap.onHand - qty, reserved: snap.reserved - qty };
  assertInventoryInvariants(next, "after fulfill");
  return next;
}

/** Restockable return: increase on_hand only. */
export function restockStock(snap: InventorySnapshot, qty: number): InventorySnapshot {
  assertPositiveQuantity(qty);
  assertInventoryInvariants(snap, "before restock");
  const next = { onHand: snap.onHand + qty, reserved: snap.reserved };
  assertInventoryInvariants(next, "after restock");
  return next;
}

/** Manual adjustment of on_hand (delta can be negative). Reserved unchanged. */
export function adjustOnHand(snap: InventorySnapshot, delta: number): InventorySnapshot {
  if (!Number.isInteger(delta) || delta === 0) {
    throw new AppError("VALIDATION", "Adjustment delta must be a non-zero integer");
  }
  assertInventoryInvariants(snap, "before adjust");
  const next = { onHand: snap.onHand + delta, reserved: snap.reserved };
  if (next.onHand < 0) {
    throw new AppError("INVENTORY_CONFLICT", "Adjustment would make on_hand negative");
  }
  if (next.reserved > next.onHand) {
    throw new AppError("INVENTORY_CONFLICT", "Adjustment would make reserved exceed on_hand");
  }
  return next;
}

export function snapshotFromInventoryItem(item: InventoryItem): InventorySnapshot {
  return { onHand: item.onHand, reserved: item.reserved };
}

export function snapshotFromProduct(product: Product): InventorySnapshot {
  return {
    onHand: product.quantity,
    reserved: product.reservedQuantity,
  };
}

export function snapshotFromVariant(variant: ProductVariant): InventorySnapshot {
  return {
    onHand: variant.quantity,
    reserved: variant.reservedQuantity,
  };
}

export function applySnapshotToInventoryItem(
  item: InventoryItem,
  snap: InventorySnapshot
): InventoryItem {
  return { ...item, onHand: snap.onHand, reserved: snap.reserved };
}

export function applySnapshotToProduct(product: Product, snap: InventorySnapshot): Product {
  return {
    ...product,
    quantity: snap.onHand,
    reservedQuantity: snap.reserved,
    status:
      snap.onHand - snap.reserved <= 0 && product.status === "published"
        ? "out_of_stock"
        : product.status === "out_of_stock" && snap.onHand - snap.reserved > 0
          ? "published"
          : product.status,
  };
}

export function applySnapshotToVariant(
  variant: ProductVariant,
  snap: InventorySnapshot
): ProductVariant {
  return {
    ...variant,
    quantity: snap.onHand,
    reservedQuantity: snap.reserved,
  };
}

export type OrderTransitionActor =
  | "buyer"
  | "seller"
  | "store_staff"
  | "moderator"
  | "admin"
  | "system";

/** Centralized order status transition matrix with actor permissions. */
const TRANSITIONS: Record<
  string,
  Array<{ to: string; actors: OrderTransitionActor[] }>
> = {
  pending_payment: [
    { to: "payment_processing", actors: ["system", "admin"] },
    { to: "paid", actors: ["system", "admin"] },
    { to: "cancelled", actors: ["buyer", "admin", "system"] },
    { to: "failed", actors: ["system", "admin"] },
  ],
  payment_processing: [
    { to: "paid", actors: ["system", "admin"] },
    { to: "failed", actors: ["system", "admin"] },
    { to: "cancelled", actors: ["admin", "system"] },
  ],
  paid: [
    { to: "confirmed", actors: ["seller", "store_staff", "admin", "system"] },
    { to: "cancellation_requested", actors: ["buyer"] },
    { to: "cancelled", actors: ["buyer", "seller", "admin", "system"] },
  ],
  confirmed: [
    { to: "preparing", actors: ["seller", "store_staff", "admin"] },
    { to: "cancellation_requested", actors: ["buyer"] },
    { to: "cancelled", actors: ["seller", "admin"] },
  ],
  preparing: [
    { to: "partially_shipped", actors: ["seller", "store_staff", "admin"] },
    { to: "shipped", actors: ["seller", "store_staff", "admin"] },
    { to: "cancellation_requested", actors: ["buyer"] },
    { to: "cancelled", actors: ["seller", "admin"] },
  ],
  partially_shipped: [
    { to: "shipped", actors: ["seller", "store_staff", "admin"] },
    { to: "out_for_delivery", actors: ["system", "admin"] },
  ],
  shipped: [
    { to: "out_for_delivery", actors: ["system", "admin", "seller"] },
    { to: "delivered", actors: ["system", "admin", "seller"] },
  ],
  out_for_delivery: [{ to: "delivered", actors: ["system", "admin", "seller"] }],
  delivered: [
    { to: "completed", actors: ["system", "admin", "buyer"] },
    { to: "return_requested", actors: ["buyer", "admin"] },
  ],
  completed: [{ to: "return_requested", actors: ["buyer", "admin"] }],
  cancellation_requested: [
    { to: "cancelled", actors: ["seller", "admin"] },
    { to: "confirmed", actors: ["seller", "admin"] },
    { to: "preparing", actors: ["seller", "admin"] },
  ],
  cancelled: [],
  return_requested: [
    { to: "partially_returned", actors: ["seller", "admin"] },
    { to: "returned", actors: ["seller", "admin"] },
    { to: "disputed", actors: ["buyer", "moderator", "admin"] },
  ],
  partially_returned: [
    { to: "returned", actors: ["seller", "admin"] },
    { to: "refund_pending", actors: ["seller", "admin", "system"] },
  ],
  returned: [
    { to: "refund_pending", actors: ["seller", "admin", "system"] },
    { to: "refunded", actors: ["admin", "system"] },
  ],
  refund_pending: [
    { to: "partially_refunded", actors: ["admin", "system"] },
    { to: "refunded", actors: ["admin", "system"] },
  ],
  partially_refunded: [{ to: "refunded", actors: ["admin", "system"] }],
  refunded: [],
  disputed: [
    { to: "completed", actors: ["moderator", "admin"] },
    { to: "refunded", actors: ["moderator", "admin"] },
    { to: "cancelled", actors: ["admin"] },
  ],
  failed: [],
};

export function canTransitionOrderStatus(
  from: string,
  to: string,
  actor: OrderTransitionActor
): boolean {
  if (from === to) return true;
  const options = TRANSITIONS[from] || [];
  return options.some((o) => o.to === to && o.actors.includes(actor));
}

export function assertOrderTransition(
  from: string,
  to: string,
  actor: OrderTransitionActor
) {
  if (!canTransitionOrderStatus(from, to, actor)) {
    throw new AppError(
      "CONFLICT",
      `Invalid order transition from ${from} to ${to} for actor ${actor}`
    );
  }
}

export const PRE_FULFILLMENT_STATUSES = new Set([
  "pending_payment",
  "payment_processing",
  "paid",
  "confirmed",
  "preparing",
  "cancellation_requested",
]);

export const FULFILLED_STATUSES = new Set([
  "partially_shipped",
  "shipped",
  "out_for_delivery",
  "delivered",
  "completed",
]);
