import {
  addresses,
  attributes,
  auditLogs,
  brands,
  categories,
  collections,
  conversations,
  disputes,
  follows,
  helpArticles,
  helpCategories,
  homepageModules,
  inventory,
  messages,
  notifications,
  offers,
  orders,
  platformSettings,
  products,
  promotions,
  reports,
  returns,
  reviews,
  sellerApplications,
  shippingMethods,
  stores,
  supportTickets,
  trendingSearches,
  users,
  warehouses,
  wishlistItems,
  wishlists,
  demoPasswords,
} from "./seed";
import type { Cart, CartItem, InventoryMovement, Session } from "@/types";
import { loadPersistedJson, savePersistedJson, canUseStorage } from "@/lib/persist";

function clone<T>(value: T): T {
  return structuredClone(value);
}

type PersistedShape = {
  users: typeof users;
  addresses: typeof addresses;
  categories: typeof categories;
  attributes: typeof attributes;
  brands: typeof brands;
  stores: typeof stores;
  products: typeof products;
  warehouses: typeof warehouses;
  inventory: typeof inventory;
  inventoryMovements: InventoryMovement[];
  shippingMethods: typeof shippingMethods;
  promotions: typeof promotions;
  reviews: typeof reviews;
  orders: typeof orders;
  conversations: typeof conversations;
  messages: typeof messages;
  notifications: typeof notifications;
  wishlists: typeof wishlists;
  wishlistItems: typeof wishlistItems;
  follows: typeof follows;
  returns: typeof returns;
  disputes: typeof disputes;
  reports: typeof reports;
  offers: typeof offers;
  sellerApplications: typeof sellerApplications;
  helpCategories: typeof helpCategories;
  helpArticles: typeof helpArticles;
  supportTickets: typeof supportTickets;
  homepageModules: typeof homepageModules;
  auditLogs: typeof auditLogs;
  platformSettings: typeof platformSettings;
  trendingSearches: typeof trendingSearches;
  collections: typeof collections;
  demoPasswords: Record<string, string>;
  savedSearches: Array<{
    id: string;
    userId: string;
    name: string;
    query: string;
    filters: Record<string, unknown>;
    sort: string;
    notify: boolean;
    createdAt: string;
  }>;
  carts: Array<[string, Cart]>;
  sessions: Array<[string, Session]>;
  idempotency: Array<[string, string]>;
  storeMembers: Array<{
    id: string;
    storeId: string;
    userId: string;
    role: string;
    permissions: string[];
    status: "active" | "invited" | "removed";
  }>;
};

function seedShape(): Omit<PersistedShape, "carts" | "sessions" | "idempotency"> & {
  carts: Map<string, Cart>;
  sessions: Map<string, Session>;
  idempotency: Map<string, string>;
  recentlyViewed: Map<string, string[]>;
} {
  return {
    users: clone(users),
    addresses: clone(addresses),
    categories: clone(categories),
    attributes: clone(attributes),
    brands: clone(brands),
    stores: clone(stores),
    products: clone(products),
    warehouses: clone(warehouses),
    inventory: clone(inventory),
    inventoryMovements: [] as InventoryMovement[],
    shippingMethods: clone(shippingMethods),
    promotions: clone(promotions),
    reviews: clone(reviews),
    orders: clone(orders),
    conversations: clone(conversations),
    messages: clone(messages),
    notifications: clone(notifications),
    wishlists: clone(wishlists),
    wishlistItems: clone(wishlistItems),
    follows: clone(follows),
    returns: clone(returns),
    disputes: clone(disputes),
    reports: clone(reports),
    offers: clone(offers),
    sellerApplications: clone(sellerApplications),
    helpCategories: clone(helpCategories),
    helpArticles: clone(helpArticles),
    supportTickets: clone(supportTickets),
    homepageModules: clone(homepageModules),
    auditLogs: clone(auditLogs),
    platformSettings: clone(platformSettings),
    trendingSearches: clone(trendingSearches),
    collections: clone(collections),
    demoPasswords: { ...demoPasswords },
    savedSearches: [],
    storeMembers: [],
    carts: new Map<string, Cart>(),
    sessions: new Map<string, Session>(),
    idempotency: new Map<string, string>(),
    recentlyViewed: new Map<string, string[]>(),
  };
}

export const mockDb = seedShape();

export function persistMockDb() {
  if (!canUseStorage()) return;
  const payload: PersistedShape = {
    users: mockDb.users,
    addresses: mockDb.addresses,
    categories: mockDb.categories,
    attributes: mockDb.attributes,
    brands: mockDb.brands,
    stores: mockDb.stores,
    products: mockDb.products,
    warehouses: mockDb.warehouses,
    inventory: mockDb.inventory,
    inventoryMovements: mockDb.inventoryMovements,
    shippingMethods: mockDb.shippingMethods,
    promotions: mockDb.promotions,
    reviews: mockDb.reviews,
    orders: mockDb.orders,
    conversations: mockDb.conversations,
    messages: mockDb.messages,
    notifications: mockDb.notifications,
    wishlists: mockDb.wishlists,
    wishlistItems: mockDb.wishlistItems,
    follows: mockDb.follows,
    returns: mockDb.returns,
    disputes: mockDb.disputes,
    reports: mockDb.reports,
    offers: mockDb.offers,
    sellerApplications: mockDb.sellerApplications,
    helpCategories: mockDb.helpCategories,
    helpArticles: mockDb.helpArticles,
    supportTickets: mockDb.supportTickets,
    homepageModules: mockDb.homepageModules,
    auditLogs: mockDb.auditLogs,
    platformSettings: mockDb.platformSettings,
    trendingSearches: mockDb.trendingSearches,
    collections: mockDb.collections,
    demoPasswords: mockDb.demoPasswords,
    savedSearches: mockDb.savedSearches,
    storeMembers: mockDb.storeMembers,
    carts: Array.from(mockDb.carts.entries()),
    sessions: Array.from(mockDb.sessions.entries()),
    idempotency: Array.from(mockDb.idempotency.entries()),
  };
  savePersistedJson("state", payload);
}

export function hydrateMockDbFromStorage() {
  const data = loadPersistedJson<PersistedShape>("state");
  if (!data) return;
  Object.assign(mockDb, {
    ...data,
    carts: new Map(data.carts || []),
    sessions: new Map(data.sessions || []),
    idempotency: new Map(data.idempotency || []),
    recentlyViewed: mockDb.recentlyViewed,
    inventoryMovements: data.inventoryMovements || [],
    storeMembers: data.storeMembers || [],
  });
}

if (canUseStorage()) {
  hydrateMockDbFromStorage();
}

export function resetMockDb() {
  const seeded = seedShape();
  Object.assign(mockDb, seeded);
  if (canUseStorage()) persistMockDb();
}

export function createId(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}

export function getOrCreateCart(key: string, userId?: string): Cart {
  const existing = mockDb.carts.get(key);
  if (existing) return existing;
  const cart: Cart = {
    id: createId("cart"),
    userId,
    items: [] as CartItem[],
    updatedAt: new Date().toISOString(),
  };
  mockDb.carts.set(key, cart);
  persistMockDb();
  return cart;
}

export function recordInventoryMovement(
  inventoryItemId: string,
  type: InventoryMovement["type"],
  quantityDelta: number,
  createdBy: string,
  note?: string
) {
  mockDb.inventoryMovements.unshift({
    id: createId("imov"),
    inventoryItemId,
    type,
    quantityDelta,
    note,
    createdAt: new Date().toISOString(),
    createdBy,
  });
}
