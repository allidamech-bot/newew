import { AppError } from "@/lib/errors";
import {
  adjustOnHand,
  applySnapshotToInventoryItem,
  applySnapshotToProduct,
  applySnapshotToVariant,
  availableStock,
  fulfillStock,
  releaseReservation,
  reserveStock,
  restockStock,
  snapshotFromInventoryItem,
  snapshotFromProduct,
  snapshotFromVariant,
} from "@/lib/inventory";
import { createId, mockDb, persistMockDb, recordInventoryMovement } from "@/mocks/db";
import type { InventoryItem, Product } from "@/types";

function touch() {
  persistMockDb();
}

function findOrCreateInventoryItem(
  product: Product,
  variantId: string | undefined
): InventoryItem {
  let item = mockDb.inventory.find(
    (i) =>
      i.productId === product.id &&
      (i.variantId || undefined) === (variantId || undefined)
  );
  if (item) return item;

  const variant = variantId
    ? product.variants.find((v) => v.id === variantId)
    : undefined;
  item = {
    id: createId("inv"),
    storeId: product.storeId,
    productId: product.id,
    variantId,
    warehouseId: `wh-${product.storeId}`,
    onHand: variant ? variant.quantity : product.quantity,
    reserved: variant ? variant.reservedQuantity : product.reservedQuantity,
    incoming: 0,
    lowStockThreshold: variant?.lowStockThreshold ?? product.lowStockThreshold,
  };
  mockDb.inventory.push(item);
  return item;
}

function syncProductMirror(productId: string, variantId: string | undefined, item: InventoryItem) {
  const pIdx = mockDb.products.findIndex((p) => p.id === productId);
  if (pIdx < 0) return;
  const product = mockDb.products[pIdx];
  if (variantId) {
    const variants = product.variants.map((v) =>
      v.id === variantId
        ? applySnapshotToVariant(v, { onHand: item.onHand, reserved: item.reserved })
        : v
    );
    // Mirror aggregate product.quantity as sum of variant available for UI convenience
    const onHand = variants.reduce((s, v) => s + v.quantity, 0);
    const reserved = variants.reduce((s, v) => s + v.reservedQuantity, 0);
    mockDb.products[pIdx] = {
      ...product,
      variants,
      quantity: onHand,
      reservedQuantity: reserved,
      status:
        onHand - reserved <= 0 && product.status === "published"
          ? "out_of_stock"
          : product.status === "out_of_stock" && onHand - reserved > 0
            ? "published"
            : product.status,
    };
  } else {
    mockDb.products[pIdx] = applySnapshotToProduct(product, {
      onHand: item.onHand,
      reserved: item.reserved,
    });
  }
}

export function getAvailableForSale(productId: string, variantId?: string): number {
  const product = mockDb.products.find((p) => p.id === productId);
  if (!product) return 0;
  const item = findOrCreateInventoryItem(product, variantId);
  return availableStock(item.onHand, item.reserved);
}

/** Checkout reservation: reserved += qty, on_hand unchanged */
export function reserveForCheckout(
  productId: string,
  variantId: string | undefined,
  qty: number,
  actorId: string,
  note?: string
): InventoryItem {
  const product = mockDb.products.find((p) => p.id === productId);
  if (!product) throw new AppError("PRODUCT_UNAVAILABLE", "Product not found");
  const item = findOrCreateInventoryItem(product, variantId);
  const next = reserveStock(snapshotFromInventoryItem(item), qty);
  const updated = applySnapshotToInventoryItem(item, next);
  const idx = mockDb.inventory.findIndex((i) => i.id === item.id);
  mockDb.inventory[idx] = updated;
  recordInventoryMovement(item.id, "sale", 0, actorId, note || "checkout reservation (reserved++)");
  // movement of reserved is tracked via reservation records conceptually; keep sale note non-destructive on on_hand
  syncProductMirror(productId, variantId, updated);
  touch();
  return updated;
}

/** Cancel before fulfillment: reserved -= qty */
export function releaseCheckoutReservation(
  productId: string,
  variantId: string | undefined,
  qty: number,
  actorId: string,
  note?: string
): InventoryItem {
  const product = mockDb.products.find((p) => p.id === productId);
  if (!product) throw new AppError("NOT_FOUND", "Product not found");
  const item = findOrCreateInventoryItem(product, variantId);
  const next = releaseReservation(snapshotFromInventoryItem(item), qty);
  const updated = applySnapshotToInventoryItem(item, next);
  const idx = mockDb.inventory.findIndex((i) => i.id === item.id);
  mockDb.inventory[idx] = updated;
  recordInventoryMovement(
    item.id,
    "cancellation_release",
    0,
    actorId,
    note || "release reservation (reserved--)"
  );
  syncProductMirror(productId, variantId, updated);
  touch();
  return updated;
}

/** Fulfillment: on_hand -= qty and reserved -= qty */
export function fulfillReservedStock(
  productId: string,
  variantId: string | undefined,
  qty: number,
  actorId: string,
  note?: string
): InventoryItem {
  const product = mockDb.products.find((p) => p.id === productId);
  if (!product) throw new AppError("NOT_FOUND", "Product not found");
  const item = findOrCreateInventoryItem(product, variantId);
  const next = fulfillStock(snapshotFromInventoryItem(item), qty);
  const updated = applySnapshotToInventoryItem(item, next);
  const idx = mockDb.inventory.findIndex((i) => i.id === item.id);
  mockDb.inventory[idx] = updated;
  recordInventoryMovement(item.id, "sale", -qty, actorId, note || "fulfillment (on_hand-- reserved--)");
  syncProductMirror(productId, variantId, updated);
  touch();
  return updated;
}

/** Restockable return: on_hand += qty */
export function restockReturned(
  productId: string,
  variantId: string | undefined,
  qty: number,
  actorId: string,
  note?: string
): InventoryItem {
  const product = mockDb.products.find((p) => p.id === productId);
  if (!product) throw new AppError("NOT_FOUND", "Product not found");
  const item = findOrCreateInventoryItem(product, variantId);
  const next = restockStock(snapshotFromInventoryItem(item), qty);
  const updated = applySnapshotToInventoryItem(item, next);
  const idx = mockDb.inventory.findIndex((i) => i.id === item.id);
  mockDb.inventory[idx] = updated;
  recordInventoryMovement(item.id, "return", qty, actorId, note || "restockable return");
  syncProductMirror(productId, variantId, updated);
  touch();
  return updated;
}

/** Damaged/non-restockable: movement only */
export function recordDamagedReturn(
  productId: string,
  variantId: string | undefined,
  qty: number,
  actorId: string,
  note?: string
) {
  const product = mockDb.products.find((p) => p.id === productId);
  if (!product) throw new AppError("NOT_FOUND", "Product not found");
  const item = findOrCreateInventoryItem(product, variantId);
  recordInventoryMovement(
    item.id,
    "damage",
    -qty,
    actorId,
    note || "non-restockable/damaged return (no on_hand change)"
  );
  touch();
}

export function manualAdjustOnHand(
  productId: string,
  variantId: string | undefined,
  delta: number,
  actorId: string,
  note?: string
): InventoryItem {
  const product = mockDb.products.find((p) => p.id === productId);
  if (!product) throw new AppError("NOT_FOUND", "Product not found");
  const item = findOrCreateInventoryItem(product, variantId);
  const next = adjustOnHand(snapshotFromInventoryItem(item), delta);
  const updated = applySnapshotToInventoryItem(item, next);
  const idx = mockDb.inventory.findIndex((i) => i.id === item.id);
  mockDb.inventory[idx] = updated;
  recordInventoryMovement(item.id, "manual_adjustment", delta, actorId, note);
  syncProductMirror(productId, variantId, updated);
  touch();
  return updated;
}

export function syncSeedInventoryFromProducts() {
  // Ensure inventory_items mirror product/variant on_hand with reserved=product.reserved
  for (const product of mockDb.products) {
    if (product.variants.length) {
      for (const v of product.variants) {
        const item = findOrCreateInventoryItem(product, v.id);
        // Normalize: treat product.quantity fields as on_hand historically
        item.onHand = v.quantity + v.reservedQuantity > v.quantity ? v.quantity + v.reservedQuantity : Math.max(v.quantity, v.reservedQuantity);
        // Better: if old model decreased quantity on sale, treat current quantity as available and reserved as 0 for seed
        item.onHand = Math.max(v.quantity, v.reservedQuantity);
        item.reserved = Math.min(v.reservedQuantity, item.onHand);
        // For seed simplicity: onHand = quantity (legacy available), reserved stays
        item.onHand = v.quantity + v.reservedQuantity;
        item.reserved = v.reservedQuantity;
        const vIdx = product.variants.findIndex((x) => x.id === v.id);
        product.variants[vIdx] = applySnapshotToVariant(v, {
          onHand: item.onHand,
          reserved: item.reserved,
        });
      }
      product.quantity = product.variants.reduce((s, v) => s + v.quantity, 0);
      product.reservedQuantity = product.variants.reduce((s, v) => s + v.reservedQuantity, 0);
    } else {
      const item = findOrCreateInventoryItem(product, undefined);
      item.onHand = product.quantity + product.reservedQuantity;
      item.reserved = product.reservedQuantity;
      const pIdx = mockDb.products.findIndex((p) => p.id === product.id);
      mockDb.products[pIdx] = applySnapshotToProduct(product, {
        onHand: item.onHand,
        reserved: item.reserved,
      });
    }
  }
}
