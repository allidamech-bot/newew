import Link from "next/link";
import { brand } from "@/config/brand";
import { Button } from "@/components/ui/button";

export const metadata = { title: "Trust And Safety" };

export default function Page() {
  return (
    <div className="container-sol py-10">
      <h1 className="text-3xl font-semibold tracking-tight">Trust And Safety</h1>
      <p className="mt-3 max-w-2xl text-[var(--muted-foreground)]">
        {brand.name} — {brand.tagline.en}. This page is part of the production information architecture and is ready for CMS content.
      </p>
      <div className="mt-6 flex flex-wrap gap-3">
        <Button asChild><Link href="/discover">Discover</Link></Button>
        <Button asChild variant="outline"><Link href="/contact">Contact support</Link></Button>
        <Button asChild variant="outline"><Link href="/seller/onboarding">Become a seller</Link></Button>
      </div>
    </div>
  );
}
