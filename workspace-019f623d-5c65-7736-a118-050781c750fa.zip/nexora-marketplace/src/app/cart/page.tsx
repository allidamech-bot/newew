"use client";

import Link from "next/link";
import Image from "next/image";
import { useEffect, useState } from "react";
import { useCartStore, cartTotals } from "@/features/cart/store";
import { PriceDisplay } from "@/components/commerce/price-display";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EmptyState } from "@/components/feedback/empty-state";
import { useLocaleStore, localize } from "@/i18n";
import { formatMoney, money, percentOf } from "@/lib/money";
import { getServices } from "@/services";
import type { Store } from "@/types";
import { toast } from "sonner";
import { useAuthStore } from "@/features/auth/store";
import { useRouter } from "next/navigation";

export default function CartPage() {
  const t = useLocaleStore((s) => s.t);
  const locale = useLocaleStore((s) => s.locale);
  const cart = useCartStore((s) => s.cart);
  const refresh = useCartStore((s) => s.refresh);
  const updateItem = useCartStore((s) => s.updateItem);
  const removeItem = useCartStore((s) => s.removeItem);
  const applyCoupon = useCartStore((s) => s.applyCoupon);
  const user = useAuthStore((s) => s.session?.user);
  const router = useRouter();
  const [coupon, setCoupon] = useState("");
  const [stores, setStores] = useState<Store[]>([]);

  useEffect(() => {
    void refresh();
    getServices()
      .stores.list({ pageSize: 100 })
      .then((r) => setStores(r.items));
  }, [refresh]);

  const items = cart?.items.filter((i) => !i.savedForLater) || [];
  const { subtotal } = cartTotals(cart);
  const storeMap = new Map(stores.map((s) => [s.id, s]));
  const grouped = items.reduce<Record<string, typeof items>>((acc, item) => {
    (acc[item.storeId] ??= []).push(item);
    return acc;
  }, {});

  if (!items.length) {
    return (
      <div className="container-sol py-10">
        <EmptyState
          title={t("cart.emptyTitle")}
          description={t("cart.emptyBody")}
          actionLabel={t("cart.emptyCta")}
          actionHref="/discover"
        />
      </div>
    );
  }

  const estimatedShipping = subtotal.amount >= 7500 ? money(0) : money(800);
  const tax = percentOf(money(subtotal.amount + estimatedShipping.amount), 8);
  const total = money(subtotal.amount + estimatedShipping.amount + tax.amount);

  return (
    <div className="container-sol py-8">
      <h1 className="text-3xl font-semibold tracking-tight">{t("cart.title")}</h1>
      <div className="mt-8 grid gap-8 lg:grid-cols-[1.4fr_0.8fr]">
        <div className="space-y-6">
          {Object.entries(grouped).map(([storeId, storeItems]) => (
            <section key={storeId} className="rounded-2xl border border-[var(--border)] bg-[var(--card)]">
              <div className="border-b border-[var(--border)] px-4 py-3 text-sm font-medium">
                {t("cart.soldBy")}{" "}
                <Link href={`/stores/${storeMap.get(storeId)?.slug || ""}`} className="text-[var(--primary)] hover:underline">
                  {storeMap.get(storeId)?.name || "Store"}
                </Link>
              </div>
              <ul className="divide-y divide-[var(--border)]">
                {storeItems.map((item) => (
                  <li key={item.id} className="flex gap-4 p-4">
                    <div className="relative h-24 w-20 shrink-0 overflow-hidden rounded-lg bg-[var(--muted)]">
                      <Image src={item.imageUrl || "/images/placeholder-product.svg"} alt="" fill className="object-cover" unoptimized />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-medium">{localize(item.title, locale)}</p>
                      <PriceDisplay price={item.unitPrice} size="sm" className="mt-1" />
                      <div className="mt-3 flex flex-wrap items-center gap-3">
                        <div className="inline-flex items-center rounded-md border border-[var(--border)]">
                          <button type="button" className="h-9 w-9" onClick={() => updateItem(item.id, item.quantity - 1)}>−</button>
                          <span className="w-8 text-center text-sm">{item.quantity}</span>
                          <button type="button" className="h-9 w-9" onClick={() => updateItem(item.id, item.quantity + 1)}>+</button>
                        </div>
                        <button
                          type="button"
                          className="text-sm text-[var(--muted-foreground)] hover:text-[var(--destructive)]"
                          onClick={async () => {
                            await removeItem(item.id);
                            toast.message(t("cart.itemRemoved"));
                          }}
                        >
                          {t("common.remove")}
                        </button>
                      </div>
                    </div>
                    <div className="text-sm font-semibold">
                      {formatMoney(money(item.unitPrice.amount * item.quantity, item.unitPrice.currency), locale)}
                    </div>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>

        <aside className="h-fit rounded-2xl border border-[var(--border)] bg-[var(--card)] p-5 lg:sticky lg:top-20">
          <h2 className="font-semibold">{t("cart.summary")}</h2>
          <div className="mt-4 flex gap-2">
            <Input
              value={coupon}
              onChange={(e) => setCoupon(e.target.value)}
              placeholder={t("cart.coupon")}
            />
            <Button
              variant="outline"
              onClick={async () => {
                try {
                  await applyCoupon(coupon);
                  toast.success("Coupon applied");
                } catch (e) {
                  toast.error(e instanceof Error ? e.message : "Invalid coupon");
                }
              }}
            >
              {t("cart.applyCoupon")}
            </Button>
          </div>
          {cart?.couponCode ? (
            <p className="mt-2 text-xs text-[var(--muted-foreground)]">Code: {cart.couponCode}</p>
          ) : null}
          <dl className="mt-5 space-y-2 text-sm">
            <div className="flex justify-between">
              <dt>{t("common.subtotal")}</dt>
              <dd>{formatMoney(subtotal, locale)}</dd>
            </div>
            <div className="flex justify-between">
              <dt>{t("common.shipping")}</dt>
              <dd>{estimatedShipping.amount === 0 ? t("common.free") : formatMoney(estimatedShipping, locale)}</dd>
            </div>
            <div className="flex justify-between">
              <dt>{t("common.tax")}</dt>
              <dd>{formatMoney(tax, locale)}</dd>
            </div>
            <div className="flex justify-between border-t border-[var(--border)] pt-3 text-base font-semibold">
              <dt>{t("cart.estimatedTotal")}</dt>
              <dd>{formatMoney(total, locale)}</dd>
            </div>
          </dl>
          <p className="mt-2 text-xs text-[var(--muted-foreground)]">{t("cart.feesNote")}</p>
          <Button
            className="mt-5 w-full"
            size="lg"
            onClick={() => {
              if (!user) {
                router.push("/auth/sign-in");
                return;
              }
              router.push("/checkout");
            }}
          >
            {t("cart.checkout")}
          </Button>
          <Button asChild variant="ghost" className="mt-2 w-full">
            <Link href="/discover">{t("cart.continueShopping")}</Link>
          </Button>
        </aside>
      </div>
    </div>
  );
}
