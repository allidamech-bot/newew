"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useCompareStore } from "@/features/compare/store";
import { getServices } from "@/services";
import type { Product } from "@/types";
import { PriceDisplay } from "@/components/commerce/price-display";
import { RatingDisplay } from "@/components/commerce/rating-display";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/feedback/empty-state";
import { useCartStore } from "@/features/cart/store";
import { toast } from "sonner";

export default function ComparePage() {
  const ids = useCompareStore((s) => s.productIds);
  const remove = useCompareStore((s) => s.remove);
  const clear = useCompareStore((s) => s.clear);
  const addItem = useCartStore((s) => s.addItem);
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const list = (
        await Promise.all(ids.map((id) => getServices().catalog.getProductById(id)))
      ).filter(Boolean) as Product[];
      if (!cancelled) setProducts(list);
    })();
    return () => {
      cancelled = true;
    };
  }, [ids]);

  if (!ids.length) {
    return (
      <div className="container-sol py-10">
        <EmptyState
          title="No products to compare"
          description="Add up to 4 products from discovery or product pages."
          actionLabel="Discover products"
          actionHref="/discover"
        />
      </div>
    );
  }

  const attrs = Array.from(
    new Set(products.flatMap((p) => Object.keys(p.attributes)))
  );

  return (
    <div className="container-sol py-8">
      <div className="mb-6 flex items-center justify-between gap-3">
        <h1 className="text-3xl font-semibold tracking-tight">Compare</h1>
        <Button variant="outline" onClick={clear}>
          Clear all
        </Button>
      </div>
      <div className="no-scrollbar overflow-x-auto">
        <table className="w-full min-w-[720px] border-collapse text-sm">
          <thead>
            <tr>
              <th className="sticky start-0 bg-[var(--background)] p-3 text-start font-medium">Feature</th>
              {products.map((p) => (
                <th key={p.id} className="min-w-[180px] p-3 text-start align-top">
                  <Link href={`/product/${p.slug}`} className="font-semibold hover:underline">
                    {p.title.en}
                  </Link>
                  <div className="mt-2">
                    <PriceDisplay price={p.basePrice} compareAt={p.compareAtPrice} size="sm" />
                  </div>
                  <RatingDisplay className="mt-1" rating={p.rating} count={p.reviewCount} />
                  <div className="mt-3 flex flex-col gap-2">
                    <Button
                      size="sm"
                      onClick={async () => {
                        await addItem(p.id, 1, p.variants[0]?.id);
                        toast.success("Added to cart");
                      }}
                    >
                      Add to cart
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => remove(p.id)}>
                      Remove
                    </Button>
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr className="border-t border-[var(--border)]">
              <td className="sticky start-0 bg-[var(--background)] p-3 font-medium">Type</td>
              {products.map((p) => (
                <td key={p.id} className="p-3 capitalize">
                  {p.type.replaceAll("_", " ")}
                </td>
              ))}
            </tr>
            <tr className="border-t border-[var(--border)]">
              <td className="sticky start-0 bg-[var(--background)] p-3 font-medium">Availability</td>
              {products.map((p) => (
                <td key={p.id} className="p-3">
                  {p.quantity > 0 ? "In stock" : "Out of stock"}
                </td>
              ))}
            </tr>
            {attrs.map((attr) => (
              <tr key={attr} className="border-t border-[var(--border)]">
                <td className="sticky start-0 bg-[var(--background)] p-3 font-medium capitalize">
                  {attr.replaceAll("_", " ")}
                </td>
                {products.map((p) => {
                  const val = p.attributes[attr];
                  return (
                    <td key={p.id} className="p-3">
                      {val == null ? "—" : Array.isArray(val) ? val.join(", ") : String(val)}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
