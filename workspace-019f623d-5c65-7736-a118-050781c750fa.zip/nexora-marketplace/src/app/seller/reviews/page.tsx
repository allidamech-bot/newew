"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Review } from "@/types";
import { RatingDisplay } from "@/components/commerce/rating-display";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/feedback/empty-state";
import { toast } from "sonner";

export default function SellerReviewsPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [items, setItems] = useState<Review[]>([]);
  const [response, setResponse] = useState<Record<string, string>>({});

  useEffect(() => {
    let cancelled = false;
    async function run() {
      if (!user) return;
      const stores = await getServices().stores.listByOwner(user.id);
      const store = stores[0] || (await getServices().stores.list({ pageSize: 1 })).items[0];
      if (!store || cancelled) return;
      const list = await getServices().reviews.listByStore(store.id);
      if (!cancelled) setItems(list);
    }
    void run();
    return () => {
      cancelled = true;
    };
  }, [user]);

  async function refresh() {
    if (!user) return;
    const stores = await getServices().stores.listByOwner(user.id);
    const store = stores[0] || (await getServices().stores.list({ pageSize: 1 })).items[0];
    if (!store) return;
    setItems(await getServices().reviews.listByStore(store.id));
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Reviews</h1>
      <div className="mt-6 space-y-3">
        {items.map((review) => (
          <article key={review.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <div className="flex items-center justify-between gap-3">
              <p className="font-semibold">{review.title.en}</p>
              <RatingDisplay rating={review.productRating} />
            </div>
            <p className="mt-2 text-sm text-[var(--muted-foreground)]">{review.body.en}</p>
            {review.sellerResponse ? (
              <p className="mt-3 rounded-lg bg-[var(--muted)]/50 p-3 text-sm">
                Response: {review.sellerResponse.body.en}
              </p>
            ) : (
              <div className="mt-3 space-y-2">
                <Textarea
                  value={response[review.id] || ""}
                  onChange={(e) => setResponse((r) => ({ ...r, [review.id]: e.target.value }))}
                  placeholder="Write a seller response"
                />
                <Button
                  size="sm"
                  onClick={async () => {
                    const body = response[review.id]?.trim();
                    if (!body) return;
                    await getServices().reviews.respond(review.id, { en: body, ar: body });
                    toast.success("Response published");
                    await refresh();
                  }}
                >
                  Respond
                </Button>
              </div>
            )}
          </article>
        ))}
        {!items.length ? (
          <EmptyState
            title="No reviews yet"
            description="Verified purchase reviews for your products will appear here."
          />
        ) : null}
      </div>
    </div>
  );
}
