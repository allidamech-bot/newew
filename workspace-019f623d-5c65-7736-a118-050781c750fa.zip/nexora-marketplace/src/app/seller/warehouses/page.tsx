"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Warehouse } from "@/types";
import type { WarehouseTransfer } from "@/repositories/management";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function SellerWarehousesPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [storeId, setStoreId] = useState("");
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [transfers, setTransfers] = useState<WarehouseTransfer[]>([]);
  const [name, setName] = useState("");
  const [transfer, setTransfer] = useState({
    fromWarehouseId: "",
    toWarehouseId: "",
    productId: "",
    quantity: "1",
  });

  async function load(id: string) {
    const services = getServices();
    setWarehouses(await services.sellerManagement.listWarehouses(id));
    setTransfers(await services.sellerManagement.listTransfers(id));
  }

  useEffect(() => {
    if (!user) return;
    (async () => {
      const stores = await getServices().stores.listByOwner(user.id);
      const store = stores[0];
      if (!store) return;
      setStoreId(store.id);
      await load(store.id);
    })();
  }, [user]);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold tracking-tight">Warehouses</h1>
      <form
        className="flex flex-wrap gap-2 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!storeId) return;
          await getServices().sellerManagement.createWarehouse({
            storeId,
            name,
            location: name,
            isDefault: warehouses.length === 0,
          });
          setName("");
          toast.success("Warehouse created");
          await load(storeId);
        }}
      >
        <div className="min-w-[220px] flex-1 space-y-1">
          <Label>Warehouse name</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} required />
        </div>
        <div className="flex items-end">
          <Button type="submit">Add warehouse</Button>
        </div>
      </form>

      <div className="grid gap-3 md:grid-cols-2">
        {warehouses.map((w) => (
          <div key={w.id} className="rounded-xl border border-[var(--border)] p-4">
            <p className="font-semibold">{w.name}</p>
            <p className="text-sm text-[var(--muted-foreground)]">
              {w.location} {w.isDefault ? "· Default" : ""}
            </p>
          </div>
        ))}
      </div>

      <section className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
        <h2 className="font-semibold">Stock transfer</h2>
        <form
          className="mt-3 grid gap-2 md:grid-cols-5"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!user || !storeId) return;
            await getServices().sellerManagement.transferStock({
              storeId,
              fromWarehouseId: transfer.fromWarehouseId,
              toWarehouseId: transfer.toWarehouseId,
              productId: transfer.productId,
              quantity: Number(transfer.quantity) || 1,
              createdBy: user.id,
              note: "Manual transfer",
            });
            toast.success("Transfer recorded");
            await load(storeId);
          }}
        >
          <select
            className="h-10 rounded-md border border-[var(--border)] bg-[var(--background)] px-2"
            value={transfer.fromWarehouseId}
            onChange={(e) => setTransfer((t) => ({ ...t, fromWarehouseId: e.target.value }))}
            required
          >
            <option value="">From</option>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>{w.name}</option>
            ))}
          </select>
          <select
            className="h-10 rounded-md border border-[var(--border)] bg-[var(--background)] px-2"
            value={transfer.toWarehouseId}
            onChange={(e) => setTransfer((t) => ({ ...t, toWarehouseId: e.target.value }))}
            required
          >
            <option value="">To</option>
            {warehouses.map((w) => (
              <option key={w.id} value={w.id}>{w.name}</option>
            ))}
          </select>
          <Input
            placeholder="Product ID"
            value={transfer.productId}
            onChange={(e) => setTransfer((t) => ({ ...t, productId: e.target.value }))}
            required
          />
          <Input
            type="number"
            value={transfer.quantity}
            onChange={(e) => setTransfer((t) => ({ ...t, quantity: e.target.value }))}
          />
          <Button type="submit">Transfer</Button>
        </form>
        <ul className="mt-4 space-y-2 text-sm">
          {transfers.map((t) => (
            <li key={t.id} className="rounded-lg border border-[var(--border)] p-2">
              {t.quantity} of {t.productId}: {t.fromWarehouseId} → {t.toWarehouseId}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
