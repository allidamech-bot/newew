"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { ReturnRequest } from "@/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/feedback/empty-state";
import { toast } from "sonner";

export default function SellerReturnsPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [items, setItems] = useState<ReturnRequest[]>([]);

  useEffect(() => {
    let cancelled = false;
    async function run() {
      if (!user) return;
      const stores = await getServices().stores.listByOwner(user.id);
      const store = stores[0] || (await getServices().stores.list({ pageSize: 1 })).items[0];
      if (!store || cancelled) return;
      const list = await getServices().returns.listByStore(store.id);
      if (!cancelled) setItems(list);
    }
    void run();
    return () => {
      cancelled = true;
    };
  }, [user]);

  async function refresh() {
    if (!user) return;
    const stores = await getServices().stores.listByOwner(user.id);
    const store = stores[0] || (await getServices().stores.list({ pageSize: 1 })).items[0];
    if (!store) return;
    setItems(await getServices().returns.listByStore(store.id));
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Returns</h1>
      <p className="mt-1 text-sm text-[var(--muted-foreground)]">
        Review buyer return requests for your store.
      </p>
      <div className="mt-6 space-y-3">
        {items.map((item) => (
          <div key={item.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-semibold">Order {item.orderId}</p>
                <p className="mt-1 text-sm text-[var(--muted-foreground)]">{item.reason}</p>
                {item.notes ? <p className="mt-1 text-sm">{item.notes}</p> : null}
              </div>
              <Badge className="capitalize">{item.status.replaceAll("_", " ")}</Badge>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button
                size="sm"
                onClick={async () => {
                  await getServices().returns.updateStatus(item.id, "approved", "Approved by seller");
                  toast.success("Return approved");
                  await refresh();
                }}
              >
                Approve
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={async () => {
                  await getServices().returns.updateStatus(item.id, "more_info_required", "Need more info");
                  toast.message("Requested more information");
                  await refresh();
                }}
              >
                Request info
              </Button>
              <Button
                size="sm"
                variant="destructive"
                onClick={async () => {
                  await getServices().returns.updateStatus(item.id, "rejected", "Rejected by seller");
                  toast.message("Return rejected");
                  await refresh();
                }}
              >
                Reject
              </Button>
            </div>
          </div>
        ))}
        {!items.length ? (
          <EmptyState
            title="No return requests"
            description="Buyer return requests for your store will appear here."
          />
        ) : null}
      </div>
    </div>
  );
}
