"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { ShippingMethod } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { fromMajor, formatMoney } from "@/lib/money";
import { toast } from "sonner";

export default function SellerShippingPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [storeId, setStoreId] = useState("");
  const [methods, setMethods] = useState<ShippingMethod[]>([]);
  const [form, setForm] = useState({
    name: "Store express",
    price: "12",
    minDays: "1",
    maxDays: "3",
  });

  async function load(id: string) {
    setMethods(await getServices().sellerManagement.listShippingMethods(id));
  }

  useEffect(() => {
    if (!user) return;
    (async () => {
      const stores = await getServices().stores.listByOwner(user.id);
      const store = stores[0];
      if (!store) return;
      setStoreId(store.id);
      await load(store.id);
    })();
  }, [user]);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold tracking-tight">Shipping methods</h1>
      <form
        className="grid gap-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 md:grid-cols-4"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!storeId) return;
          await getServices().sellerManagement.createShippingMethod({
            storeId,
            name: { en: form.name, ar: form.name },
            description: { en: form.name, ar: form.name },
            price: fromMajor(Number(form.price) || 0),
            minDays: Number(form.minDays) || 1,
            maxDays: Number(form.maxDays) || 3,
            enabled: true,
            type: "flat",
          });
          toast.success("Shipping method created");
          await load(storeId);
        }}
      >
        <div className="space-y-1 md:col-span-2">
          <Label>Name</Label>
          <Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} required />
        </div>
        <div className="space-y-1">
          <Label>Price</Label>
          <Input value={form.price} onChange={(e) => setForm((f) => ({ ...f, price: e.target.value }))} />
        </div>
        <div className="flex items-end">
          <Button type="submit" className="w-full">Add method</Button>
        </div>
      </form>
      <div className="space-y-3">
        {methods.map((m) => (
          <div key={m.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--border)] p-4">
            <div>
              <p className="font-semibold">{m.name.en}</p>
              <p className="text-sm text-[var(--muted-foreground)]">
                {formatMoney(m.price)} · {m.minDays}–{m.maxDays} days
              </p>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={async () => {
                await getServices().sellerManagement.updateShippingMethod(m.id, {
                  enabled: !m.enabled,
                });
                toast.success("Updated");
                await load(storeId);
              }}
            >
              {m.enabled ? "Disable" : "Enable"}
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}
