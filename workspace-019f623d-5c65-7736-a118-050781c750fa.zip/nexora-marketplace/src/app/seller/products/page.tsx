"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Product, Store } from "@/types";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatMoney } from "@/lib/money";
import { EmptyState } from "@/components/feedback/empty-state";

export default function SellerProductsPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [store, setStore] = useState<Store | null>(null);
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const stores = await getServices().stores.listByOwner(user.id);
      const active = stores[0];
      if (!active) {
        // Demo seller may own harbor/lumen depending on seed mapping
        const all = await getServices().stores.list({ pageSize: 20 });
        const fallback = all.items.find((s) => s.ownerId === user.id) || all.items[0];
        setStore(fallback || null);
        if (fallback) {
          const list = await getServices().catalog.listByStore(fallback.id, { pageSize: 100 });
          setProducts(list.items);
        }
        return;
      }
      setStore(active);
      const list = await getServices().catalog.listByStore(active.id, { pageSize: 100 });
      setProducts(list.items);
    })();
  }, [user]);

  return (
    <div>
      <div className="mb-6 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Products</h1>
          <p className="text-sm text-[var(--muted-foreground)]">{store?.name || "Store"}</p>
        </div>
        <Button asChild>
          <Link href="/seller/products/new">Add product</Link>
        </Button>
      </div>
      {!products.length ? (
        <EmptyState
          title="No products yet"
          description="Create your first product with the multi-step wizard."
          actionLabel="Create product"
          actionHref="/seller/products/new"
        />
      ) : (
        <div className="overflow-x-auto rounded-xl border border-[var(--border)]">
          <table className="w-full min-w-[720px] text-sm">
            <thead className="bg-[var(--muted)]/40 text-start">
              <tr>
                <th className="p-3 text-start font-medium">Product</th>
                <th className="p-3 text-start font-medium">Status</th>
                <th className="p-3 text-start font-medium">Price</th>
                <th className="p-3 text-start font-medium">Stock</th>
                <th className="p-3 text-start font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id} className="border-t border-[var(--border)]">
                  <td className="p-3">
                    <p className="font-medium">{p.title.en}</p>
                    <p className="text-xs text-[var(--muted-foreground)]">{p.slug}</p>
                  </td>
                  <td className="p-3">
                    <Badge variant="secondary" className="capitalize">
                      {p.status.replaceAll("_", " ")}
                    </Badge>
                  </td>
                  <td className="p-3">{formatMoney(p.basePrice)}</td>
                  <td className="p-3">{p.quantity}</td>
                  <td className="p-3">
                    <Button asChild size="sm" variant="outline">
                      <Link href={`/seller/products/${p.id}`}>Edit</Link>
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
