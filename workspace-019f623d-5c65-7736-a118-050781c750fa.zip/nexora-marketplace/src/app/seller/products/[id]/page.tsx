"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { getServices } from "@/services";
import type { Product } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { fromMajor, toMajor } from "@/lib/money";
import { toast } from "sonner";

export default function EditProductPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [product, setProduct] = useState<Product | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [quantity, setQuantity] = useState("");

  useEffect(() => {
    void getServices()
      .catalog.getProductById(params.id)
      .then((p) => {
        setProduct(p);
        if (p) {
          setTitle(p.title.en);
          setDescription(p.description.en);
          setPrice(String(toMajor(p.basePrice)));
          setQuantity(String(p.quantity));
        }
      });
  }, [params.id]);

  if (!product) {
    return <p className="text-sm text-[var(--muted-foreground)]">Loading product…</p>;
  }

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="text-2xl font-semibold tracking-tight">Edit product</h1>
      <p className="mt-1 text-sm text-[var(--muted-foreground)]">{product.slug}</p>
      <form
        className="mt-6 space-y-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-5"
        onSubmit={async (e) => {
          e.preventDefault();
          await getServices().catalog.updateProduct(product.id, {
            title: { en: title, ar: product.title.ar },
            description: { en: description, ar: product.description.ar },
            basePrice: fromMajor(Number(price) || 0),
            quantity: Number(quantity) || 0,
          });
          toast.success("Product updated");
          router.push("/seller/products");
        }}
      >
        <div className="space-y-1">
          <Label>Title</Label>
          <Input value={title} onChange={(e) => setTitle(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label>Description</Label>
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} />
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1">
            <Label>Price</Label>
            <Input value={price} onChange={(e) => setPrice(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>Quantity</Label>
            <Input value={quantity} onChange={(e) => setQuantity(e.target.value)} />
          </div>
        </div>
        <div className="flex gap-2">
          <Button type="submit">Save changes</Button>
          <Button
            type="button"
            variant="outline"
            onClick={async () => {
              await getServices().catalog.updateProduct(product.id, {
                status: product.status === "published" ? "paused" : "published",
              });
              toast.success("Visibility updated");
              router.refresh();
            }}
          >
            {product.status === "published" ? "Pause" : "Publish"}
          </Button>
        </div>
      </form>
    </div>
  );
}
