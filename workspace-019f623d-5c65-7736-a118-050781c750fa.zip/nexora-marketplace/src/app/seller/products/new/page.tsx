"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { AttributeDefinition, Category, Store } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { fromMajor } from "@/lib/money";
import { slugify } from "@/lib/utils";
import { toast } from "sonner";
import {
  generateVariantCombinations,
  productQualityScore,
  productWizardSchema,
  type ProductWizardValues,
} from "@/validation/product";

const steps = [
  "Type",
  "Basics",
  "Category",
  "Media",
  "Attributes",
  "Variants",
  "Pricing",
  "Inventory",
  "Delivery",
  "SEO",
  "Review",
] as const;

const DRAFT_KEY = "nexora-product-wizard-draft-v1";
const MAX_COMBOS = 100;

export default function NewProductPage() {
  const user = useAuthStore((s) => s.session?.user);
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [store, setStore] = useState<Store | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [attributes, setAttributes] = useState<AttributeDefinition[]>([]);
  const [saving, setSaving] = useState(false);
  const [bulkPrice, setBulkPrice] = useState("");
  const [bulkQty, setBulkQty] = useState("");

  const form = useForm<ProductWizardValues>({
    resolver: zodResolver(productWizardSchema) as never,
    defaultValues: {
      type: "physical",
      titleEn: "",
      titleAr: "",
      descriptionEn: "",
      descriptionAr: "",
      categoryId: "",
      price: 49,
      quantity: 10,
      sku: "",
      weightGrams: 500,
      requiresShipping: true,
      offersEnabled: false,
      seoTitle: "",
      seoDescription: "",
      digitalFileRef: "",
      serviceDurationMinutes: 60,
      processingDays: 2,
      returnDays: 14,
      attributes: {},
      media: [{ id: "m1", url: "/images/placeholder-product.svg", alt: "", isCover: true }],
      variantAxes: [],
      variants: [],
    },
    mode: "onChange",
  });

  const values = form.watch();
  const quality = useMemo(() => productQualityScore(values), [values]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const owned = await getServices().stores.listByOwner(user.id);
      const active = owned[0] || null;
      setStore(active);
      const cats = await getServices().categories.list();
      setCategories(cats);
      if (active && !form.getValues("categoryId")) {
        form.setValue("categoryId", cats[0]?.id || "");
      }
    })();
    // draft recovery
    try {
      const raw = localStorage.getItem(DRAFT_KEY);
      if (raw) {
        const draft = JSON.parse(raw) as ProductWizardValues;
        form.reset(draft);
        toast.message("Draft recovered");
      }
    } catch {
      // ignore
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // autosave
  useEffect(() => {
    const sub = form.watch((val) => {
      try {
        localStorage.setItem(DRAFT_KEY, JSON.stringify(val));
      } catch {
        // ignore
      }
    });
    return () => sub.unsubscribe();
  }, [form]);

  // dirty leave warning
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (form.formState.isDirty) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [form.formState.isDirty]);

  useEffect(() => {
    const categoryId = values.categoryId;
    if (!categoryId) return;
    void getServices()
      .categories.listAttributes(categoryId)
      .then(setAttributes);
  }, [values.categoryId]);

  function rebuildVariants() {
    const combos = generateVariantCombinations(values.variantAxes || []);
    if (combos.length > MAX_COMBOS) {
      toast.warning(`Too many combinations (${combos.length}). Limit is ${MAX_COMBOS}.`);
    }
    const limited = combos.slice(0, MAX_COMBOS);
    const next = limited.map((options, idx) => {
      const existing = (values.variants || []).find((v) =>
        Object.entries(options).every(([k, val]) => v.options[k] === val)
      );
      return (
        existing || {
          id: `var-${idx}-${Object.values(options).join("-")}`,
          options,
          sku: `${values.sku || "SKU"}-${Object.values(options)
            .map((v) => v.slice(0, 3).toUpperCase())
            .join("-")}`,
          price: values.price || 0,
          quantity: values.quantity || 0,
          enabled: true,
        }
      );
    });
    form.setValue("variants", next, { shouldDirty: true });
  }

  async function save(status: "draft" | "pending_review") {
    if (!user) return;
    const owned = await getServices().stores.listByOwner(user.id);
    const activeStore = owned[0];
    if (!activeStore) {
      toast.error("Create/approve a store before adding products");
      return;
    }
    const parsed = productWizardSchema.safeParse(form.getValues());
    if (!parsed.success && status === "pending_review") {
      const first = parsed.error.issues[0];
      toast.error(first?.message || "Fix validation errors");
      return;
    }
    const data = parsed.success ? parsed.data : form.getValues();
    setSaving(true);
    try {
      const product = await getServices().catalog.createProduct({
        storeId: activeStore.id,
        sellerId: user.id,
        type: data.type,
        title: { en: data.titleEn, ar: data.titleAr || data.titleEn },
        description: {
          en: data.descriptionEn,
          ar: data.descriptionAr || data.descriptionEn,
        },
        shortDescription: {
          en: data.descriptionEn.slice(0, 120),
          ar: (data.descriptionAr || data.descriptionEn).slice(0, 120),
        },
        categoryId: data.categoryId,
        slug: slugify(data.titleEn || "untitled-product"),
        basePrice: fromMajor(Number(data.price) || 0),
        quantity: Number(data.quantity) || 0,
        status,
        requiresShipping:
          data.type === "physical" || data.type === "made_to_order" || data.type === "preorder",
        media: (data.media || []).map((m, idx) => ({
          id: m.id || `media-${idx}`,
          bucket: "product-media",
          path: m.url,
          url: m.url,
          alt: { en: m.alt || data.titleEn, ar: m.alt || data.titleAr || data.titleEn },
          isCover: !!m.isCover || idx === 0,
          sortOrder: idx,
          moderationStatus: "pending" as const,
        })),
        attributes: data.attributes || {},
        variantOptions: (data.variantAxes || []).map((a) => ({
          name: a.name,
          values: a.values,
        })),
        variants: (data.variants || []).map((v, idx) => ({
          id: v.id || `var-${idx}`,
          productId: "pending",
          sku: v.sku,
          title: {
            en: Object.values(v.options).join(" / "),
            ar: Object.values(v.options).join(" / "),
          },
          options: v.options,
          price: fromMajor(Number(v.price) || 0),
          quantity: Number(v.quantity) || 0,
          reservedQuantity: 0,
          lowStockThreshold: 3,
          enabled: v.enabled,
          mediaIds: [],
        })),
        offersEnabled: !!data.offersEnabled,
        seoTitle: data.seoTitle ? { en: data.seoTitle, ar: data.seoTitle } : undefined,
        seoDescription: data.seoDescription
          ? { en: data.seoDescription, ar: data.seoDescription }
          : undefined,
        weightGrams: data.weightGrams,
        digitalFileRef: data.digitalFileRef,
        serviceDurationMinutes: data.serviceDurationMinutes,
        processingDays: data.processingDays,
        returnDays: data.returnDays,
      });
      if (product.variants.length) {
        await getServices().catalog.updateProduct(product.id, {
          variants: product.variants.map((v) => ({ ...v, productId: product.id })),
        });
      }
      localStorage.removeItem(DRAFT_KEY);
      toast.success(status === "draft" ? "Draft saved" : "Submitted for review");
      router.push("/seller/products");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not save product");
    } finally {
      setSaving(false);
    }
  }

  const fieldErrors = form.formState.errors;

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Product wizard</h1>
          <p className="text-sm text-[var(--muted-foreground)]">
            Store: {store?.name || "No owned store yet"} · Quality score {quality.score}%
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => void save("draft")} disabled={saving}>
            Save & exit
          </Button>
          <Button
            variant="secondary"
            onClick={() => {
              toast.message("Preview uses current form values");
              setStep(steps.length - 1);
            }}
          >
            Preview
          </Button>
        </div>
      </div>

      <div className="mb-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-3">
        <div className="mb-2 h-2 overflow-hidden rounded-full bg-[var(--muted)]">
          <div className="h-full bg-[var(--primary)]" style={{ width: `${quality.score}%` }} />
        </div>
        {quality.missing.length ? (
          <p className="text-xs text-[var(--muted-foreground)]">
            Missing: {quality.missing.join(", ")}
          </p>
        ) : (
          <p className="text-xs text-emerald-700 dark:text-emerald-300">Ready for high-quality publish</p>
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        {steps.map((label, i) => (
          <button
            key={label}
            type="button"
            onClick={() => setStep(i)}
            className={`rounded-full px-3 py-1 text-xs ${
              i === step
                ? "bg-[var(--primary)] text-[var(--primary-foreground)]"
                : "border border-[var(--border)] text-[var(--muted-foreground)]"
            }`}
          >
            {i + 1}. {label}
          </button>
        ))}
      </div>

      <div className="mt-6 space-y-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-5">
        {Object.keys(fieldErrors).length > 0 && step === steps.length - 1 ? (
          <div className="rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800 dark:border-red-900 dark:bg-red-950/40 dark:text-red-100">
            Validation summary:{" "}
            {Object.entries(fieldErrors)
              .map(([k, v]) => `${k}: ${(v as { message?: string })?.message || "invalid"}`)
              .join(" · ")}
          </div>
        ) : null}

        {step === 0 && (
          <div className="grid gap-2 sm:grid-cols-2">
            {(["physical", "digital", "service", "made_to_order", "preorder"] as const).map((type) => (
              <label
                key={type}
                className={`cursor-pointer rounded-lg border p-3 capitalize ${
                  values.type === type ? "border-[var(--primary)]" : "border-[var(--border)]"
                }`}
              >
                <input
                  type="radio"
                  className="me-2"
                  checked={values.type === type}
                  onChange={() => {
                    form.setValue("type", type, { shouldDirty: true });
                    form.setValue(
                      "requiresShipping",
                      type === "physical" || type === "made_to_order" || type === "preorder",
                      { shouldDirty: true }
                    );
                  }}
                />
                {type.replaceAll("_", " ")}
              </label>
            ))}
          </div>
        )}

        {step === 1 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>Title (English)</Label>
              <Input {...form.register("titleEn")} />
            </div>
            <div className="space-y-1">
              <Label>Title (Arabic)</Label>
              <Input dir="rtl" {...form.register("titleAr")} />
            </div>
            <div className="space-y-1">
              <Label>Description (English)</Label>
              <Textarea rows={5} {...form.register("descriptionEn")} />
            </div>
            <div className="space-y-1">
              <Label>Description (Arabic)</Label>
              <Textarea rows={5} dir="rtl" {...form.register("descriptionAr")} />
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-1">
            <Label>Category</Label>
            <select
              className="h-10 w-full rounded-md border border-[var(--border)] bg-[var(--background)] px-3"
              value={values.categoryId}
              onChange={(e) => form.setValue("categoryId", e.target.value, { shouldDirty: true })}
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name.en}
                </option>
              ))}
            </select>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>Add media URL</Label>
              <div className="flex gap-2">
                <Input id="media-url" placeholder="/images/products/example.svg" />
                <Button
                  type="button"
                  onClick={() => {
                    const el = document.getElementById("media-url") as HTMLInputElement | null;
                    const url = el?.value?.trim();
                    if (!url) return;
                    const media = [
                      ...(values.media || []),
                      {
                        id: `m-${Date.now()}`,
                        url,
                        alt: values.titleEn || "",
                        isCover: (values.media || []).length === 0,
                      },
                    ];
                    form.setValue("media", media, { shouldDirty: true });
                    if (el) el.value = "";
                  }}
                >
                  Add
                </Button>
              </div>
            </div>
            <ul className="space-y-2">
              {(values.media || []).map((m, idx) => (
                <li key={m.id} className="flex flex-wrap items-center gap-2 rounded-lg border border-[var(--border)] p-2">
                  <span className="text-xs text-[var(--muted-foreground)]">#{idx + 1}</span>
                  <Input
                    className="max-w-xs"
                    value={m.url}
                    onChange={(e) => {
                      const media = [...(values.media || [])];
                      media[idx] = { ...media[idx], url: e.target.value };
                      form.setValue("media", media, { shouldDirty: true });
                    }}
                  />
                  <Input
                    className="max-w-[180px]"
                    placeholder="Alt text"
                    value={m.alt || ""}
                    onChange={(e) => {
                      const media = [...(values.media || [])];
                      media[idx] = { ...media[idx], alt: e.target.value };
                      form.setValue("media", media, { shouldDirty: true });
                    }}
                  />
                  <Button
                    type="button"
                    size="sm"
                    variant={m.isCover ? "default" : "outline"}
                    onClick={() => {
                      const media = (values.media || []).map((item, i) => ({
                        ...item,
                        isCover: i === idx,
                      }));
                      form.setValue("media", media, { shouldDirty: true });
                    }}
                  >
                    Cover
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    disabled={idx === 0}
                    onClick={() => {
                      const media = [...(values.media || [])];
                      const [item] = media.splice(idx, 1);
                      media.splice(idx - 1, 0, item);
                      form.setValue("media", media, { shouldDirty: true });
                    }}
                  >
                    Up
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      const media = (values.media || []).filter((_, i) => i !== idx);
                      if (media.length && !media.some((x) => x.isCover)) media[0].isCover = true;
                      form.setValue("media", media, { shouldDirty: true });
                    }}
                  >
                    Remove
                  </Button>
                </li>
              ))}
            </ul>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-3">
            {!attributes.length ? (
              <p className="text-sm text-[var(--muted-foreground)]">
                No category attributes configured.
              </p>
            ) : (
              attributes.map((attr) => (
                <div key={attr.id} className="space-y-1">
                  <Label>
                    {attr.name.en}
                    {attr.required ? " *" : ""}
                  </Label>
                  {attr.options?.length ? (
                    <select
                      className="h-10 w-full rounded-md border border-[var(--border)] bg-[var(--background)] px-3"
                      value={String(values.attributes?.[attr.key] ?? "")}
                      onChange={(e) =>
                        form.setValue(
                          "attributes",
                          { ...(values.attributes || {}), [attr.key]: e.target.value },
                          { shouldDirty: true }
                        )
                      }
                    >
                      <option value="">Select</option>
                      {attr.options.map((opt) => (
                        <option key={opt.id} value={opt.value}>
                          {opt.label.en}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <Input
                      value={String(values.attributes?.[attr.key] ?? "")}
                      onChange={(e) =>
                        form.setValue(
                          "attributes",
                          { ...(values.attributes || {}), [attr.key]: e.target.value },
                          { shouldDirty: true }
                        )
                      }
                    />
                  )}
                </div>
              ))
            )}
          </div>
        )}

        {step === 5 && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Variant axes</Label>
              {(values.variantAxes || []).map((axis, axisIdx) => (
                <div key={axisIdx} className="rounded-lg border border-[var(--border)] p-3">
                  <div className="flex flex-wrap gap-2">
                    <Input
                      placeholder="Axis name (color, size...)"
                      value={axis.name}
                      onChange={(e) => {
                        const axes = [...(values.variantAxes || [])];
                        axes[axisIdx] = { ...axes[axisIdx], name: e.target.value };
                        form.setValue("variantAxes", axes, { shouldDirty: true });
                      }}
                    />
                    <Input
                      placeholder="values comma-separated"
                      value={axis.values.join(",")}
                      onChange={(e) => {
                        const axes = [...(values.variantAxes || [])];
                        axes[axisIdx] = {
                          ...axes[axisIdx],
                          values: e.target.value
                            .split(",")
                            .map((v) => v.trim())
                            .filter(Boolean),
                        };
                        form.setValue("variantAxes", axes, { shouldDirty: true });
                      }}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => {
                        const axes = (values.variantAxes || []).filter((_, i) => i !== axisIdx);
                        form.setValue("variantAxes", axes, { shouldDirty: true });
                      }}
                    >
                      Remove axis
                    </Button>
                  </div>
                </div>
              ))}
              <Button
                type="button"
                variant="outline"
                onClick={() =>
                  form.setValue(
                    "variantAxes",
                    [...(values.variantAxes || []), { name: "option", values: ["a", "b"] }],
                    { shouldDirty: true }
                  )
                }
              >
                Add axis
              </Button>
              <Button type="button" onClick={rebuildVariants}>
                Generate combinations
              </Button>
              {(values.variants || []).length > MAX_COMBOS ? (
                <p className="text-sm text-amber-700">Combination limit exceeded.</p>
              ) : null}
            </div>
            <div className="flex flex-wrap gap-2">
              <Input
                className="w-32"
                placeholder="Bulk price"
                value={bulkPrice}
                onChange={(e) => setBulkPrice(e.target.value)}
              />
              <Input
                className="w-32"
                placeholder="Bulk qty"
                value={bulkQty}
                onChange={(e) => setBulkQty(e.target.value)}
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  const variants = (values.variants || []).map((v) => ({
                    ...v,
                    price: bulkPrice ? Number(bulkPrice) : v.price,
                    quantity: bulkQty ? Number(bulkQty) : v.quantity,
                  }));
                  form.setValue("variants", variants, { shouldDirty: true });
                }}
              >
                Apply bulk edit
              </Button>
            </div>
            <div className="space-y-2">
              {(values.variants || []).map((variant, idx) => (
                <div key={variant.id} className="grid gap-2 rounded-lg border border-[var(--border)] p-3 md:grid-cols-5">
                  <div className="text-sm font-medium md:col-span-5">
                    {Object.entries(variant.options)
                      .map(([k, v]) => `${k}: ${v}`)
                      .join(" · ")}
                  </div>
                  <Input
                    value={variant.sku}
                    onChange={(e) => {
                      const variants = [...(values.variants || [])];
                      variants[idx] = { ...variants[idx], sku: e.target.value };
                      form.setValue("variants", variants, { shouldDirty: true });
                    }}
                    placeholder="SKU"
                  />
                  <Input
                    type="number"
                    value={variant.price}
                    onChange={(e) => {
                      const variants = [...(values.variants || [])];
                      variants[idx] = { ...variants[idx], price: Number(e.target.value) };
                      form.setValue("variants", variants, { shouldDirty: true });
                    }}
                    placeholder="Price"
                  />
                  <Input
                    type="number"
                    value={variant.quantity}
                    onChange={(e) => {
                      const variants = [...(values.variants || [])];
                      variants[idx] = { ...variants[idx], quantity: Number(e.target.value) };
                      form.setValue("variants", variants, { shouldDirty: true });
                    }}
                    placeholder="Qty"
                  />
                  <Input
                    value={variant.mediaUrl || ""}
                    onChange={(e) => {
                      const variants = [...(values.variants || [])];
                      variants[idx] = { ...variants[idx], mediaUrl: e.target.value };
                      form.setValue("variants", variants, { shouldDirty: true });
                    }}
                    placeholder="Media URL"
                  />
                  <label className="flex items-center gap-2 text-sm">
                    <input
                      type="checkbox"
                      checked={variant.enabled}
                      onChange={(e) => {
                        const variants = [...(values.variants || [])];
                        variants[idx] = { ...variants[idx], enabled: e.target.checked };
                        form.setValue("variants", variants, { shouldDirty: true });
                      }}
                    />
                    Enabled
                  </label>
                </div>
              ))}
            </div>
          </div>
        )}

        {step === 6 && (
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1">
              <Label>Base price</Label>
              <Input type="number" step="0.01" {...form.register("price")} />
            </div>
            <div className="space-y-1">
              <Label>SKU prefix</Label>
              <Input {...form.register("sku")} />
            </div>
            <label className="flex items-center gap-2 text-sm sm:col-span-2">
              <input type="checkbox" {...form.register("offersEnabled")} /> Enable offers
            </label>
          </div>
        )}

        {step === 7 && (
          <div className="space-y-1">
            <Label>Default quantity</Label>
            <Input type="number" {...form.register("quantity")} />
          </div>
        )}

        {step === 8 && (
          <div className="space-y-3">
            {(values.type === "physical" ||
              values.type === "made_to_order" ||
              values.type === "preorder") && (
              <>
                <div className="space-y-1">
                  <Label>Weight (grams)</Label>
                  <Input type="number" {...form.register("weightGrams")} />
                </div>
                <div className="space-y-1">
                  <Label>Processing days</Label>
                  <Input type="number" {...form.register("processingDays")} />
                </div>
                <div className="space-y-1">
                  <Label>Return days</Label>
                  <Input type="number" {...form.register("returnDays")} />
                </div>
              </>
            )}
            {values.type === "digital" && (
              <div className="space-y-1">
                <Label>Digital file reference</Label>
                <Input {...form.register("digitalFileRef")} placeholder="digital/files/kit.zip" />
              </div>
            )}
            {values.type === "service" && (
              <div className="space-y-1">
                <Label>Service duration (minutes)</Label>
                <Input type="number" {...form.register("serviceDurationMinutes")} />
              </div>
            )}
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" {...form.register("requiresShipping")} /> Requires shipping
            </label>
          </div>
        )}

        {step === 9 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>SEO title</Label>
              <Input {...form.register("seoTitle")} />
            </div>
            <div className="space-y-1">
              <Label>SEO description</Label>
              <Textarea {...form.register("seoDescription")} />
            </div>
          </div>
        )}

        {step === 10 && (
          <div className="space-y-2 text-sm">
            <p>
              <strong>Type:</strong> {values.type}
            </p>
            <p>
              <strong>Title:</strong> {values.titleEn} / {values.titleAr}
            </p>
            <p>
              <strong>Store:</strong> {store?.name || "—"}
            </p>
            <p>
              <strong>Price:</strong> ${values.price}
            </p>
            <p>
              <strong>Media:</strong> {(values.media || []).length}
            </p>
            <p>
              <strong>Variants:</strong> {(values.variants || []).length}
            </p>
            <p>
              <strong>Quality:</strong> {quality.score}%
            </p>
          </div>
        )}

        <div className="flex flex-wrap justify-between gap-2 pt-2">
          <Button type="button" variant="outline" disabled={step === 0} onClick={() => setStep((s) => s - 1)}>
            Back
          </Button>
          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="secondary" disabled={saving} onClick={() => void save("draft")}>
              Save draft
            </Button>
            {step < steps.length - 1 ? (
              <Button type="button" onClick={() => setStep((s) => s + 1)}>
                Continue
              </Button>
            ) : (
              <Button type="button" disabled={saving} onClick={() => void save("pending_review")}>
                {saving ? "Saving…" : "Submit for review"}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
