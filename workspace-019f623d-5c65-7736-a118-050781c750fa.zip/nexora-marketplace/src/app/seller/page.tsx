"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Order, Store } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatMoney, money } from "@/lib/money";
import { Button } from "@/components/ui/button";

export default function SellerDashboardPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [store, setStore] = useState<Store | null>(null);
  const [metrics, setMetrics] = useState<Awaited<
    ReturnType<ReturnType<typeof getServices>["analytics"]["sellerMetrics"]>
  > | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const stores = await getServices().stores.listByOwner(user.id);
      const active = stores[0] || (await getServices().stores.list({ pageSize: 1 })).items[0];
      if (!active) return;
      setStore(active);
      setMetrics(await getServices().analytics.sellerMetrics(active.id));
      setOrders(await getServices().orders.listByStore(active.id));
    })();
  }, [user]);

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Seller dashboard</h1>
          <p className="text-sm text-[var(--muted-foreground)]">
            {store ? store.name : "Loading store…"}
          </p>
        </div>
        <Button asChild>
          <Link href="/seller/products/new">Create product</Link>
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          {
            label: "Revenue",
            value: metrics ? formatMoney(money(metrics.revenueMinor)) : "—",
          },
          { label: "Orders", value: metrics?.orders ?? "—" },
          { label: "Units sold", value: metrics?.unitsSold ?? "—" },
          {
            label: "AOV",
            value: metrics ? formatMoney(money(metrics.aovMinor)) : "—",
          },
        ].map((item) => (
          <Card key={item.label}>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-[var(--muted-foreground)]">
                {item.label}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-2xl font-semibold">{item.value}</CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Today&apos;s priorities</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <p>Pending orders: {metrics?.pendingOrders ?? 0}</p>
            <p>Low-stock SKUs: {metrics?.lowStock ?? 0}</p>
            <p>Followers: {metrics?.followers ?? 0}</p>
            <p>Conversion (mock sample): {metrics?.conversion ?? 0}%</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Recent orders</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {orders.slice(0, 5).map((o) => (
              <Link
                key={o.id}
                href={`/seller/orders/${o.id}`}
                className="flex items-center justify-between rounded-lg border border-[var(--border)] px-3 py-2 text-sm hover:border-[var(--primary)]"
              >
                <span>
                  {o.orderNumber}
                  <span className="ms-2 capitalize text-[var(--muted-foreground)]">
                    {o.status.replaceAll("_", " ")}
                  </span>
                </span>
                <span className="font-medium">{formatMoney(o.total)}</span>
              </Link>
            ))}
            {!orders.length ? (
              <p className="text-sm text-[var(--muted-foreground)]">No store orders yet.</p>
            ) : null}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
