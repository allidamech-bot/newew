"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Order } from "@/types";
import { formatMoney } from "@/lib/money";
import { Badge } from "@/components/ui/badge";

export default function SellerOrdersPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const stores = await getServices().stores.listByOwner(user.id);
      const storeIds = stores.map((s) => s.id);
      if (!storeIds.length) {
        // include all for admin/demo visibility if no owned store
        const allStores = await getServices().stores.list({ pageSize: 50 });
        const ids = allStores.items.filter((s) => s.ownerId === user.id).map((s) => s.id);
        const lists = await Promise.all(
          (ids.length ? ids : allStores.items.slice(0, 1).map((s) => s.id)).map((id) =>
            getServices().orders.listByStore(id)
          )
        );
        setOrders(lists.flat());
        return;
      }
      const lists = await Promise.all(storeIds.map((id) => getServices().orders.listByStore(id)));
      setOrders(lists.flat());
    })();
  }, [user]);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Orders</h1>
      <div className="mt-6 space-y-3">
        {orders.map((order) => (
          <Link
            key={order.id}
            href={`/seller/orders/${order.id}`}
            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 hover:border-[var(--primary)]"
          >
            <div>
              <p className="font-semibold">{order.orderNumber}</p>
              <p className="text-sm text-[var(--muted-foreground)]">
                {new Date(order.createdAt).toLocaleString()} · {order.items.length} item(s)
              </p>
            </div>
            <div className="text-end">
              <Badge className="capitalize">{order.status.replaceAll("_", " ")}</Badge>
              <p className="mt-2 font-semibold">{formatMoney(order.total)}</p>
            </div>
          </Link>
        ))}
        {!orders.length ? (
          <p className="text-sm text-[var(--muted-foreground)]">No orders for your stores yet.</p>
        ) : null}
      </div>
    </div>
  );
}
