"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { getServices } from "@/services";
import type { Order, OrderStatus } from "@/types";
import { formatMoney } from "@/lib/money";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

const transitions: OrderStatus[] = [
  "confirmed",
  "preparing",
  "shipped",
  "out_for_delivery",
  "delivered",
  "completed",
];

export default function SellerOrderDetailPage() {
  const params = useParams<{ id: string }>();
  const [order, setOrder] = useState<Order | null>(null);

  useEffect(() => {
    void getServices().orders.getById(params.id).then(setOrder);
  }, [params.id]);

  if (!order) return <p className="text-sm text-[var(--muted-foreground)]">Loading…</p>;

  return (
    <div className="max-w-3xl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{order.orderNumber}</h1>
          <Badge className="mt-2 capitalize">{order.status.replaceAll("_", " ")}</Badge>
        </div>
        <p className="text-xl font-semibold">{formatMoney(order.total)}</p>
      </div>

      <section className="mt-6 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
        <h2 className="font-semibold">Items</h2>
        <ul className="mt-3 space-y-2 text-sm">
          {order.items.map((item) => (
            <li key={item.id} className="flex justify-between gap-3">
              <span>
                {item.title.en} × {item.quantity}
              </span>
              <span>{formatMoney(item.total)}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 text-sm">
        <h2 className="font-semibold">Ship to</h2>
        <p className="mt-2">{order.shippingAddress.fullName}</p>
        <p className="text-[var(--muted-foreground)]">
          {order.shippingAddress.line1}, {order.shippingAddress.city}, {order.shippingAddress.country}
        </p>
      </section>

      <section className="mt-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
        <h2 className="font-semibold">Update fulfillment</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {transitions.map((status) => (
            <Button
              key={status}
              size="sm"
              variant="outline"
              className="capitalize"
              onClick={async () => {
                const updated = await getServices().orders.updateStatus(
                  order.id,
                  status,
                  `Seller marked ${status}`
                );
                setOrder(updated);
                toast.success(`Status: ${status}`);
              }}
            >
              {status.replaceAll("_", " ")}
            </Button>
          ))}
        </div>
      </section>

      <section className="mt-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
        <h2 className="font-semibold">Timeline</h2>
        <ol className="mt-3 space-y-2 text-sm">
          {order.timeline.map((event, idx) => (
            <li key={`${event.at}-${idx}`}>
              <span className="font-medium capitalize">
                {String(event.status).replaceAll("_", " ")}
              </span>
              <span className="text-[var(--muted-foreground)]">
                {" "}
                · {new Date(event.at).toLocaleString()}
                {event.note ? ` · ${event.note}` : ""}
              </span>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
