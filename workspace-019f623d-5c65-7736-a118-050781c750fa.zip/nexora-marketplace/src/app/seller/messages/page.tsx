"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Conversation } from "@/types";
import { EmptyState } from "@/components/feedback/empty-state";

export default function SellerMessagesPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [items, setItems] = useState<Conversation[]>([]);

  useEffect(() => {
    if (!user) return;
    void getServices().conversations.listForUser(user.id).then(setItems);
  }, [user]);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Messages</h1>
      <div className="mt-6 space-y-2">
        {items.map((c) => (
          <Link key={c.id} href={`/account/messages/${c.id}`} className="block rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 hover:border-[var(--primary)]">
            <p className="font-semibold">{c.subject}</p>
            <p className="mt-1 line-clamp-1 text-sm text-[var(--muted-foreground)]">{c.lastMessagePreview}</p>
          </Link>
        ))}
        {!items.length ? (
          <EmptyState title="No conversations" description="Customer product and order inquiries will appear here." />
        ) : null}
      </div>
    </div>
  );
}
