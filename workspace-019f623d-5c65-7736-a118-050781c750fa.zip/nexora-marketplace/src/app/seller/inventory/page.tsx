"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { InventoryItem, Product } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function SellerInventoryPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [products, setProducts] = useState<Record<string, Product>>({});
  const [adjustments, setAdjustments] = useState<Record<string, string>>({});

  async function load() {
    if (!user) return;
    const stores = await getServices().stores.listByOwner(user.id);
    const store = stores[0] || (await getServices().stores.list({ pageSize: 1 })).items[0];
    if (!store) return;
    const inventory = await getServices().inventory.listByStore(store.id);
    setItems(inventory);
    const productList = await getServices().catalog.listByStore(store.id, { pageSize: 100 });
    setProducts(Object.fromEntries(productList.items.map((p) => [p.id, p])));
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Inventory</h1>
      <p className="mt-1 text-sm text-[var(--muted-foreground)]">
        On hand, reserved, and available stock by product/variant.
      </p>
      <div className="mt-6 overflow-x-auto rounded-xl border border-[var(--border)]">
        <table className="w-full min-w-[800px] text-sm">
          <thead className="bg-[var(--muted)]/40">
            <tr>
              <th className="p-3 text-start">Product</th>
              <th className="p-3 text-start">On hand</th>
              <th className="p-3 text-start">Reserved</th>
              <th className="p-3 text-start">Available</th>
              <th className="p-3 text-start">Adjust</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => {
              const product = products[item.productId];
              const available = item.onHand - item.reserved;
              const low = available <= item.lowStockThreshold;
              return (
                <tr key={item.id} className="border-t border-[var(--border)]">
                  <td className="p-3">
                    <p className="font-medium">{product?.title.en || item.productId}</p>
                    <p className="text-xs text-[var(--muted-foreground)]">
                      {item.variantId || "default"}
                      {low ? " · low stock" : ""}
                    </p>
                  </td>
                  <td className="p-3">{item.onHand}</td>
                  <td className="p-3">{item.reserved}</td>
                  <td className="p-3">{available}</td>
                  <td className="p-3">
                    <div className="flex gap-2">
                      <Input
                        className="h-9 w-24"
                        placeholder="+/- qty"
                        value={adjustments[item.id] || ""}
                        onChange={(e) =>
                          setAdjustments((a) => ({ ...a, [item.id]: e.target.value }))
                        }
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={async () => {
                          const delta = Number(adjustments[item.id] || 0);
                          if (!delta || !user) return;
                          await getServices().inventory.adjust({
                            productId: item.productId,
                            variantId: item.variantId,
                            delta,
                            actorId: user.id,
                            note: "Manual adjustment",
                          });
                          toast.success("Inventory updated");
                          await load();
                        }}
                      >
                        Apply
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
