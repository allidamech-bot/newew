"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Promotion } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { fromMajor } from "@/lib/money";

export default function SellerPromotionsPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [storeId, setStoreId] = useState("");
  const [items, setItems] = useState<Promotion[]>([]);
  const [form, setForm] = useState({
    name: "",
    code: "",
    type: "percentage" as Promotion["type"],
    value: "10",
    minOrder: "0",
  });

  async function load(id: string) {
    setItems(await getServices().sellerManagement.listPromotions(id));
  }

  useEffect(() => {
    if (!user) return;
    (async () => {
      const stores = await getServices().stores.listByOwner(user.id);
      const store = stores[0];
      if (!store) return;
      setStoreId(store.id);
      await load(store.id);
    })();
  }, [user]);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold tracking-tight">Promotions & coupons</h1>
      <form
        className="grid gap-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 md:grid-cols-2"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!storeId) return;
          const startsAt = new Date().toISOString();
          const endsAt = new Date(Date.now() + 30 * 86400000).toISOString();
          await getServices().sellerManagement.createPromotion({
            storeId,
            platformWide: false,
            name: { en: form.name, ar: form.name },
            type: form.type,
            value: Number(form.value),
            minOrder: fromMajor(Number(form.minOrder) || 0),
            code: form.code || undefined,
            startsAt,
            endsAt,
            stackable: false,
            active: true,
          });
          toast.success("Promotion created");
          setForm({ name: "", code: "", type: "percentage", value: "10", minOrder: "0" });
          await load(storeId);
        }}
      >
        <div className="space-y-1">
          <Label>Name</Label>
          <Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} required />
        </div>
        <div className="space-y-1">
          <Label>Code</Label>
          <Input value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))} />
        </div>
        <div className="space-y-1">
          <Label>Type</Label>
          <select
            className="h-10 w-full rounded-md border border-[var(--border)] bg-[var(--background)] px-3"
            value={form.type}
            onChange={(e) => setForm((f) => ({ ...f, type: e.target.value as Promotion["type"] }))}
          >
            <option value="percentage">Percentage</option>
            <option value="fixed">Fixed</option>
            <option value="free_shipping">Free shipping</option>
          </select>
        </div>
        <div className="space-y-1">
          <Label>Value</Label>
          <Input value={form.value} onChange={(e) => setForm((f) => ({ ...f, value: e.target.value }))} />
        </div>
        <div className="space-y-1">
          <Label>Min order</Label>
          <Input value={form.minOrder} onChange={(e) => setForm((f) => ({ ...f, minOrder: e.target.value }))} />
        </div>
        <div className="flex items-end">
          <Button type="submit" className="w-full">Create promotion</Button>
        </div>
      </form>

      <div className="space-y-3">
        {items.map((p) => (
          <div key={p.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--border)] p-4">
            <div>
              <p className="font-semibold">{p.name.en}</p>
              <p className="text-sm text-[var(--muted-foreground)]">
                {p.code || "no code"} · {p.type} · {p.value}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={p.active ? "success" : "secondary"}>{p.active ? "Active" : "Disabled"}</Badge>
              <Button
                size="sm"
                variant="outline"
                onClick={async () => {
                  await getServices().sellerManagement.updatePromotion(p.id, { active: !p.active });
                  toast.success("Updated");
                  await load(storeId);
                }}
              >
                {p.active ? "Disable" : "Enable"}
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
