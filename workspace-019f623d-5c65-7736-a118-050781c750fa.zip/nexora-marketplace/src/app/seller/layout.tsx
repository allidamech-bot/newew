"use client";

import { usePathname } from "next/navigation";
import { DashboardShell } from "@/components/layout/dashboard-shell";
import { sellerNavItems } from "@/features/seller/seller-nav";

export default function SellerLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const onboardingOnly = pathname.startsWith("/seller/onboarding");

  return (
    <DashboardShell
      title="Seller workspace"
      requiredRoles={
        onboardingOnly
          ? ["buyer", "seller", "store_staff", "admin", "super_admin"]
          : ["seller", "store_staff", "admin", "super_admin"]
      }
      nav={sellerNavItems.map((i) => ({ href: i.href, label: i.label }))}
    >
      {children}
    </DashboardShell>
  );
}
