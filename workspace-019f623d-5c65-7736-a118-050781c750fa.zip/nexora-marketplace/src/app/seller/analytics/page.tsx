"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatMoney, money } from "@/lib/money";

export default function SellerAnalyticsPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [metrics, setMetrics] = useState<Awaited<ReturnType<ReturnType<typeof getServices>["analytics"]["sellerMetrics"]>> | null>(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const stores = await getServices().stores.listByOwner(user.id);
      const store = stores[0] || (await getServices().stores.list({ pageSize: 1 })).items[0];
      if (!store) return;
      setMetrics(await getServices().analytics.sellerMetrics(store.id));
    })();
  }, [user]);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Analytics</h1>
      <p className="mt-1 text-sm text-[var(--muted-foreground)]">Mock analytics repository — metrics are clearly sample-backed.</p>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          ["Revenue", metrics ? formatMoney(money(metrics.revenueMinor)) : "—"],
          ["Orders", metrics?.orders ?? "—"],
          ["Units sold", metrics?.unitsSold ?? "—"],
          ["AOV", metrics ? formatMoney(money(metrics.aovMinor)) : "—"],
          ["Conversion", metrics ? `${metrics.conversion}%` : "—"],
          ["Product views", metrics?.productViews ?? "—"],
          ["Store views", metrics?.storeViews ?? "—"],
          ["Low stock", metrics?.lowStock ?? "—"],
        ].map(([label, value]) => (
          <Card key={String(label)}>
            <CardHeader><CardTitle className="text-sm text-[var(--muted-foreground)]">{label}</CardTitle></CardHeader>
            <CardContent className="text-2xl font-semibold">{value}</CardContent>
          </Card>
        ))}
      </div>
      <div className="mt-6 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
        <h2 className="font-semibold">Top products</h2>
        <ul className="mt-3 space-y-2 text-sm">
          {(metrics?.topProducts || []).map((p) => (
            <li key={p.productId} className="flex justify-between gap-3">
              <span>{p.title}</span>
              <span className="text-[var(--muted-foreground)]">{p.sales} sales</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
