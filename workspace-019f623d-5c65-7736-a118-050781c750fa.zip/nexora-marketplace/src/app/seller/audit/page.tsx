"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";

export default function SellerAuditPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [rows, setRows] = useState<
    Array<{ id: string; action: string; entityType: string; entityId: string; createdAt: string; actorId: string }>
  >([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const stores = await getServices().stores.listByOwner(user.id);
      const store = stores[0];
      if (!store) return;
      setRows(await getServices().sellerManagement.listAudit(store.id));
    })();
  }, [user]);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Store audit history</h1>
      <div className="mt-6 space-y-2">
        {rows.map((row) => (
          <div key={row.id} className="rounded-xl border border-[var(--border)] p-4 text-sm">
            <p className="font-semibold">{row.action}</p>
            <p className="text-[var(--muted-foreground)]">
              {row.entityType}:{row.entityId} · {row.actorId}
            </p>
            <p className="text-xs text-[var(--muted-foreground)]">
              {new Date(row.createdAt).toLocaleString()}
            </p>
          </div>
        ))}
        {!rows.length ? (
          <p className="text-sm text-[var(--muted-foreground)]">No store audit events yet.</p>
        ) : null}
      </div>
    </div>
  );
}
