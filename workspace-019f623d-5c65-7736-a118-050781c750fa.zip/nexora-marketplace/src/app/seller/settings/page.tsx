"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function SellerSettingsPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Store settings</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {[
          ["Payout settings", "Placeholder for connected payout accounts. No raw bank data stored locally."],
          ["Tax settings", "Tax behavior is calculated at order time; jurisdiction config is provider-ready."],
          ["Notification preferences", "Order, message, and inventory alerts for store members."],
          ["Audit history", "High-risk store changes write to the platform audit log repository."],
        ].map(([title, body]) => (
          <Card key={title}>
            <CardHeader><CardTitle className="text-base">{title}</CardTitle></CardHeader>
            <CardContent className="text-sm text-[var(--muted-foreground)]">{body}</CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
