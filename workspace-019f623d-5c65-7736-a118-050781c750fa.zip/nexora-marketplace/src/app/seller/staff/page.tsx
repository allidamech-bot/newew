"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { StoreStaffMember } from "@/repositories/management";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

const rolePerms: Record<StoreStaffMember["role"], string[]> = {
  store_admin: ["*"],
  catalog_manager: ["catalog.manage", "media.manage"],
  inventory_manager: ["inventory.manage"],
  order_manager: ["orders.manage", "returns.manage"],
  customer_support: ["messages.manage", "reviews.respond"],
  marketing_manager: ["promotions.manage"],
  analyst: ["analytics.read"],
};

export default function SellerStaffPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [storeId, setStoreId] = useState("");
  const [staff, setStaff] = useState<StoreStaffMember[]>([]);
  const [form, setForm] = useState({
    name: "",
    email: "",
    role: "catalog_manager" as StoreStaffMember["role"],
  });

  async function load(id: string) {
    setStaff(await getServices().sellerManagement.listStaff(id));
  }

  useEffect(() => {
    if (!user) return;
    (async () => {
      const stores = await getServices().stores.listByOwner(user.id);
      const store = stores[0];
      if (!store) return;
      setStoreId(store.id);
      await load(store.id);
    })();
  }, [user]);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold tracking-tight">Staff & permissions</h1>
      <form
        className="grid gap-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 md:grid-cols-4"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!storeId) return;
          await getServices().sellerManagement.inviteStaff({
            storeId,
            name: form.name,
            email: form.email,
            role: form.role,
            permissions: rolePerms[form.role],
          });
          toast.success("Invitation created");
          setForm({ name: "", email: "", role: "catalog_manager" });
          await load(storeId);
        }}
      >
        <div className="space-y-1">
          <Label>Name</Label>
          <Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} required />
        </div>
        <div className="space-y-1">
          <Label>Email</Label>
          <Input type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} required />
        </div>
        <div className="space-y-1">
          <Label>Role</Label>
          <select
            className="h-10 w-full rounded-md border border-[var(--border)] bg-[var(--background)] px-3"
            value={form.role}
            onChange={(e) => setForm((f) => ({ ...f, role: e.target.value as StoreStaffMember["role"] }))}
          >
            {Object.keys(rolePerms).map((role) => (
              <option key={role} value={role}>
                {role.replaceAll("_", " ")}
              </option>
            ))}
          </select>
        </div>
        <div className="flex items-end">
          <Button type="submit" className="w-full">Invite</Button>
        </div>
      </form>
      <div className="space-y-3">
        {staff.map((member) => (
          <div key={member.id} className="rounded-xl border border-[var(--border)] p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-semibold">{member.name}</p>
                <p className="text-sm text-[var(--muted-foreground)]">
                  {member.email} · {member.role.replaceAll("_", " ")}
                </p>
                <p className="mt-1 text-xs text-[var(--muted-foreground)]">
                  Permissions: {member.permissions.join(", ")}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Badge className="capitalize">{member.status}</Badge>
                {member.status !== "active" ? (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={async () => {
                      await getServices().sellerManagement.updateStaff(member.id, {
                        status: "active",
                      });
                      await load(storeId);
                    }}
                  >
                    Activate
                  </Button>
                ) : null}
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={async () => {
                    await getServices().sellerManagement.removeStaff(member.id);
                    toast.message("Staff removed");
                    await load(storeId);
                  }}
                >
                  Remove
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
