"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import { EmptyState } from "@/components/feedback/empty-state";

export default function SellerCustomersPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [rows, setRows] = useState<Array<{ buyerId: string; orders: number }>>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const stores = await getServices().stores.listByOwner(user.id);
      const store = stores[0] || (await getServices().stores.list({ pageSize: 1 })).items[0];
      if (!store) return;
      const orders = await getServices().orders.listByStore(store.id);
      const map = new Map<string, number>();
      orders.forEach((o) => map.set(o.buyerId, (map.get(o.buyerId) || 0) + 1));
      setRows(Array.from(map.entries()).map(([buyerId, count]) => ({ buyerId, orders: count })));
    })();
  }, [user]);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Customers</h1>
      <div className="mt-6 space-y-2">
        {rows.map((row) => (
          <div key={row.buyerId} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 text-sm">
            <p className="font-semibold">{row.buyerId}</p>
            <p className="text-[var(--muted-foreground)]">{row.orders} order(s)</p>
          </div>
        ))}
        {!rows.length ? <EmptyState title="No customers yet" description="Buyers who purchase from your store will appear here." /> : null}
      </div>
    </div>
  );
}
