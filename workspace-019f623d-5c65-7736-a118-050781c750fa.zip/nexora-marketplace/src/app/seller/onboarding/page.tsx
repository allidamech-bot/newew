"use client";

import { useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useRouter } from "next/navigation";
import { getServices } from "@/services";
import { slugify } from "@/lib/utils";

const steps = [
  "Seller type",
  "Identity",
  "Store",
  "Categories",
  "Policies",
  "Documents",
  "Review",
] as const;

export default function SellerOnboardingPage() {
  const user = useAuthStore((s) => s.session?.user);
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    sellerType: "individual",
    legalName: user?.displayName || "",
    storeName: "",
    storeSlug: "",
    description: "",
    categories: "home-living",
    returnsPolicy: "14-day returns on unused items",
    shippingOrigin: "Istanbul, TR",
    documentName: "id-document.pdf",
  });

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="text-2xl font-semibold tracking-tight">Seller onboarding</h1>
      <p className="mt-1 text-sm text-[var(--muted-foreground)]">
        Complete the application to open a store on NEXORA.
      </p>
      <ol className="mt-4 flex flex-wrap gap-2">
        {steps.map((label, i) => (
          <li
            key={label}
            className={`rounded-full px-3 py-1 text-xs ${
              i === step
                ? "bg-[var(--primary)] text-[var(--primary-foreground)]"
                : "border border-[var(--border)] text-[var(--muted-foreground)]"
            }`}
          >
            {i + 1}. {label}
          </li>
        ))}
      </ol>

      <div className="mt-6 space-y-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-5">
        {step === 0 && (
          <div className="space-y-3">
            {["individual", "business"].map((type) => (
              <label key={type} className="flex items-center gap-2 capitalize">
                <input
                  type="radio"
                  checked={form.sellerType === type}
                  onChange={() => setForm((f) => ({ ...f, sellerType: type }))}
                />
                {type}
              </label>
            ))}
          </div>
        )}
        {step === 1 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>Legal name</Label>
              <Input
                value={form.legalName}
                onChange={(e) => setForm((f) => ({ ...f, legalName: e.target.value }))}
              />
            </div>
            <p className="text-xs text-[var(--muted-foreground)]">
              Identity documents stay private and are never exposed publicly.
            </p>
          </div>
        )}
        {step === 2 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>Store name</Label>
              <Input
                value={form.storeName}
                onChange={(e) =>
                  setForm((f) => ({
                    ...f,
                    storeName: e.target.value,
                    storeSlug: slugify(e.target.value),
                  }))
                }
              />
            </div>
            <div className="space-y-1">
              <Label>Slug</Label>
              <Input
                value={form.storeSlug}
                onChange={(e) => setForm((f) => ({ ...f, storeSlug: slugify(e.target.value) }))}
              />
            </div>
            <div className="space-y-1">
              <Label>Description</Label>
              <Textarea
                value={form.description}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              />
            </div>
          </div>
        )}
        {step === 3 && (
          <div className="space-y-1">
            <Label>Primary categories (comma separated slugs)</Label>
            <Input
              value={form.categories}
              onChange={(e) => setForm((f) => ({ ...f, categories: e.target.value }))}
            />
          </div>
        )}
        {step === 4 && (
          <div className="space-y-3">
            <div className="space-y-1">
              <Label>Return policy</Label>
              <Textarea
                value={form.returnsPolicy}
                onChange={(e) => setForm((f) => ({ ...f, returnsPolicy: e.target.value }))}
              />
            </div>
            <div className="space-y-1">
              <Label>Shipping origin</Label>
              <Input
                value={form.shippingOrigin}
                onChange={(e) => setForm((f) => ({ ...f, shippingOrigin: e.target.value }))}
              />
            </div>
          </div>
        )}
        {step === 5 && (
          <div className="space-y-1">
            <Label>Document reference</Label>
            <Input
              value={form.documentName}
              onChange={(e) => setForm((f) => ({ ...f, documentName: e.target.value }))}
            />
            <p className="text-xs text-[var(--muted-foreground)]">
              Mock upload reference only — private seller-documents bucket later.
            </p>
          </div>
        )}
        {step === 6 && (
          <div className="space-y-2 text-sm">
            <p>
              <strong>Type:</strong> {form.sellerType}
            </p>
            <p>
              <strong>Store:</strong> {form.storeName || "—"} ({form.storeSlug || "—"})
            </p>
            <p>
              <strong>Categories:</strong> {form.categories}
            </p>
            <p>
              <strong>Origin:</strong> {form.shippingOrigin}
            </p>
            <p className="text-[var(--muted-foreground)]">
              Submitting marks the application as under review in mock mode and unlocks seller tools for demo accounts.
            </p>
          </div>
        )}

        <div className="flex justify-between pt-2">
          <Button variant="outline" disabled={step === 0} onClick={() => setStep((s) => s - 1)}>
            Back
          </Button>
          {step < steps.length - 1 ? (
            <Button onClick={() => setStep((s) => s + 1)}>Continue</Button>
          ) : (
            <Button
              onClick={async () => {
                if (!user) return;
                await getServices().audit.write({
                  actorId: user.id,
                  action: "seller_application.submit",
                  entityType: "seller_application",
                  entityId: user.id,
                  metadata: { storeName: form.storeName, storeSlug: form.storeSlug },
                });
                toast.success("Application submitted for review");
                router.push("/seller");
              }}
            >
              Submit application
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
