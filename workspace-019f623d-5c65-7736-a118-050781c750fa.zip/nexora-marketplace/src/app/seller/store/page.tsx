"use client";

import { useEffect, useState } from "react";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Store } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import Link from "next/link";

export default function SellerStorePage() {
  const user = useAuthStore((s) => s.session?.user);
  const [store, setStore] = useState<Store | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [announcement, setAnnouncement] = useState("");

  useEffect(() => {
    if (!user) return;
    (async () => {
      const stores = await getServices().stores.listByOwner(user.id);
      const active = stores[0] || (await getServices().stores.list({ pageSize: 1 })).items[0];
      if (!active) return;
      setStore(active);
      setName(active.name);
      setDescription(active.description.en);
      setAnnouncement(active.announcement?.en || "");
    })();
  }, [user]);

  if (!store) return <p className="text-sm text-[var(--muted-foreground)]">Loading store…</p>;

  return (
    <div className="max-w-2xl">
      <div className="mb-6 flex items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold tracking-tight">Store profile</h1>
        <Button asChild variant="outline">
          <Link href={`/stores/${store.slug}`}>View public storefront</Link>
        </Button>
      </div>
      <form
        className="space-y-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-5"
        onSubmit={async (e) => {
          e.preventDefault();
          const updated = await getServices().stores.updateStore(store.id, {
            name,
            description: { en: description, ar: store.description.ar },
            announcement: announcement
              ? { en: announcement, ar: store.announcement?.ar || announcement }
              : undefined,
          });
          setStore(updated);
          toast.success("Store updated");
        }}
      >
        <div className="space-y-1">
          <Label>Store name</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label>Description</Label>
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} />
        </div>
        <div className="space-y-1">
          <Label>Announcement</Label>
          <Input value={announcement} onChange={(e) => setAnnouncement(e.target.value)} />
        </div>
        <p className="text-xs text-[var(--muted-foreground)]">
          Accent color and branding use approved options only — no arbitrary CSS/JS.
        </p>
        <Button type="submit">Save store</Button>
      </form>
    </div>
  );
}
