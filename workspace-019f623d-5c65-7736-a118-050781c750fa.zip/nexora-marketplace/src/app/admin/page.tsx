"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatMoney, money } from "@/lib/money";

export default function AdminOverviewPage() {
  const [metrics, setMetrics] = useState<Awaited<
    ReturnType<ReturnType<typeof getServices>["analytics"]["platformMetrics"]>
  > | null>(null);

  useEffect(() => {
    void getServices().analytics.platformMetrics().then(setMetrics);
  }, []);

  const cards = [
    { label: "GMV", value: metrics ? formatMoney(money(metrics.gmvMinor)) : "—" },
    { label: "Orders", value: metrics?.orders ?? "—" },
    { label: "Active buyers", value: metrics?.activeBuyers ?? "—" },
    { label: "Active sellers", value: metrics?.activeSellers ?? "—" },
    { label: "Open disputes", value: metrics?.openDisputes ?? "—" },
    { label: "Open reports", value: metrics?.openReports ?? "—" },
    { label: "Pending products", value: metrics?.pendingProducts ?? "—" },
    { label: "Pending applications", value: metrics?.pendingApplications ?? "—" },
  ];

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Admin overview</h1>
      <p className="mt-1 text-sm text-[var(--muted-foreground)]">
        Platform health and moderation queues (mock analytics repository).
      </p>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((card) => (
          <Card key={card.label}>
            <CardHeader>
              <CardTitle className="text-sm font-medium text-[var(--muted-foreground)]">
                {card.label}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-2xl font-semibold">{card.value}</CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
