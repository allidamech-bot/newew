"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatMoney, money } from "@/lib/money";

export default function AdminAnalyticsPage() {
  const [metrics, setMetrics] = useState<Awaited<ReturnType<ReturnType<typeof getServices>["analytics"]["platformMetrics"]>> | null>(null);
  useEffect(() => {
    void getServices().analytics.platformMetrics().then(setMetrics);
  }, []);
  const cards = [
    ["GMV", metrics ? formatMoney(money(metrics.gmvMinor)) : "—"],
    ["Orders", metrics?.orders ?? "—"],
    ["Active buyers", metrics?.activeBuyers ?? "—"],
    ["Active sellers", metrics?.activeSellers ?? "—"],
    ["Open disputes", metrics?.openDisputes ?? "—"],
    ["Open reports", metrics?.openReports ?? "—"],
    ["Pending products", metrics?.pendingProducts ?? "—"],
    ["Pending applications", metrics?.pendingApplications ?? "—"],
  ];
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Platform analytics</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map(([label, value]) => (
          <Card key={String(label)}>
            <CardHeader><CardTitle className="text-sm text-[var(--muted-foreground)]">{label}</CardTitle></CardHeader>
            <CardContent className="text-2xl font-semibold">{value}</CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
