"use client";
import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { TransactionRecord } from "@/repositories/management";
import { formatMoney } from "@/lib/money";
export default function AdminTransactionsPage() {
  const [rows, setRows] = useState<TransactionRecord[]>([]);
  useEffect(() => { void getServices().adminManagement.listTransactions().then(setRows); }, []);
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Transactions</h1>
      <div className="mt-6 space-y-2">
        {rows.map((r) => (
          <div key={r.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--border)] p-4">
            <div>
              <p className="font-semibold">{r.orderNumber}</p>
              <p className="text-sm text-[var(--muted-foreground)]">{r.method} · {r.status}</p>
            </div>
            <p className="font-semibold">{formatMoney(r.amount)}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
