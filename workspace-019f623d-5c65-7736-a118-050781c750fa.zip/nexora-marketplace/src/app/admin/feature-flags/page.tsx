"use client";

import { useState } from "react";
import { defaultFeatureFlags, type FeatureFlagKey } from "@/config/features";
import { toast } from "sonner";

// lightweight local switch if radix switch exists
function FlagSwitch({
  checked,
  onCheckedChange,
}: {
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onCheckedChange(!checked)}
      className={`relative h-6 w-11 rounded-full transition ${
        checked ? "bg-[var(--primary)]" : "bg-[var(--muted)]"
      }`}
    >
      <span
        className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition ${
          checked ? "start-5" : "start-0.5"
        }`}
      />
    </button>
  );
}

export default function FeatureFlagsPage() {
  const [flags, setFlags] = useState(defaultFeatureFlags);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Feature flags</h1>
      <p className="mt-1 text-sm text-[var(--muted-foreground)]">
        Mock configuration source. Later loadable from platform_settings / feature_flags tables.
      </p>
      <div className="mt-6 space-y-3">
        {(Object.keys(flags) as FeatureFlagKey[]).map((key) => (
          <div
            key={key}
            className="flex items-center justify-between rounded-xl border border-[var(--border)] bg-[var(--card)] px-4 py-3"
          >
            <div>
              <p className="font-medium">{key}</p>
              <p className="text-xs text-[var(--muted-foreground)]">
                {flags[key] ? "Enabled" : "Disabled"}
              </p>
            </div>
            <FlagSwitch
              checked={flags[key]}
              onCheckedChange={(value) => {
                setFlags((f) => ({ ...f, [key]: value }));
                toast.message(`${key}: ${value ? "on" : "off"}`);
              }}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
