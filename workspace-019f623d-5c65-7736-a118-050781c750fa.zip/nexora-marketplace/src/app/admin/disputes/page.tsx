"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { Dispute } from "@/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/feedback/empty-state";
import { toast } from "sonner";

export default function AdminDisputesPage() {
  const [items, setItems] = useState<Dispute[]>([]);
  async function load() {
    setItems(await getServices().disputes.list());
  }
  useEffect(() => { void load(); }, []);
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Disputes</h1>
      <div className="mt-6 space-y-3">
        {items.map((d) => (
          <div key={d.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <p className="font-semibold">Order {d.orderId}</p>
                <p className="text-sm text-[var(--muted-foreground)]">{d.reason}</p>
              </div>
              <Badge className="capitalize">{d.status.replaceAll("_", " ")}</Badge>
            </div>
            <div className="mt-3 flex gap-2">
              <Button size="sm" onClick={async () => {
                await getServices().disputes.updateStatus(d.id, "under_review", "Moderator review");
                toast.message("Under review");
                await load();
              }}>Review</Button>
              <Button size="sm" variant="outline" onClick={async () => {
                await getServices().disputes.updateStatus(d.id, "resolved", "Resolved for buyer");
                toast.success("Resolved");
                await load();
              }}>Resolve</Button>
            </div>
          </div>
        ))}
        {!items.length ? <EmptyState title="No disputes" description="Escalated order cases will appear here." /> : null}
      </div>
    </div>
  );
}
