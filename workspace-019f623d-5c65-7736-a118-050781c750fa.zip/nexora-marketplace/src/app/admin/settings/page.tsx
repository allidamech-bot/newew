"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { PlatformSettings } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuthStore } from "@/features/auth/store";
import { toast } from "sonner";

export default function AdminSettingsPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [settings, setSettings] = useState<PlatformSettings | null>(null);
  const [confirm, setConfirm] = useState(false);

  useEffect(() => {
    void getServices().adminManagement.getSettings().then(setSettings);
  }, []);

  if (!settings) return <p className="text-sm text-[var(--muted-foreground)]">Loading…</p>;

  return (
    <div className="max-w-xl space-y-4">
      <h1 className="text-2xl font-semibold tracking-tight">Platform settings</h1>
      <div className="space-y-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={settings.maintenanceMode}
            onChange={(e) => setSettings({ ...settings, maintenanceMode: e.target.checked })}
          />
          Maintenance mode
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={settings.sellerRegistrationOpen}
            onChange={(e) =>
              setSettings({ ...settings, sellerRegistrationOpen: e.target.checked })
            }
          />
          Seller registration open
        </label>
        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={settings.requireProductModeration}
            onChange={(e) =>
              setSettings({ ...settings, requireProductModeration: e.target.checked })
            }
          />
          Require product moderation
        </label>
        <div className="space-y-1">
          <Label>Default commission %</Label>
          <Input
            type="number"
            value={settings.defaultCommissionPercent}
            onChange={(e) =>
              setSettings({
                ...settings,
                defaultCommissionPercent: Number(e.target.value) || 0,
              })
            }
          />
        </div>
        <div className="space-y-1">
          <Label>Return window days</Label>
          <Input
            type="number"
            value={settings.returnWindowDays}
            onChange={(e) =>
              setSettings({
                ...settings,
                returnWindowDays: Number(e.target.value) || 0,
              })
            }
          />
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={confirm} onChange={(e) => setConfirm(e.target.checked)} />
          I confirm this high-risk configuration change
        </label>
        <Button
          disabled={!confirm || !user}
          onClick={async () => {
            if (!user) return;
            const updated = await getServices().adminManagement.updateSettings(settings, user.id);
            setSettings(updated);
            setConfirm(false);
            toast.success("Settings saved and audited");
          }}
        >
          Save settings
        </Button>
      </div>
    </div>
  );
}
