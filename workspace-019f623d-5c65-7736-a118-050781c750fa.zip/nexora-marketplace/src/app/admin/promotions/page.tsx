"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { Promotion } from "@/types";
import { Badge } from "@/components/ui/badge";

export default function AdminPromotionsPage() {
  const [items, setItems] = useState<Promotion[]>([]);
  useEffect(() => { void getServices().promotions.listActive().then(setItems); }, []);
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Promotions</h1>
      <div className="mt-6 space-y-3">
        {items.map((p) => (
          <div key={p.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="font-semibold">{p.name.en}</p>
                <p className="text-sm text-[var(--muted-foreground)]">{p.code || "no code"} · {p.type} · {p.value}</p>
              </div>
              <Badge>{p.platformWide ? "Platform" : "Store"}</Badge>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
