"use client";
import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { NotificationCampaign } from "@/repositories/management";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
export default function AdminCampaignsPage() {
  const [rows, setRows] = useState<NotificationCampaign[]>([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  async function load(){ setRows(await getServices().adminManagement.listCampaigns()); }
  useEffect(()=>{ void load(); }, []);
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold tracking-tight">Notification campaigns</h1>
      <form className="space-y-2 rounded-xl border border-[var(--border)] p-4" onSubmit={async (e)=>{
        e.preventDefault();
        const camp = await getServices().adminManagement.upsertCampaign({
          title: { en: title, ar: title },
          body: { en: body, ar: body },
          audience: "all",
          channel: "in_app",
          status: "draft",
        });
        toast.success("Campaign drafted");
        setTitle(""); setBody("");
        await load();
        void camp;
      }}>
        <Input placeholder="Title" value={title} onChange={(e)=>setTitle(e.target.value)} required />
        <Textarea placeholder="Body" value={body} onChange={(e)=>setBody(e.target.value)} required />
        <Button type="submit">Save draft</Button>
      </form>
      <div className="space-y-2">
        {rows.map((c)=>(
          <div key={c.id} className="flex items-center justify-between rounded-xl border border-[var(--border)] p-4">
            <div>
              <p className="font-semibold">{c.title.en}</p>
              <p className="text-sm text-[var(--muted-foreground)]">{c.status} · {c.channel}</p>
            </div>
            {c.status !== "sent" ? (
              <Button size="sm" onClick={async ()=>{
                await getServices().adminManagement.sendCampaign(c.id);
                toast.success("Campaign sent");
                await load();
              }}>Send</Button>
            ) : null}
          </div>
        ))}
      </div>
    </div>
  );
}
