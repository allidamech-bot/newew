"use client";
import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { SupportTicket } from "@/types";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useAuthStore } from "@/features/auth/store";
import { toast } from "sonner";
export default function AdminSupportPage() {
  const user = useAuthStore(s=>s.session?.user);
  const [rows, setRows] = useState<SupportTicket[]>([]);
  const [active, setActive] = useState<string>("");
  const [reply, setReply] = useState("");
  async function load(){ setRows(await getServices().adminManagement.listSupportTickets()); }
  useEffect(()=>{ void load(); }, []);
  const ticket = rows.find(r=>r.id===active) || rows[0];
  return (
    <div className="grid gap-4 lg:grid-cols-[280px_1fr]">
      <div className="space-y-2">
        <h1 className="text-xl font-semibold">Support tickets</h1>
        {rows.map(r=>(
          <button key={r.id} type="button" onClick={()=>setActive(r.id)} className="block w-full rounded-lg border border-[var(--border)] p-3 text-start text-sm">
            <p className="font-medium">{r.subject}</p>
            <p className="text-[var(--muted-foreground)]">{r.status}</p>
          </button>
        ))}
      </div>
      <div className="rounded-xl border border-[var(--border)] p-4">
        {ticket ? (
          <>
            <h2 className="font-semibold">{ticket.subject}</h2>
            <div className="mt-3 space-y-2">
              {ticket.messages.map(m=>(
                <div key={m.id} className="rounded-lg bg-[var(--muted)]/40 p-2 text-sm">
                  <p>{m.body}</p>
                  <p className="text-xs text-[var(--muted-foreground)]">{m.senderId} · {new Date(m.createdAt).toLocaleString()}</p>
                </div>
              ))}
            </div>
            <form className="mt-4 space-y-2" onSubmit={async (e)=>{
              e.preventDefault();
              if(!user||!ticket) return;
              await getServices().adminManagement.replySupportTicket(ticket.id, user.id, reply);
              setReply("");
              toast.success("Reply sent");
              await load();
            }}>
              <Textarea value={reply} onChange={(e)=>setReply(e.target.value)} required />
              <Button type="submit">Reply</Button>
            </form>
          </>
        ) : <p className="text-sm text-[var(--muted-foreground)]">No tickets</p>}
      </div>
    </div>
  );
}
