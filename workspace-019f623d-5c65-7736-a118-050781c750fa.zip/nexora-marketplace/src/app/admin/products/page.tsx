"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { Product } from "@/types";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);

  async function load() {
    const pending = await getServices().moderation.listPendingProducts();
    // also show published sample for moderation tools demo
    const published = await getServices().catalog.listProducts({ pageSize: 12 });
    setProducts([...pending, ...published.items.filter((p) => !pending.find((x) => x.id === p.id))]);
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Product moderation</h1>
      <div className="mt-6 space-y-3">
        {products.map((p) => (
          <div
            key={p.id}
            className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4"
          >
            <div>
              <p className="font-semibold">{p.title.en}</p>
              <p className="text-sm text-[var(--muted-foreground)]">{p.slug}</p>
              <div className="mt-2 flex gap-2">
                <Badge variant="secondary" className="capitalize">
                  {p.status.replaceAll("_", " ")}
                </Badge>
                <Badge variant="outline" className="capitalize">
                  {p.moderationStatus.replaceAll("_", " ")}
                </Badge>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                onClick={async () => {
                  await getServices().moderation.moderateProduct(p.id, "approved", "Looks good");
                  toast.success("Approved");
                  await load();
                }}
              >
                Approve
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={async () => {
                  await getServices().moderation.moderateProduct(
                    p.id,
                    "changes_requested",
                    "Need clearer media"
                  );
                  toast.message("Changes requested");
                  await load();
                }}
              >
                Request changes
              </Button>
              <Button
                size="sm"
                variant="destructive"
                onClick={async () => {
                  await getServices().moderation.moderateProduct(p.id, "rejected", "Policy violation");
                  toast.message("Rejected");
                  await load();
                }}
              >
                Reject
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
