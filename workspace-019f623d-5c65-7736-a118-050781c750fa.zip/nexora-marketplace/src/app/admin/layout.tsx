"use client";

import { DashboardShell } from "@/components/layout/dashboard-shell";
import { adminNavItems } from "@/features/admin/admin-nav";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <DashboardShell
      title="Admin platform"
      requiredRoles={["admin", "super_admin", "moderator"]}
      nav={adminNavItems.map((i) => ({ href: i.href, label: i.label }))}
    >
      {children}
    </DashboardShell>
  );
}
