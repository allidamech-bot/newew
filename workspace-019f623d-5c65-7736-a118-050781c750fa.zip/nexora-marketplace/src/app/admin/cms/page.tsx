"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { HomepageModuleRecord } from "@/repositories/management";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export default function AdminCmsPage() {
  const [modules, setModules] = useState<HomepageModuleRecord[]>([]);
  const [title, setTitle] = useState("");

  async function load() {
    setModules(await getServices().adminManagement.listHomepageModules());
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold tracking-tight">CMS · Homepage modules</h1>
      <form
        className="flex flex-wrap gap-2"
        onSubmit={async (e) => {
          e.preventDefault();
          await getServices().adminManagement.upsertHomepageModule({
            type: "editorial",
            title: { en: title, ar: title },
            visible: true,
            sortOrder: modules.length,
          });
          setTitle("");
          toast.success("Module created");
          await load();
        }}
      >
        <Input
          className="max-w-md"
          placeholder="New module title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <Button type="submit">Create module</Button>
      </form>
      <div className="space-y-2">
        {modules.map((mod, idx) => (
          <div key={mod.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--border)] p-4">
            <div>
              <p className="font-semibold">{mod.title.en}</p>
              <p className="text-sm text-[var(--muted-foreground)]">
                {mod.type} · order {mod.sortOrder}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Badge variant={mod.visible ? "success" : "secondary"}>
                {mod.visible ? "Visible" : "Hidden"}
              </Badge>
              <Button
                size="sm"
                variant="outline"
                onClick={async () => {
                  await getServices().adminManagement.upsertHomepageModule({
                    ...mod,
                    visible: !mod.visible,
                  });
                  await load();
                }}
              >
                {mod.visible ? "Hide" : "Publish"}
              </Button>
              <Button
                size="sm"
                variant="ghost"
                disabled={idx === 0}
                onClick={async () => {
                  const ids = modules.map((m) => m.id);
                  const next = [...ids];
                  const [item] = next.splice(idx, 1);
                  next.splice(idx - 1, 0, item);
                  await getServices().adminManagement.reorderHomepageModules(next);
                  await load();
                }}
              >
                Move up
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
