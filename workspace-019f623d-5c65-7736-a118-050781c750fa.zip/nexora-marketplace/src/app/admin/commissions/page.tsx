"use client";
import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { CommissionRecord } from "@/repositories/management";
import { formatMoney } from "@/lib/money";
export default function AdminCommissionsPage() {
  const [rows, setRows] = useState<CommissionRecord[]>([]);
  useEffect(() => { void getServices().adminManagement.listCommissions().then(setRows); }, []);
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Commissions</h1>
      <div className="mt-6 space-y-2">
        {rows.map((r) => (
          <div key={r.id} className="flex items-center justify-between rounded-xl border border-[var(--border)] p-4">
            <div>
              <p className="font-semibold">Order {r.orderId}</p>
              <p className="text-sm text-[var(--muted-foreground)]">{r.ratePercent}% · store {r.storeId}</p>
            </div>
            <p className="font-semibold">{formatMoney(r.amount)}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
