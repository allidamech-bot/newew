"use client";

import { useEffect, useState } from "react";
import { mockDb } from "@/mocks/db";
import type { Review } from "@/types";
import { RatingDisplay } from "@/components/commerce/rating-display";
import { Badge } from "@/components/ui/badge";

export default function AdminReviewsPage() {
  const [items, setItems] = useState<Review[]>([]);
  useEffect(() => { setItems([...mockDb.reviews]); }, []);
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Reviews moderation</h1>
      <div className="mt-6 space-y-3">
        {items.map((r) => (
          <article key={r.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <div className="flex items-center justify-between gap-3">
              <p className="font-semibold">{r.title.en}</p>
              <div className="flex items-center gap-2">
                <RatingDisplay rating={r.productRating} />
                <Badge variant="outline" className="capitalize">{r.moderationStatus}</Badge>
              </div>
            </div>
            <p className="mt-2 text-sm text-[var(--muted-foreground)]">{r.body.en}</p>
          </article>
        ))}
      </div>
    </div>
  );
}
