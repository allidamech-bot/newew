"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { SellerApplication } from "@/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/feedback/empty-state";
import { toast } from "sonner";

export default function AdminApplicationsPage() {
  const [items, setItems] = useState<SellerApplication[]>([]);

  async function load() {
    setItems(await getServices().moderation.listSellerApplications());
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Seller applications</h1>
      <div className="mt-6 space-y-3">
        {items.map((app) => (
          <div key={app.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-semibold">{app.storeName || "(draft store)"}</p>
                <p className="text-sm text-[var(--muted-foreground)]">
                  {app.sellerType} · {app.contactEmail}
                </p>
              </div>
              <Badge className="capitalize">{app.status.replaceAll("_", " ")}</Badge>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <Button size="sm" onClick={async () => {
                await getServices().moderation.reviewApplication(app.id, "approved", "Approved");
                toast.success("Approved");
                await load();
              }}>Approve</Button>
              <Button size="sm" variant="outline" onClick={async () => {
                await getServices().moderation.reviewApplication(app.id, "more_info_required", "Need docs");
                toast.message("More info requested");
                await load();
              }}>Request info</Button>
              <Button size="sm" variant="destructive" onClick={async () => {
                await getServices().moderation.reviewApplication(app.id, "rejected", "Rejected");
                toast.message("Rejected");
                await load();
              }}>Reject</Button>
            </div>
          </div>
        ))}
        {!items.length ? <EmptyState title="No applications" description="Seller applications will appear here for review." /> : null}
      </div>
    </div>
  );
}
