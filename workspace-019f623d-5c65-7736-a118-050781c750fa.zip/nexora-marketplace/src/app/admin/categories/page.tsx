"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { AttributeDefinition, Category } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { slugify } from "@/lib/utils";

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [attributes, setAttributes] = useState<AttributeDefinition[]>([]);
  const [name, setName] = useState("");

  async function load() {
    setCategories(await getServices().categories.list());
    setAttributes(await getServices().categories.listAllAttributes());
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <div className="grid gap-8 lg:grid-cols-2">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Categories</h1>
        <form
          className="mt-4 flex gap-2"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!name.trim()) return;
            await getServices().categories.createCategory({
              name: { en: name, ar: name },
              slug: slugify(name),
              description: { en: `${name} category`, ar: name },
              visible: true,
              featured: false,
              parentId: null,
              sortOrder: 99,
              productTypes: ["physical"],
              attributeIds: [],
            });
            setName("");
            toast.success("Category created");
            await load();
          }}
        >
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="New category name" />
          <Button type="submit">Add</Button>
        </form>
        <div className="mt-4 space-y-2">
          {categories.map((c) => (
            <div key={c.id} className="rounded-lg border border-[var(--border)] p-3 text-sm">
              <p className="font-medium">
                {c.name.en} <span className="text-[var(--muted-foreground)]">/{c.slug}</span>
              </p>
              <p className="text-[var(--muted-foreground)]">
                attrs: {c.attributeIds.length} · {c.visible ? "visible" : "hidden"}
              </p>
            </div>
          ))}
        </div>
      </div>
      <div>
        <h2 className="text-xl font-semibold tracking-tight">Attributes</h2>
        <div className="mt-4 space-y-2">
          {attributes.map((a) => (
            <div key={a.id} className="rounded-lg border border-[var(--border)] p-3 text-sm">
              <p className="font-medium">
                {a.name.en} <span className="text-[var(--muted-foreground)]">({a.type})</span>
              </p>
              <p className="text-[var(--muted-foreground)]">
                filterable: {String(a.filterable)} · variant: {String(a.variantAxis)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
