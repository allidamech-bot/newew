"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { Store } from "@/types";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

export default function AdminSellersPage() {
  const [stores, setStores] = useState<Store[]>([]);
  useEffect(() => {
    void getServices().stores.list({ pageSize: 100 }).then((r) => setStores(r.items));
  }, []);
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Sellers & stores</h1>
      <div className="mt-6 space-y-3">
        {stores.map((store) => (
          <div key={store.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <div>
              <Link href={`/stores/${store.slug}`} className="font-semibold hover:underline">{store.name}</Link>
              <p className="text-sm text-[var(--muted-foreground)]">{store.location || "—"} · owner {store.ownerId}</p>
            </div>
            <div className="flex gap-2">
              <Badge variant="secondary" className="capitalize">{store.status}</Badge>
              <Badge variant="outline" className="capitalize">{store.verificationStatus}</Badge>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
