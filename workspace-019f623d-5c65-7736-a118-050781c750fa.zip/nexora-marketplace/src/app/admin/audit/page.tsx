"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";

export default function AdminAuditPage() {
  const [logs, setLogs] = useState<Array<{
    id: string;
    actorId: string;
    action: string;
    entityType: string;
    entityId: string;
    createdAt: string;
  }>>([]);
  useEffect(() => {
    void getServices().audit.list(50).then(setLogs);
  }, []);
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Audit logs</h1>
      <div className="mt-6 space-y-2">
        {logs.map((log) => (
          <div key={log.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 text-sm">
            <p className="font-semibold">{log.action}</p>
            <p className="text-[var(--muted-foreground)]">
              {log.entityType}:{log.entityId} · actor {log.actorId}
            </p>
            <p className="mt-1 text-xs text-[var(--muted-foreground)]">{new Date(log.createdAt).toLocaleString()}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
