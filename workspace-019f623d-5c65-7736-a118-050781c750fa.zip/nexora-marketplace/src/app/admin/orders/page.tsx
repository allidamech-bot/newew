"use client";

import { useEffect, useState } from "react";
import { mockDb } from "@/mocks/db";
import type { Order } from "@/types";
import { formatMoney } from "@/lib/money";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  useEffect(() => {
    setOrders([...mockDb.orders]);
  }, []);
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Orders</h1>
      <div className="mt-6 space-y-3">
        {orders.map((order) => (
          <div key={order.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <div>
              <p className="font-semibold">{order.orderNumber}</p>
              <p className="text-sm text-[var(--muted-foreground)]">
                buyer {order.buyerId} · store {order.storeId}
              </p>
            </div>
            <div className="text-end">
              <Badge className="capitalize">{order.status.replaceAll("_", " ")}</Badge>
              <p className="mt-2 font-semibold">{formatMoney(order.total)}</p>
              <Link href={`/account/orders/${order.id}`} className="text-xs text-[var(--primary)] hover:underline">View</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
