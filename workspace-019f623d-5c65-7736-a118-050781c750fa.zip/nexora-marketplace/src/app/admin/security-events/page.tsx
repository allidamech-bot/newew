"use client";
import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { SecurityEvent } from "@/repositories/management";
export default function AdminSecurityEventsPage() {
  const [rows, setRows] = useState<SecurityEvent[]>([]);
  useEffect(()=>{ void getServices().adminManagement.listSecurityEvents().then(setRows); }, []);
  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Security events</h1>
      <div className="mt-6 space-y-2">
        {rows.map((e)=>(
          <div key={e.id} className="rounded-xl border border-[var(--border)] p-4 text-sm">
            <p className="font-semibold">{e.eventType}</p>
            <p className="text-[var(--muted-foreground)]">user {e.userId || "—"} · {e.ip || "n/a"}</p>
            <p className="text-xs text-[var(--muted-foreground)]">{new Date(e.createdAt).toLocaleString()}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
