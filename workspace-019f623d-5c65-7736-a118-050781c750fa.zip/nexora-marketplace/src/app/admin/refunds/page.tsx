"use client";
import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { RefundRecord } from "@/repositories/management";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { fromMajor, formatMoney } from "@/lib/money";
import { toast } from "sonner";
export default function AdminRefundsPage() {
  const [rows, setRows] = useState<RefundRecord[]>([]);
  const [orderId, setOrderId] = useState("");
  const [amount, setAmount] = useState("10");
  const [reason, setReason] = useState("Customer request");
  async function load(){ setRows(await getServices().adminManagement.listRefunds()); }
  useEffect(() => { void load(); }, []);
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold tracking-tight">Refunds</h1>
      <form className="flex flex-wrap gap-2" onSubmit={async (e) => {
        e.preventDefault();
        await getServices().adminManagement.createRefund({ orderId, amount: fromMajor(Number(amount)||0), reason });
        toast.success("Refund recorded");
        setOrderId("");
        await load();
      }}>
        <Input placeholder="Order ID" value={orderId} onChange={(e)=>setOrderId(e.target.value)} required />
        <Input placeholder="Amount" value={amount} onChange={(e)=>setAmount(e.target.value)} />
        <Input placeholder="Reason" value={reason} onChange={(e)=>setReason(e.target.value)} />
        <Button type="submit">Create refund</Button>
      </form>
      <div className="space-y-2">
        {rows.map((r)=>(
          <div key={r.id} className="rounded-xl border border-[var(--border)] p-4">
            <p className="font-semibold">{formatMoney(r.amount)} · {r.status}</p>
            <p className="text-sm text-[var(--muted-foreground)]">Order {r.orderId} · {r.reason}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
