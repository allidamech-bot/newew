"use client";

import { useEffect, useState } from "react";
import { getServices } from "@/services";
import type { Report } from "@/types";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

export default function AdminReportsPage() {
  const [reports, setReports] = useState<Report[]>([]);

  async function load() {
    setReports(await getServices().moderation.listReports());
  }

  useEffect(() => {
    void load();
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-semibold tracking-tight">Reports</h1>
      <div className="mt-6 space-y-3">
        {reports.map((report) => (
          <div
            key={report.id}
            className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4"
          >
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <p className="font-semibold">
                  {report.targetType} · {report.reason}
                </p>
                <p className="mt-1 text-sm text-[var(--muted-foreground)]">
                  Target {report.targetId}
                  {report.details ? ` · ${report.details}` : ""}
                </p>
              </div>
              <Badge className="capitalize">{report.status}</Badge>
            </div>
            <div className="mt-3 flex gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={async () => {
                  await getServices().moderation.updateReport(report.id, "reviewing");
                  toast.message("Marked reviewing");
                  await load();
                }}
              >
                Review
              </Button>
              <Button
                size="sm"
                onClick={async () => {
                  await getServices().moderation.updateReport(report.id, "resolved");
                  toast.success("Resolved");
                  await load();
                }}
              >
                Resolve
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={async () => {
                  await getServices().moderation.updateReport(report.id, "dismissed");
                  toast.message("Dismissed");
                  await load();
                }}
              >
                Dismiss
              </Button>
            </div>
          </div>
        ))}
        {!reports.length ? (
          <p className="text-sm text-[var(--muted-foreground)]">No open reports.</p>
        ) : null}
      </div>
    </div>
  );
}
