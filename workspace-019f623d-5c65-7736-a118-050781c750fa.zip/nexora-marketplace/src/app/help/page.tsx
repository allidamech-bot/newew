import Link from "next/link";
import { getServices } from "@/services";

export const metadata = { title: "Help Center" };

export default async function HelpPage() {
  const services = getServices();
  const [categories, articles] = await Promise.all([
    services.cms.helpCategories(),
    services.cms.helpArticles(),
  ]);
  return (
    <div className="container-sol py-10">
      <h1 className="text-3xl font-semibold tracking-tight">Help Center</h1>
      <p className="mt-2 text-[var(--muted-foreground)]">Guides for buyers and sellers on NEXORA.</p>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((c) => (
          <div key={c.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-5">
            <h2 className="font-semibold">{c.name.en}</h2>
            <ul className="mt-3 space-y-2 text-sm">
              {articles
                .filter((a) => a.categoryId === c.id)
                .map((a) => (
                  <li key={a.id}>
                    <Link href={`/help/${a.slug}`} className="text-[var(--primary)] hover:underline">
                      {a.title.en}
                    </Link>
                  </li>
                ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
