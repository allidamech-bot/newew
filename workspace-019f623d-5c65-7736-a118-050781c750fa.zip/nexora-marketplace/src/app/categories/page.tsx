import Link from "next/link";
import Image from "next/image";
import { getServices } from "@/services";

export const metadata = { title: "Categories" };

export default async function CategoriesPage() {
  const tree = await getServices().categories.getTree();
  return (
    <div className="container-sol py-8">
      <h1 className="text-3xl font-semibold tracking-tight">Categories</h1>
      <p className="mt-2 text-[var(--muted-foreground)]">
        Explore SOL by category universe — not a flat list of icons.
      </p>
      <div className="mt-8 space-y-10">
        {tree.map((cat) => (
          <section key={cat.id}>
            <div className="mb-4 flex items-end justify-between gap-3">
              <div>
                <h2 className="text-xl font-semibold">
                  <Link href={`/categories/${cat.slug}`} className="hover:underline">
                    {cat.name.en}
                  </Link>
                </h2>
                <p className="text-sm text-[var(--muted-foreground)]">{cat.description.en}</p>
              </div>
              <Link href={`/categories/${cat.slug}`} className="text-sm text-[var(--primary)] hover:underline">
                View all
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <Link
                href={`/categories/${cat.slug}`}
                className="relative aspect-[4/3] overflow-hidden rounded-xl border border-[var(--border)]"
              >
                <Image src={cat.imageUrl || "/images/cat-home.svg"} alt="" fill className="object-cover" unoptimized />
                <div className="absolute inset-0 bg-gradient-to-t from-black/55 to-transparent" />
                <span className="absolute bottom-3 start-3 font-medium text-white">{cat.name.en}</span>
              </Link>
              {cat.children.map((child) => (
                <Link
                  key={child.id}
                  href={`/categories/${child.slug}`}
                  className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 hover:border-[var(--primary)]"
                >
                  <p className="font-medium">{child.name.en}</p>
                  <p className="mt-1 line-clamp-2 text-xs text-[var(--muted-foreground)]">
                    {child.description.en}
                  </p>
                </Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
