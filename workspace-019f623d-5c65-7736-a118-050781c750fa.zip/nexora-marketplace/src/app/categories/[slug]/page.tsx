import { notFound } from "next/navigation";
import { getServices } from "@/services";
import { ProductCard } from "@/components/commerce/product-card";
import Link from "next/link";

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const services = getServices();
  const category = await services.categories.getBySlug(slug);
  if (!category) notFound();
  const all = await services.categories.list();
  const childIds = all.filter((c) => c.parentId === category.id).map((c) => c.id);
  const products = await services.catalog.listProducts({
    pageSize: 48,
    filters: { categoryId: category.id },
  });
  // also include children via second pass if parent
  let items = products.items;
  if (!category.parentId && childIds.length) {
    const more = await services.catalog.listProducts({ pageSize: 48 });
    items = more.items.filter(
      (p) => p.categoryId === category.id || childIds.includes(p.categoryId)
    );
  }
  const stores = await services.stores.list({ pageSize: 100 });
  const storeMap = new Map(stores.items.map((s) => [s.id, s]));
  const children = all.filter((c) => c.parentId === category.id);

  return (
    <div className="container-sol py-8">
      <nav className="text-sm text-[var(--muted-foreground)]">
        <Link href="/categories" className="hover:underline">
          Categories
        </Link>
        <span className="mx-2">/</span>
        <span>{category.name.en}</span>
      </nav>
      <h1 className="mt-3 text-3xl font-semibold tracking-tight">{category.name.en}</h1>
      <p className="mt-2 max-w-2xl text-[var(--muted-foreground)]">{category.description.en}</p>
      {children.length ? (
        <div className="mt-5 flex flex-wrap gap-2">
          {children.map((c) => (
            <Link
              key={c.id}
              href={`/categories/${c.slug}`}
              className="rounded-full border border-[var(--border)] px-3 py-1.5 text-sm hover:border-[var(--primary)]"
            >
              {c.name.en}
            </Link>
          ))}
        </div>
      ) : null}
      <p className="mt-6 text-sm text-[var(--muted-foreground)]">{items.length} results</p>
      <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
        {items.map((p) => (
          <ProductCard key={p.id} product={p} store={storeMap.get(p.storeId)} />
        ))}
      </div>
    </div>
  );
}
