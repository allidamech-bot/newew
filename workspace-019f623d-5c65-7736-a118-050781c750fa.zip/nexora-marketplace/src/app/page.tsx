import { getServices } from "@/services";
import { brand } from "@/config/brand";
import { HomeClient } from "@/features/catalog/home-client";

export default async function HomePage() {
  const services = getServices();
  // Request only what homepage modules need — avoid full catalog serialization.
  const [modules, trending, deals, recommended, stores, categories, collections] =
    await Promise.all([
      services.cms.homepageModules(),
      services.catalog.listProducts({ sort: "best_selling", pageSize: 8 }),
      services.catalog.listProducts({ filters: { onSale: true }, pageSize: 8 }),
      services.catalog.listProducts({ sort: "rating", pageSize: 8 }),
      services.stores.list({ pageSize: 6 }),
      services.categories.getTree(),
      services.cms.collections(),
    ]);

  const [digital, servicesProducts, fast] = await Promise.all([
    services.catalog.listProducts({ filters: { productTypes: ["digital"] }, pageSize: 6 }),
    services.catalog.listProducts({ filters: { productTypes: ["service"] }, pageSize: 6 }),
    services.catalog.listProducts({
      filters: { verifiedSellersOnly: true, inStockOnly: true },
      sort: "newest",
      pageSize: 6,
    }),
  ]);

  return (
    <HomeClient
      brandName={brand.name}
      modules={modules}
      trending={trending.items}
      deals={deals.items}
      recommended={recommended.items}
      digital={digital.items}
      servicesProducts={servicesProducts.items}
      fast={fast.items}
      stores={stores.items}
      categories={categories}
      collections={collections}
    />
  );
}
