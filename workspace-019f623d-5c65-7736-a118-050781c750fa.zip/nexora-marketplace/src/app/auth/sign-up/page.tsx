"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuthStore } from "@/features/auth/store";
import { useLocaleStore } from "@/i18n";
import { toast } from "sonner";

export default function SignUpPage() {
  const t = useLocaleStore((s) => s.t);
  const signUp = useAuthStore((s) => s.signUp);
  const router = useRouter();
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirm: "",
  });
  const [loading, setLoading] = useState(false);

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-4 py-10">
      <Logo />
      <h1 className="mt-8 text-2xl font-semibold tracking-tight">{t("auth.signUpTitle")}</h1>
      <form
        className="mt-6 space-y-4"
        onSubmit={async (e) => {
          e.preventDefault();
          if (form.password !== form.confirm) {
            toast.error("Passwords do not match");
            return;
          }
          setLoading(true);
          try {
            await signUp({
              email: form.email,
              password: form.password,
              firstName: form.firstName,
              lastName: form.lastName,
            });
            toast.success("Account created");
            router.push("/account");
          } catch (err) {
            toast.error(err instanceof Error ? err.message : "Sign up failed");
          } finally {
            setLoading(false);
          }
        }}
      >
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label htmlFor="firstName">{t("auth.firstName")}</Label>
            <Input
              id="firstName"
              value={form.firstName}
              onChange={(e) => setForm((f) => ({ ...f, firstName: e.target.value }))}
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="lastName">{t("auth.lastName")}</Label>
            <Input
              id="lastName"
              value={form.lastName}
              onChange={(e) => setForm((f) => ({ ...f, lastName: e.target.value }))}
              required
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">{t("auth.email")}</Label>
          <Input
            id="email"
            type="email"
            value={form.email}
            onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="password">{t("auth.password")}</Label>
          <Input
            id="password"
            type="password"
            value={form.password}
            onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))}
            required
            minLength={8}
          />
          <p className="text-xs text-[var(--muted-foreground)]">{t("auth.passwordRequirements")}</p>
        </div>
        <div className="space-y-2">
          <Label htmlFor="confirm">{t("auth.confirmPassword")}</Label>
          <Input
            id="confirm"
            type="password"
            value={form.confirm}
            onChange={(e) => setForm((f) => ({ ...f, confirm: e.target.value }))}
            required
          />
        </div>
        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? t("common.loading") : t("nav.signUp")}
        </Button>
      </form>
      <p className="mt-6 text-center text-sm text-[var(--muted-foreground)]">
        {t("auth.hasAccount")}{" "}
        <Link href="/auth/sign-in" className="font-medium text-[var(--primary)] hover:underline">
          {t("nav.signIn")}
        </Link>
      </p>
    </div>
  );
}
