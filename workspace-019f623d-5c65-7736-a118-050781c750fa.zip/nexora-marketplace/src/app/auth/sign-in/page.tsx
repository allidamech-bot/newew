"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuthStore } from "@/features/auth/store";
import { useLocaleStore } from "@/i18n";
import { toast } from "sonner";
import { Eye, EyeOff } from "lucide-react";

const demos = [
  { email: "buyer@sol.demo", role: "Buyer" },
  { email: "seller@sol.demo", role: "Seller" },
  { email: "admin@sol.demo", role: "Admin" },
  { email: "moderator@sol.demo", role: "Moderator" },
];

export default function SignInPage() {
  const t = useLocaleStore((s) => s.t);
  const signIn = useAuthStore((s) => s.signIn);
  const router = useRouter();
  const [email, setEmail] = useState("buyer@sol.demo");
  const [password, setPassword] = useState("demo1234");
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-4 py-10">
      <Logo />
      <h1 className="mt-8 text-2xl font-semibold tracking-tight">{t("auth.signInTitle")}</h1>
      <p className="mt-2 text-sm text-[var(--muted-foreground)]">{t("auth.demoNote")}</p>
      <form
        className="mt-6 space-y-4"
        onSubmit={async (e) => {
          e.preventDefault();
          setLoading(true);
          try {
            await signIn(email, password);
            toast.success("Signed in");
            router.push("/account");
          } catch (err) {
            toast.error(err instanceof Error ? err.message : "Sign in failed");
          } finally {
            setLoading(false);
          }
        }}
      >
        <div className="space-y-2">
          <Label htmlFor="email">{t("auth.email")}</Label>
          <Input
            id="email"
            type="email"
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="password">{t("auth.password")}</Label>
            <Link href="/auth/forgot-password" className="text-xs text-[var(--primary)] hover:underline">
              {t("auth.forgotPassword")}
            </Link>
          </div>
          <div className="relative">
            <Input
              id="password"
              type={show ? "text" : "password"}
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button
              type="button"
              className="absolute end-3 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]"
              onClick={() => setShow((v) => !v)}
              aria-label="Toggle password visibility"
            >
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <Button type="submit" className="w-full" disabled={loading}>
          {loading ? t("common.loading") : t("nav.signIn")}
        </Button>
      </form>
      <div className="mt-6 grid grid-cols-2 gap-2">
        {demos.map((d) => (
          <Button
            key={d.email}
            type="button"
            variant="outline"
            size="sm"
            onClick={() => {
              setEmail(d.email);
              setPassword("demo1234");
            }}
          >
            {d.role}
          </Button>
        ))}
      </div>
      <p className="mt-6 text-center text-sm text-[var(--muted-foreground)]">
        {t("auth.noAccount")}{" "}
        <Link href="/auth/sign-up" className="font-medium text-[var(--primary)] hover:underline">
          {t("nav.signUp")}
        </Link>
      </p>
      <div className="mt-6 space-y-2">
        <Button variant="outline" className="w-full" disabled>
          {t("auth.continueWithGoogle")}
        </Button>
        <Button variant="outline" className="w-full" disabled>
          {t("auth.continueWithApple")}
        </Button>
      </div>
    </div>
  );
}
