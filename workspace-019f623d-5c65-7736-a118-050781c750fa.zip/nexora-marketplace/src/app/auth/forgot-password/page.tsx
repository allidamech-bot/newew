"use client";

import Link from "next/link";
import { useState } from "react";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getServices } from "@/services";
import { toast } from "sonner";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);

  return (
    <div className="mx-auto flex min-h-dvh max-w-md flex-col justify-center px-4 py-10">
      <Logo />
      <h1 className="mt-8 text-2xl font-semibold tracking-tight">Reset password</h1>
      {sent ? (
        <p className="mt-4 text-sm text-[var(--muted-foreground)]">
          If an account exists for {email}, a reset link has been prepared (mock mode — check demo docs).
        </p>
      ) : (
        <form
          className="mt-6 space-y-4"
          onSubmit={async (e) => {
            e.preventDefault();
            await getServices().auth.requestPasswordReset(email);
            setSent(true);
            toast.success("Reset link sent (mock)");
          }}
        >
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <Button type="submit" className="w-full">
            Send reset link
          </Button>
        </form>
      )}
      <Link href="/auth/sign-in" className="mt-6 text-sm text-[var(--primary)] hover:underline">
        Back to sign in
      </Link>
    </div>
  );
}
