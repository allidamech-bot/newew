"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuthStore } from "@/features/auth/store";
import { useCartStore, cartTotals } from "@/features/cart/store";
import { getServices } from "@/services";
import type { Address, Order } from "@/types";
import { formatMoney, money, percentOf } from "@/lib/money";
import { useLocaleStore } from "@/i18n";
import { toast } from "sonner";

const steps = ["contact", "address", "delivery", "payment", "review"] as const;

export default function CheckoutPage() {
  const t = useLocaleStore((s) => s.t);
  const locale = useLocaleStore((s) => s.locale);
  const user = useAuthStore((s) => s.session?.user);
  const cart = useCartStore((s) => s.cart);
  const cartKey = useCartStore((s) => s.cartKey);
  const refresh = useCartStore((s) => s.refresh);
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [addressId, setAddressId] = useState("");
  const [shippingMethodId, setShippingMethodId] = useState("ship-standard");
  const [paymentMethod, setPaymentMethod] = useState("card");
  const [agree, setAgree] = useState(false);
  const [loading, setLoading] = useState(false);
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [email, setEmail] = useState(user?.email || "");
  const [phone, setPhone] = useState("");

  useEffect(() => {
    if (!user) {
      router.replace("/auth/sign-in");
      return;
    }
    void refresh();
    getServices()
      .profile.listAddresses(user.id)
      .then((list) => {
        setAddresses(list);
        setAddressId(list.find((a) => a.isDefault)?.id || list[0]?.id || "");
      });
    setEmail(user.email);
  }, [user, router, refresh]);

  const items = cart?.items.filter((i) => !i.savedForLater) || [];
  const { subtotal } = cartTotals(cart);
  const shipping = shippingMethodId === "ship-express" ? money(1800) : subtotal.amount >= 7500 ? money(0) : money(800);
  const tax = percentOf(money(subtotal.amount + shipping.amount), 8);
  const total = money(subtotal.amount + shipping.amount + tax.amount);

  if (orders) {
    return (
      <div className="mx-auto max-w-lg px-4 py-12">
        <Logo />
        <h1 className="mt-8 text-3xl font-semibold tracking-tight">{t("checkout.thankYou")}</h1>
        <p className="mt-2 text-[var(--muted-foreground)]">{t("checkout.orderPlaced")}</p>
        <ul className="mt-6 space-y-2">
          {orders.map((o) => (
            <li key={o.id} className="rounded-xl border border-[var(--border)] p-4">
              <p className="font-semibold">{o.orderNumber}</p>
              <p className="text-sm text-[var(--muted-foreground)]">{formatMoney(o.total, locale)}</p>
            </li>
          ))}
        </ul>
        <Button className="mt-6 w-full" onClick={() => router.push("/account/orders")}>
          View orders
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <Logo />
      <h1 className="mt-6 text-2xl font-semibold tracking-tight">{t("checkout.title")}</h1>
      <ol className="mt-4 flex flex-wrap gap-2 text-xs">
        {steps.map((s, i) => (
          <li
            key={s}
            className={`rounded-full px-3 py-1 ${
              i === step
                ? "bg-[var(--primary)] text-[var(--primary-foreground)]"
                : i < step
                  ? "bg-[var(--muted)]"
                  : "border border-[var(--border)] text-[var(--muted-foreground)]"
            }`}
          >
            {t(`checkout.${s}` as never)}
          </li>
        ))}
      </ol>

      <div className="mt-8 grid gap-8 md:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--card)] p-5">
          {step === 0 && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>{t("checkout.email")}</Label>
                <Input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />
              </div>
              <div className="space-y-2">
                <Label>{t("checkout.phone")}</Label>
                <Input value={phone} onChange={(e) => setPhone(e.target.value)} type="tel" />
              </div>
            </div>
          )}
          {step === 1 && (
            <div className="space-y-3">
              <p className="font-medium">{t("checkout.selectAddress")}</p>
              {addresses.map((a) => (
                <label
                  key={a.id}
                  className={`block cursor-pointer rounded-xl border p-4 ${
                    addressId === a.id ? "border-[var(--primary)]" : "border-[var(--border)]"
                  }`}
                >
                  <input
                    type="radio"
                    className="me-2"
                    checked={addressId === a.id}
                    onChange={() => setAddressId(a.id)}
                  />
                  <span className="font-medium">{a.label}</span>
                  <p className="mt-1 text-sm text-[var(--muted-foreground)]">
                    {a.fullName} · {a.line1}, {a.city}, {a.country}
                  </p>
                </label>
              ))}
              {!addresses.length ? (
                <p className="text-sm text-[var(--muted-foreground)]">
                  No addresses yet. Add one in account settings, or use demo buyer account.
                </p>
              ) : null}
            </div>
          )}
          {step === 2 && (
            <div className="space-y-3">
              {[
                { id: "ship-standard", name: "Standard 4–7 days", price: subtotal.amount >= 7500 ? "Free" : "$8.00" },
                { id: "ship-express", name: "Express 1–3 days", price: "$18.00" },
              ].map((m) => (
                <label
                  key={m.id}
                  className={`flex cursor-pointer items-center justify-between rounded-xl border p-4 ${
                    shippingMethodId === m.id ? "border-[var(--primary)]" : "border-[var(--border)]"
                  }`}
                >
                  <span>
                    <input
                      type="radio"
                      className="me-2"
                      checked={shippingMethodId === m.id}
                      onChange={() => setShippingMethodId(m.id)}
                    />
                    {m.name}
                  </span>
                  <span className="text-sm font-medium">{m.price}</span>
                </label>
              ))}
            </div>
          )}
          {step === 3 && (
            <div className="space-y-3">
              {[
                { id: "card", label: t("checkout.card") },
                { id: "cod", label: t("checkout.cod") },
                { id: "bank", label: t("checkout.bank") },
              ].map((m) => (
                <label
                  key={m.id}
                  className={`block cursor-pointer rounded-xl border p-4 ${
                    paymentMethod === m.id ? "border-[var(--primary)]" : "border-[var(--border)]"
                  }`}
                >
                  <input
                    type="radio"
                    className="me-2"
                    checked={paymentMethod === m.id}
                    onChange={() => setPaymentMethod(m.id)}
                  />
                  {m.label}
                </label>
              ))}
              <p className="text-xs text-[var(--muted-foreground)]">{t("checkout.secureNote")}</p>
            </div>
          )}
          {step === 4 && (
            <div className="space-y-4 text-sm">
              <p>
                <span className="text-[var(--muted-foreground)]">Contact:</span> {email}
              </p>
              <p>
                <span className="text-[var(--muted-foreground)]">Items:</span> {items.length}
              </p>
              <p>
                <span className="text-[var(--muted-foreground)]">Payment:</span> {paymentMethod}
              </p>
              <label className="flex items-start gap-2">
                <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} className="mt-1" />
                <span>{t("checkout.agreeTerms")}</span>
              </label>
            </div>
          )}

          <div className="mt-6 flex justify-between gap-3">
            <Button variant="outline" disabled={step === 0} onClick={() => setStep((s) => s - 1)}>
              {t("common.back")}
            </Button>
            {step < steps.length - 1 ? (
              <Button
                onClick={() => {
                  if (step === 1 && !addressId) {
                    toast.error("Select an address");
                    return;
                  }
                  setStep((s) => s + 1);
                }}
              >
                {t("common.continue")}
              </Button>
            ) : (
              <Button
                disabled={!agree || loading || !items.length}
                onClick={async () => {
                  if (!user) return;
                  setLoading(true);
                  try {
                    const intent = await getServices().payments.createIntent({
                      amountMinor: total.amount,
                      currency: "USD",
                      method: paymentMethod,
                      idempotencyKey: `checkout-${user.id}-${Date.now()}`,
                    });
                    await getServices().payments.confirm(intent.id);
                    const created = await getServices().orders.createFromCart({
                      cartKey: cartKey(),
                      buyerId: user.id,
                      addressId,
                      shippingMethodId,
                      paymentMethod,
                      idempotencyKey: `order-${user.id}-${Date.now()}`,
                    });
                    await refresh();
                    setOrders(created);
                    toast.success("Order placed");
                  } catch (e) {
                    toast.error(e instanceof Error ? e.message : "Checkout failed");
                  } finally {
                    setLoading(false);
                  }
                }}
              >
                {loading ? t("common.loading") : t("checkout.placeOrder")}
              </Button>
            )}
          </div>
        </div>

        <aside className="h-fit rounded-2xl border border-[var(--border)] bg-[var(--card)] p-5">
          <h2 className="font-semibold">{t("cart.summary")}</h2>
          <dl className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <dt>{t("common.subtotal")}</dt>
              <dd>{formatMoney(subtotal, locale)}</dd>
            </div>
            <div className="flex justify-between">
              <dt>{t("common.shipping")}</dt>
              <dd>{shipping.amount === 0 ? t("common.free") : formatMoney(shipping, locale)}</dd>
            </div>
            <div className="flex justify-between">
              <dt>{t("common.tax")}</dt>
              <dd>{formatMoney(tax, locale)}</dd>
            </div>
            <div className="flex justify-between border-t border-[var(--border)] pt-3 text-base font-semibold">
              <dt>{t("common.total")}</dt>
              <dd>{formatMoney(total, locale)}</dd>
            </div>
          </dl>
        </aside>
      </div>
    </div>
  );
}
