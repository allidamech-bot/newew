import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
  const paths = [
    "",
    "/discover",
    "/categories",
    "/stores",
    "/deals",
    "/sell",
    "/help",
    "/about",
    "/contact",
    "/trust-and-safety",
    "/accessibility",
    "/policies/terms",
    "/policies/privacy",
    "/policies/returns",
  ];
  return paths.map((path) => ({
    url: `${base}${path || "/"}`,
    lastModified: new Date(),
    changeFrequency: "daily" as const,
    priority: path === "" ? 1 : 0.6,
  }));
}
