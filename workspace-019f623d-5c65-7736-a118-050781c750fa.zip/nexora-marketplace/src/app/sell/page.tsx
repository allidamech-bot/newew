import Link from "next/link";
import { brand } from "@/config/brand";
import { Button } from "@/components/ui/button";

export const metadata = { title: "Sell on NEXORA" };

export default function SellPage() {
  return (
    <div className="container-sol py-10">
      <p className="text-xs font-semibold uppercase tracking-[0.18em] text-[var(--primary)]">
        {brand.name}
      </p>
      <h1 className="mt-3 max-w-2xl text-4xl font-semibold tracking-tight">
        Build a premium independent storefront
      </h1>
      <p className="mt-4 max-w-2xl text-lg text-[var(--muted-foreground)]">
        {brand.tagline.en} NEXORA gives sellers product tools, inventory, messaging, promotions, and
        analytics without forcing a generic template experience.
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        <Button asChild size="lg">
          <Link href="/seller/onboarding">Start seller onboarding</Link>
        </Button>
        <Button asChild size="lg" variant="outline">
          <Link href="/help">Seller help</Link>
        </Button>
      </div>
      <div className="mt-12 grid gap-4 md:grid-cols-3">
        {[
          ["Product wizard", "Variants, media, category attributes, and quality checks."],
          ["Order operations", "Multi-store fulfillment, returns, and customer messaging."],
          ["Growth tools", "Promotions, store analytics, and verified storefront identity."],
        ].map(([title, body]) => (
          <div key={title} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-5">
            <h2 className="font-semibold">{title}</h2>
            <p className="mt-2 text-sm text-[var(--muted-foreground)]">{body}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
