import { getServices } from "@/services";
import { SearchClient } from "@/features/search/search-client";

export const metadata = { title: "Search" };

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q : "";
  const sort = typeof sp.sort === "string" ? sp.sort : "relevance";
  const services = getServices();
  const [result, trending] = await Promise.all([
    services.search.search(q, undefined, sort === "relevance" ? undefined : sort, 1, 12),
    services.search.trending(),
  ]);

  return (
    <SearchClient
      query={q}
      result={result}
      trending={trending}
      stores={result.stores}
      sort={sort}
    />
  );
}
