import { notFound } from "next/navigation";
import Image from "next/image";
import { BadgeCheck } from "lucide-react";
import { getServices } from "@/services";
import { ProductCard } from "@/components/commerce/product-card";
import { RatingDisplay } from "@/components/commerce/rating-display";
import { StoreActions } from "@/features/stores/store-actions";

export default async function StorePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const services = getServices();
  const store = await services.stores.getBySlug(slug);
  if (!store) notFound();
  const [products, reviews] = await Promise.all([
    services.catalog.listByStore(store.id, { pageSize: 48 }),
    services.reviews.listByStore(store.id),
  ]);

  return (
    <div>
      <div className="relative h-40 md:h-56">
        <Image
          src={store.coverUrl || "/images/cover-northline.svg"}
          alt=""
          fill
          className="object-cover"
          unoptimized
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
      </div>
      <div className="container-sol -mt-10 pb-10">
        <div className="rounded-2xl border border-[var(--border)] bg-[var(--card)] p-5 shadow-sm md:p-6">
          <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
            <div className="flex gap-4">
              <div className="relative h-20 w-20 overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--muted)]">
                <Image src={store.logoUrl || "/images/placeholder-product.svg"} alt="" fill unoptimized />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-semibold tracking-tight">{store.name}</h1>
                  {store.verificationStatus === "verified" ? (
                    <BadgeCheck className="h-5 w-5 text-[var(--primary)]" />
                  ) : null}
                </div>
                <p className="mt-1 max-w-2xl text-sm text-[var(--muted-foreground)]">
                  {store.description.en}
                </p>
                <div className="mt-2 flex flex-wrap items-center gap-3 text-sm">
                  <RatingDisplay rating={store.rating} count={store.reviewCount} />
                  <span className="text-[var(--muted-foreground)]">{store.salesCount} sales</span>
                  <span className="text-[var(--muted-foreground)]">{store.followersCount} followers</span>
                  <span className="text-[var(--muted-foreground)]">{store.location}</span>
                </div>
              </div>
            </div>
            <StoreActions storeId={store.id} ownerId={store.ownerId} />
          </div>
          {store.announcement ? (
            <p className="mt-4 rounded-lg bg-[var(--muted)]/60 px-3 py-2 text-sm">
              {store.announcement.en}
            </p>
          ) : null}
        </div>

        <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_280px]">
          <div>
            <h2 className="text-lg font-semibold">Products</h2>
            <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-3">
              {products.items.map((p) => (
                <ProductCard key={p.id} product={p} store={store} />
              ))}
            </div>
            <h2 className="mt-10 text-lg font-semibold">Reviews</h2>
            <div className="mt-4 space-y-3">
              {reviews.slice(0, 6).map((r) => (
                <article key={r.id} className="rounded-xl border border-[var(--border)] p-4">
                  <div className="flex items-center justify-between">
                    <p className="font-medium">{r.buyerName}</p>
                    <RatingDisplay rating={r.storeRating} />
                  </div>
                  <p className="mt-2 text-sm text-[var(--muted-foreground)]">{r.body.en}</p>
                </article>
              ))}
              {!reviews.length ? (
                <p className="text-sm text-[var(--muted-foreground)]">No store reviews yet.</p>
              ) : null}
            </div>
          </div>
          <aside className="space-y-4">
            <div className="rounded-xl border border-[var(--border)] p-4">
              <h3 className="font-semibold">Policies</h3>
              <div className="mt-3 space-y-3 text-sm text-[var(--muted-foreground)]">
                <p>
                  <span className="font-medium text-[var(--foreground)]">Returns: </span>
                  {store.policies?.returns?.en || "See product pages for return windows."}
                </p>
                <p>
                  <span className="font-medium text-[var(--foreground)]">Shipping: </span>
                  {store.policies?.shipping?.en || "Calculated at checkout."}
                </p>
                <p>
                  <span className="font-medium text-[var(--foreground)]">Warranty: </span>
                  {store.policies?.warranty?.en || "Varies by product."}
                </p>
              </div>
            </div>
            <div className="rounded-xl border border-[var(--border)] p-4 text-sm">
              <h3 className="font-semibold">About</h3>
              <p className="mt-2 text-[var(--muted-foreground)]">
                {store.story?.en || store.description.en}
              </p>
              <p className="mt-3 text-[var(--muted-foreground)]">Support: {store.supportHours || "See messages"}</p>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
