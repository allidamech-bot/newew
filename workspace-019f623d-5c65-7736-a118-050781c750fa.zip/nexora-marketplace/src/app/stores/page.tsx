import Link from "next/link";
import Image from "next/image";
import { BadgeCheck } from "lucide-react";
import { getServices } from "@/services";
import { RatingDisplay } from "@/components/commerce/rating-display";

export const metadata = { title: "Stores" };

export default async function StoresPage() {
  const stores = await getServices().stores.list({ pageSize: 50 });
  return (
    <div className="container-sol py-8">
      <h1 className="text-3xl font-semibold tracking-tight">Independent stores</h1>
      <p className="mt-2 text-[var(--muted-foreground)]">
        Verified makers, studios, and service professionals on SOL.
      </p>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {stores.items.map((store) => (
          <Link
            key={store.id}
            href={`/stores/${store.slug}`}
            className="overflow-hidden rounded-2xl border border-[var(--border)] bg-[var(--card)] transition hover:shadow-md"
          >
            <div className="relative h-28 bg-[var(--muted)]">
              <Image
                src={store.coverUrl || "/images/cover-northline.svg"}
                alt=""
                fill
                className="object-cover"
                unoptimized
              />
            </div>
            <div className="p-4">
              <div className="flex items-center gap-2">
                <div className="relative h-12 w-12 -mt-10 overflow-hidden rounded-full border-2 border-[var(--card)] bg-[var(--muted)]">
                  <Image src={store.logoUrl || "/images/placeholder-product.svg"} alt="" fill unoptimized />
                </div>
                <div className="mt-1 flex items-center gap-1">
                  <h2 className="font-semibold">{store.name}</h2>
                  {store.verificationStatus === "verified" ? (
                    <BadgeCheck className="h-4 w-4 text-[var(--primary)]" />
                  ) : null}
                </div>
              </div>
              <p className="mt-2 line-clamp-2 text-sm text-[var(--muted-foreground)]">
                {store.description.en}
              </p>
              <div className="mt-3 flex items-center justify-between text-sm">
                <RatingDisplay rating={store.rating} count={store.reviewCount} />
                <span className="text-[var(--muted-foreground)]">{store.location}</span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
