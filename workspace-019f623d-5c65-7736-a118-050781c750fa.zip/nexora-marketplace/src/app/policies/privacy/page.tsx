import { brand } from "@/config/brand";
export const metadata = { title: "Privacy" };
export default function PolicyPage() {
  return (
    <div className="container-sol prose prose-neutral py-10 dark:prose-invert">
      <h1 className="text-3xl font-semibold tracking-tight capitalize">privacy</h1>
      <p className="mt-4 max-w-3xl text-[var(--muted-foreground)]">
        Official privacy policy for {brand.name}. This content is CMS-ready and localized architecture is prepared for English and Arabic.
      </p>
      <p className="mt-4 max-w-3xl text-[var(--muted-foreground)]">
        Contact {brand.supportEmail} for policy questions.
      </p>
    </div>
  );
}
