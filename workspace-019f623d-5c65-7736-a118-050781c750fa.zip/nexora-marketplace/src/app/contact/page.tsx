"use client";

import { useState } from "react";
import { brand } from "@/config/brand";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";

export default function ContactPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");

  return (
    <div className="container-sol py-10">
      <h1 className="text-3xl font-semibold tracking-tight">Contact</h1>
      <p className="mt-2 text-[var(--muted-foreground)]">
        Reach {brand.name} support at {brand.supportEmail}
      </p>
      <form
        className="mt-8 max-w-xl space-y-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-5"
        onSubmit={async (e) => {
          e.preventDefault();
          if (user) {
            await getServices().cms.createTicket({
              userId: user.id,
              subject,
              body,
            });
            toast.success("Support ticket created");
          } else {
            toast.success("Message recorded (sign in to track tickets)");
          }
          setSubject("");
          setBody("");
        }}
      >
        <div className="space-y-1">
          <Label htmlFor="subject">Subject</Label>
          <Input id="subject" value={subject} onChange={(e) => setSubject(e.target.value)} required />
        </div>
        <div className="space-y-1">
          <Label htmlFor="body">Message</Label>
          <Textarea id="body" value={body} onChange={(e) => setBody(e.target.value)} required />
        </div>
        <Button type="submit">Send message</Button>
      </form>
    </div>
  );
}
