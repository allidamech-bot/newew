import { getServices } from "@/services";
import { ProductCard } from "@/components/commerce/product-card";

export const metadata = { title: "Deals" };

export default async function DealsPage() {
  const services = getServices();
  const [products, stores] = await Promise.all([
    services.catalog.listProducts({ filters: { onSale: true }, sort: "discount", pageSize: 48 }),
    services.stores.list({ pageSize: 100 }),
  ]);
  const storeMap = new Map(stores.items.map((s) => [s.id, s]));
  return (
    <div className="container-sol py-8">
      <h1 className="text-3xl font-semibold tracking-tight">Time-sensitive deals</h1>
      <p className="mt-2 text-[var(--muted-foreground)]">
        Price drops and campaign discounts across independent stores.
      </p>
      <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-4">
        {products.items.map((p) => (
          <ProductCard key={p.id} product={p} store={storeMap.get(p.storeId)} variant="deal" />
        ))}
      </div>
    </div>
  );
}
