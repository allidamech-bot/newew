"use client";
import { useEffect, useState } from "react";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { mockDb, persistMockDb, createId } from "@/mocks/db";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

export default function SavedSearchesPage() {
  const user = useAuthStore(s=>s.session?.user);
  const [items, setItems] = useState(mockDb.savedSearches);
  const [query, setQuery] = useState("linen lamp");
  useEffect(()=>{
    if(!user) return;
    setItems(mockDb.savedSearches.filter(s=>s.userId===user.id));
  },[user]);
  return (
    <AccountShell title="Saved searches">
      <form className="mb-4 flex gap-2" onSubmit={(e)=>{
        e.preventDefault();
        if(!user) return;
        const row = {
          id: createId("ss"),
          userId: user.id,
          name: query,
          query,
          filters: {},
          sort: "relevance",
          notify: true,
          createdAt: new Date().toISOString(),
        };
        mockDb.savedSearches.unshift(row);
        persistMockDb();
        setItems(mockDb.savedSearches.filter(s=>s.userId===user.id));
        toast.success("Search saved");
      }}>
        <Input value={query} onChange={(e)=>setQuery(e.target.value)} />
        <Button type="submit">Save search</Button>
      </form>
      <div className="space-y-2">
        {items.map(item=>(
          <div key={item.id} className="rounded-xl border border-[var(--border)] p-4">
            <p className="font-semibold">{item.name}</p>
            <p className="text-sm text-[var(--muted-foreground)]">{item.query} · notify {String(item.notify)}</p>
          </div>
        ))}
      </div>
    </AccountShell>
  );
}
