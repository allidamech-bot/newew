"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Store } from "@/types";
import { EmptyState } from "@/components/feedback/empty-state";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function FollowingPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [stores, setStores] = useState<Store[]>([]);

  async function load() {
    if (!user) return;
    setStores(await getServices().stores.listFollowed(user.id));
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  return (
    <AccountShell title="Following">
      {!stores.length ? (
        <EmptyState
          title="Not following any stores"
          description="Follow stores to get product and promotion updates."
          actionLabel="Browse stores"
          actionHref="/stores"
        />
      ) : (
        <div className="space-y-3">
          {stores.map((store) => (
            <div
              key={store.id}
              className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4"
            >
              <div>
                <Link href={`/stores/${store.slug}`} className="font-semibold hover:underline">
                  {store.name}
                </Link>
                <p className="text-sm text-[var(--muted-foreground)]">{store.description.en}</p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  if (!user) return;
                  await getServices().stores.unfollow(user.id, store.id);
                  toast.message("Unfollowed");
                  await load();
                }}
              >
                Unfollow
              </Button>
            </div>
          ))}
        </div>
      )}
    </AccountShell>
  );
}
