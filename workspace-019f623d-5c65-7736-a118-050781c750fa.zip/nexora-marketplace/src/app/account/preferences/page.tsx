"use client";

import { AccountShell } from "@/components/layout/account-shell";
import { useLocaleStore } from "@/i18n";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

export default function PreferencesPage() {
  const locale = useLocaleStore((s) => s.locale);
  const setLocale = useLocaleStore((s) => s.setLocale);
  const { theme, setTheme } = useTheme();

  return (
    <AccountShell title="Preferences">
      <div className="max-w-xl space-y-6 rounded-xl border border-[var(--border)] bg-[var(--card)] p-5">
        <div>
          <Label>Language</Label>
          <div className="mt-2 flex gap-2">
            <Button variant={locale === "en" ? "default" : "outline"} onClick={() => setLocale("en")}>
              English
            </Button>
            <Button variant={locale === "ar" ? "default" : "outline"} onClick={() => setLocale("ar")}>
              العربية
            </Button>
          </div>
        </div>
        <div>
          <Label>Theme</Label>
          <div className="mt-2 flex gap-2">
            {(["light", "dark", "system"] as const).map((value) => (
              <Button
                key={value}
                variant={theme === value ? "default" : "outline"}
                onClick={() => setTheme(value)}
                className="capitalize"
              >
                {value}
              </Button>
            ))}
          </div>
        </div>
        <div>
          <Label>Notification channels</Label>
          <div className="mt-3 space-y-2 text-sm">
            <label className="flex items-center gap-2">
              <input type="checkbox" defaultChecked /> Order updates (required)
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" defaultChecked /> Messages
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" defaultChecked /> Promotions
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" /> Price drop alerts
            </label>
          </div>
        </div>
      </div>
    </AccountShell>
  );
}
