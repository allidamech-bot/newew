"use client";

import { AccountShell } from "@/components/layout/account-shell";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useAuthStore } from "@/features/auth/store";

export default function PrivacyPage() {
  const user = useAuthStore((s) => s.session?.user);
  const signOut = useAuthStore((s) => s.signOut);

  return (
    <AccountShell title="Privacy">
      <div className="max-w-2xl space-y-4">
        <section className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-5">
          <h2 className="font-semibold">Data export</h2>
          <p className="mt-1 text-sm text-[var(--muted-foreground)]">
            Request a portable export of your profile, orders, and messages. In mock mode the request is recorded only.
          </p>
          <Button
            className="mt-4"
            variant="outline"
            onClick={() => toast.success(`Export requested for ${user?.email}`)}
          >
            Request data export
          </Button>
        </section>
        <section className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-5">
          <h2 className="font-semibold">Marketing consent</h2>
          <label className="mt-3 flex items-center gap-2 text-sm">
            <input type="checkbox" defaultChecked /> Personalized recommendations
          </label>
          <label className="mt-2 flex items-center gap-2 text-sm">
            <input type="checkbox" /> Marketing emails
          </label>
        </section>
        <section className="rounded-xl border border-red-200 bg-red-50 p-5 dark:border-red-900 dark:bg-red-950/30">
          <h2 className="font-semibold text-red-900 dark:text-red-100">Delete account</h2>
          <p className="mt-1 text-sm text-red-800/80 dark:text-red-200/80">
            Account deletion requests are queued for review. Order records may be retained for legal and financial
            requirements.
          </p>
          <Button
            className="mt-4"
            variant="destructive"
            onClick={async () => {
              toast.success("Deletion request submitted (mock)");
              await signOut();
            }}
          >
            Request account deletion
          </Button>
        </section>
      </div>
    </AccountShell>
  );
}
