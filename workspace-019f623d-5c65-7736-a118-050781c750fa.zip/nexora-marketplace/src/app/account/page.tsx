"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Notification, Order } from "@/types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatMoney } from "@/lib/money";
import { Button } from "@/components/ui/button";

export default function AccountOverviewPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [orders, setOrders] = useState<Order[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    if (!user) return;
    void getServices().orders.listByBuyer(user.id).then(setOrders);
    void getServices().notifications.list(user.id).then(setNotifications);
  }, [user]);

  return (
    <AccountShell title="Account overview">
      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Orders</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-semibold">{orders.length}</CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Unread alerts</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-semibold">
            {notifications.filter((n) => !n.read).length}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Role</CardTitle>
          </CardHeader>
          <CardContent className="text-sm font-medium capitalize">
            {user?.roles.join(", ")}
          </CardContent>
        </Card>
      </div>

      <section className="mt-8">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Recent orders</h2>
          <Button asChild variant="ghost" size="sm">
            <Link href="/account/orders">View all</Link>
          </Button>
        </div>
        <div className="space-y-3">
          {orders.slice(0, 4).map((order) => (
            <Link
              key={order.id}
              href={`/account/orders/${order.id}`}
              className="block rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 hover:border-[var(--primary)]"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-semibold">{order.orderNumber}</p>
                  <p className="text-sm text-[var(--muted-foreground)] capitalize">
                    {order.status.replaceAll("_", " ")}
                  </p>
                </div>
                <p className="font-medium">{formatMoney(order.total)}</p>
              </div>
            </Link>
          ))}
          {!orders.length ? (
            <p className="rounded-xl border border-dashed border-[var(--border)] p-8 text-center text-sm text-[var(--muted-foreground)]">
              No orders yet. Discover products and complete a mock checkout to see them here.
            </p>
          ) : null}
        </div>
      </section>
    </AccountShell>
  );
}
