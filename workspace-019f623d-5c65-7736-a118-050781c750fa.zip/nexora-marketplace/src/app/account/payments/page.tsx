"use client";
import { AccountShell } from "@/components/layout/account-shell";
export default function PaymentsPage() {
  return (
    <AccountShell title="Payment settings">
      <div className="max-w-xl space-y-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-5 text-sm">
        <p>Payment methods use provider tokens only. NEXORA never stores raw card data.</p>
        <div className="rounded-lg border border-[var(--border)] p-3">
          <p className="font-medium">Visa •••• 4242</p>
          <p className="text-[var(--muted-foreground)]">Provider ref: pm_mock_4242</p>
        </div>
        <div className="rounded-lg border border-[var(--border)] p-3">
          <p className="font-medium">Cash on delivery</p>
          <p className="text-[var(--muted-foreground)]">Enabled for eligible sellers</p>
        </div>
      </div>
    </AccountShell>
  );
}
