"use client";
import { useEffect, useState } from "react";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { SupportTicket } from "@/types";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
export default function AccountSupportPage() {
  const user = useAuthStore(s=>s.session?.user);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [active, setActive] = useState("");
  const [reply, setReply] = useState("");
  async function load(){
    if(!user) return;
    const list = await getServices().cms.listTickets(user.id);
    setTickets(list);
  }
  useEffect(()=>{ if(!user) return; void getServices().cms.listTickets(user.id).then(setTickets); },[user]);
  const ticket = tickets.find(t=>t.id===active) || tickets[0];
  return (
    <AccountShell title="Support tickets">
      <div className="grid gap-4 lg:grid-cols-[240px_1fr]">
        <div className="space-y-2">
          {tickets.map(t=>(
            <button key={t.id} type="button" className="block w-full rounded-lg border border-[var(--border)] p-3 text-start text-sm" onClick={()=>setActive(t.id)}>
              <p className="font-medium">{t.subject}</p>
              <p className="text-[var(--muted-foreground)]">{t.status}</p>
            </button>
          ))}
        </div>
        <div className="rounded-xl border border-[var(--border)] p-4">
          {ticket ? (
            <>
              <h2 className="font-semibold">{ticket.subject}</h2>
              <div className="mt-3 space-y-2">
                {ticket.messages.map(m=>(
                  <div key={m.id} className="rounded-lg bg-[var(--muted)]/40 p-2 text-sm">
                    <p>{m.body}</p>
                  </div>
                ))}
              </div>
              <form className="mt-3 space-y-2" onSubmit={async (e)=>{
                e.preventDefault();
                if(!user||!ticket) return;
                await getServices().adminManagement.replySupportTicket(ticket.id, user.id, reply);
                setReply("");
                toast.success("Message sent");
                await load();
              }}>
                <Textarea value={reply} onChange={(e)=>setReply(e.target.value)} />
                <Button type="submit">Reply</Button>
              </form>
            </>
          ) : <p className="text-sm text-[var(--muted-foreground)]">No tickets yet. Use Contact to open one.</p>}
        </div>
      </div>
    </AccountShell>
  );
}
