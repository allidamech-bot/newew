"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Conversation } from "@/types";
import { EmptyState } from "@/components/feedback/empty-state";

export default function MessagesPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [items, setItems] = useState<Conversation[]>([]);

  useEffect(() => {
    if (!user) return;
    void getServices().conversations.listForUser(user.id).then(setItems);
  }, [user]);

  return (
    <AccountShell title="Messages">
      {!items.length ? (
        <EmptyState
          title="No conversations yet"
          description="Start a conversation from a product page or order details."
          actionLabel="Discover products"
          actionHref="/discover"
        />
      ) : (
        <div className="space-y-2">
          {items.map((c) => {
            const unread = user ? c.unreadBy[user.id] || 0 : 0;
            return (
              <Link
                key={c.id}
                href={`/account/messages/${c.id}`}
                className="block rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 hover:border-[var(--primary)]"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-semibold">{c.subject}</p>
                    <p className="mt-1 line-clamp-1 text-sm text-[var(--muted-foreground)]">
                      {c.lastMessagePreview}
                    </p>
                  </div>
                  <div className="text-end text-xs text-[var(--muted-foreground)]">
                    {new Date(c.lastMessageAt).toLocaleString()}
                    {unread > 0 ? (
                      <span className="mt-1 block rounded-full bg-[var(--primary)] px-2 py-0.5 text-[10px] font-semibold text-[var(--primary-foreground)]">
                        {unread} new
                      </span>
                    ) : null}
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </AccountShell>
  );
}
