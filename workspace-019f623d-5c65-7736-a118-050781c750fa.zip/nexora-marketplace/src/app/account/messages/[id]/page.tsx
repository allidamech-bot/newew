"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Conversation, Message } from "@/types";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

export default function ConversationPage() {
  const params = useParams<{ id: string }>();
  const user = useAuthStore((s) => s.session?.user);
  const [conversation, setConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);

  async function load() {
    const services = getServices();
    const conv = await services.conversations.get(params.id);
    setConversation(conv);
    const msgs = await services.conversations.listMessages(params.id);
    setMessages(msgs);
    if (user) await services.conversations.markRead(params.id, user.id);
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [params.id, user?.id]);

  return (
    <AccountShell title={conversation?.subject || "Conversation"}>
      <div className="flex min-h-[60vh] flex-col rounded-xl border border-[var(--border)] bg-[var(--card)]">
        <div className="flex-1 space-y-3 overflow-y-auto p-4">
          {messages.map((m) => {
            const mine = m.senderId === user?.id;
            return (
              <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-[85%] rounded-2xl px-3 py-2 text-sm ${
                    mine
                      ? "bg-[var(--primary)] text-[var(--primary-foreground)]"
                      : "bg-[var(--muted)] text-[var(--foreground)]"
                  }`}
                >
                  <p>{m.body}</p>
                  <p className={`mt-1 text-[10px] ${mine ? "opacity-80" : "text-[var(--muted-foreground)]"}`}>
                    {new Date(m.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
        <form
          className="border-t border-[var(--border)] p-3"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!user || !conversation || !body.trim()) return;
            setSending(true);
            try {
              const recipientId = conversation.participantIds.find((id) => id !== user.id);
              if (!recipientId) throw new Error("No recipient");
              await getServices().conversations.sendMessage({
                conversationId: conversation.id,
                senderId: user.id,
                recipientId,
                body: body.trim(),
                storeId: conversation.storeId,
                productId: conversation.productId,
                orderId: conversation.orderId,
                type: conversation.type,
              });
              setBody("");
              await load();
            } catch (err) {
              toast.error(err instanceof Error ? err.message : "Failed to send");
            } finally {
              setSending(false);
            }
          }}
        >
          <Textarea
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder="Write a message…"
            rows={3}
          />
          <div className="mt-2 flex justify-end">
            <Button type="submit" disabled={sending || !body.trim()}>
              {sending ? "Sending…" : "Send"}
            </Button>
          </div>
        </form>
      </div>
    </AccountShell>
  );
}
