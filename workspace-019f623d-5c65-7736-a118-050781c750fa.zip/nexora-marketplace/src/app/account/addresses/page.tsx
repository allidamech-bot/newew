"use client";

import { useEffect, useState } from "react";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Address } from "@/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function AddressesPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [form, setForm] = useState({
    label: "Home",
    fullName: "",
    phone: "",
    line1: "",
    city: "",
    postalCode: "",
    country: "TR",
  });

  async function load() {
    if (!user) return;
    setAddresses(await getServices().profile.listAddresses(user.id));
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  return (
    <AccountShell title="Addresses">
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-3">
          {addresses.map((a) => (
            <div key={a.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-semibold">
                    {a.label} {a.isDefault ? "· Default" : ""}
                  </p>
                  <p className="mt-1 text-sm text-[var(--muted-foreground)]">
                    {a.fullName}
                    <br />
                    {a.line1}
                    <br />
                    {a.city}, {a.postalCode}, {a.country}
                    <br />
                    {a.phone}
                  </p>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={async () => {
                    await getServices().profile.deleteAddress(a.id);
                    toast.message("Address removed");
                    await load();
                  }}
                >
                  Delete
                </Button>
              </div>
            </div>
          ))}
          {!addresses.length ? (
            <p className="text-sm text-[var(--muted-foreground)]">No addresses saved yet.</p>
          ) : null}
        </div>

        <form
          className="space-y-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!user) return;
            await getServices().profile.createAddress({
              userId: user.id,
              label: form.label,
              fullName: form.fullName,
              phone: form.phone,
              line1: form.line1,
              city: form.city,
              postalCode: form.postalCode,
              country: form.country,
              isDefault: addresses.length === 0,
            });
            toast.success("Address added");
            setForm({
              label: "Home",
              fullName: "",
              phone: "",
              line1: "",
              city: "",
              postalCode: "",
              country: "TR",
            });
            await load();
          }}
        >
          <h2 className="font-semibold">Add address</h2>
          {(
            [
              ["label", "Label"],
              ["fullName", "Full name"],
              ["phone", "Phone"],
              ["line1", "Address line"],
              ["city", "City"],
              ["postalCode", "Postal code"],
              ["country", "Country"],
            ] as const
          ).map(([key, label]) => (
            <div key={key} className="space-y-1">
              <Label htmlFor={key}>{label}</Label>
              <Input
                id={key}
                value={form[key]}
                onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                required
              />
            </div>
          ))}
          <Button type="submit" className="w-full">
            Save address
          </Button>
        </form>
      </div>
    </AccountShell>
  );
}
