"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Notification } from "@/types";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/feedback/empty-state";
import { localize, useLocaleStore } from "@/i18n";

export default function NotificationsPage() {
  const user = useAuthStore((s) => s.session?.user);
  const locale = useLocaleStore((s) => s.locale);
  const [items, setItems] = useState<Notification[]>([]);

  async function load() {
    if (!user) return;
    setItems(await getServices().notifications.list(user.id));
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  return (
    <AccountShell title="Notifications">
      <div className="mb-4 flex justify-end">
        <Button
          variant="outline"
          size="sm"
          onClick={async () => {
            if (!user) return;
            await getServices().notifications.markAllRead(user.id);
            await load();
          }}
        >
          Mark all read
        </Button>
      </div>
      {!items.length ? (
        <EmptyState
          title="You're all caught up"
          description="Important order, message, and account updates will appear here."
        />
      ) : (
        <div className="space-y-2">
          {items.map((n) => (
            <div
              key={n.id}
              className={`rounded-xl border p-4 ${
                n.read
                  ? "border-[var(--border)] bg-[var(--card)]"
                  : "border-[var(--primary)]/30 bg-[var(--accent)]/40"
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-semibold">{localize(n.title, locale)}</p>
                  <p className="mt-1 text-sm text-[var(--muted-foreground)]">
                    {localize(n.body, locale)}
                  </p>
                  <p className="mt-2 text-xs text-[var(--muted-foreground)]">
                    {new Date(n.createdAt).toLocaleString()} · {n.category}
                  </p>
                </div>
                <div className="flex flex-col gap-2">
                  {!n.read ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={async () => {
                        if (!user) return;
                        await getServices().notifications.markRead(n.id, user.id);
                        await load();
                      }}
                    >
                      Mark read
                    </Button>
                  ) : null}
                  {n.href ? (
                    <Button asChild size="sm" variant="outline">
                      <Link href={n.href}>Open</Link>
                    </Button>
                  ) : null}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </AccountShell>
  );
}
