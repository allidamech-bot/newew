"use client";

import { useEffect, useState } from "react";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Review } from "@/types";
import { RatingDisplay } from "@/components/commerce/rating-display";
import { EmptyState } from "@/components/feedback/empty-state";

export default function AccountReviewsPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [reviews, setReviews] = useState<Review[]>([]);

  useEffect(() => {
    if (!user) return;
    void getServices().reviews.listByBuyer(user.id).then(setReviews);
  }, [user]);

  return (
    <AccountShell title="Your reviews">
      {!reviews.length ? (
        <EmptyState
          title="No reviews yet"
          description="After a completed purchase, you can leave a verified review from the order details."
          actionLabel="View orders"
          actionHref="/account/orders"
        />
      ) : (
        <div className="space-y-3">
          {reviews.map((r) => (
            <article key={r.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
              <div className="flex items-center justify-between gap-3">
                <p className="font-semibold">{r.title.en}</p>
                <RatingDisplay rating={r.productRating} />
              </div>
              <p className="mt-2 text-sm text-[var(--muted-foreground)]">{r.body.en}</p>
            </article>
          ))}
        </div>
      )}
    </AccountShell>
  );
}
