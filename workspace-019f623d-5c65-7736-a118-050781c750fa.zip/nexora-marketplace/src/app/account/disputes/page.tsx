"use client";

import { useEffect, useState } from "react";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Dispute, Order } from "@/types";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/feedback/empty-state";
import { toast } from "sonner";

export default function DisputesPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [orderId, setOrderId] = useState("");
  const [reason, setReason] = useState("Item not received");

  async function load() {
    if (!user) return;
    setDisputes(await getServices().disputes.listByBuyer(user.id));
    setOrders(await getServices().orders.listByBuyer(user.id));
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  return (
    <AccountShell title="Disputes">
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-3">
          {disputes.map((d) => (
            <div key={d.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
              <p className="font-semibold capitalize">{d.status.replaceAll("_", " ")}</p>
              <p className="mt-1 text-sm text-[var(--muted-foreground)]">
                Order {d.orderId} · {d.reason}
              </p>
            </div>
          ))}
          {!disputes.length ? (
            <EmptyState
              title="No disputes"
              description="Open a dispute only after attempting seller resolution for eligible order issues."
            />
          ) : null}
        </div>
        <form
          className="space-y-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!user || !orderId) return;
            const order = orders.find((o) => o.id === orderId);
            if (!order) return;
            await getServices().disputes.create({
              orderId,
              buyerId: user.id,
              sellerId: order.sellerId,
              storeId: order.storeId,
              reason,
              evidenceUrls: [],
            });
            toast.success("Dispute opened");
            await load();
          }}
        >
          <h2 className="font-semibold">Open dispute</h2>
          <select
            className="h-10 w-full rounded-md border border-[var(--border)] bg-[var(--background)] px-3 text-sm"
            value={orderId}
            onChange={(e) => setOrderId(e.target.value)}
            required
          >
            <option value="">Select order</option>
            {orders.map((o) => (
              <option key={o.id} value={o.id}>
                {o.orderNumber}
              </option>
            ))}
          </select>
          <Textarea value={reason} onChange={(e) => setReason(e.target.value)} />
          <Button type="submit">Submit dispute</Button>
        </form>
      </div>
    </AccountShell>
  );
}
