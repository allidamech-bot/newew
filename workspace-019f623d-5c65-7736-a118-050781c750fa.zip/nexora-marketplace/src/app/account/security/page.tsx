"use client";

import { AccountShell } from "@/components/layout/account-shell";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function SecurityPage() {
  return (
    <AccountShell title="Security">
      <div className="space-y-4 max-w-2xl">
        <section className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-5">
          <h2 className="font-semibold">Password</h2>
          <p className="mt-1 text-sm text-[var(--muted-foreground)]">
            Demo mode uses fixed credentials. Password reset is simulated for architecture readiness.
          </p>
          <Button className="mt-4" variant="outline" onClick={() => toast.success("Reset email queued (mock)")}>
            Send password reset
          </Button>
        </section>
        <section className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-5">
          <h2 className="font-semibold">Two-factor authentication</h2>
          <p className="mt-1 text-sm text-[var(--muted-foreground)]">
            Placeholder architecture ready for authenticator apps when Supabase MFA is connected.
          </p>
          <Button className="mt-4" variant="outline" disabled>
            Enable 2FA (coming soon)
          </Button>
        </section>
        <section className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-5">
          <h2 className="font-semibold">Active sessions</h2>
          <p className="mt-1 text-sm text-[var(--muted-foreground)]">
            This browser session is active. Session metadata will sync from Supabase Auth later.
          </p>
        </section>
      </div>
    </AccountShell>
  );
}
