"use client";

import { useState } from "react";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export default function ProfilePage() {
  const session = useAuthStore((s) => s.session);
  const setSession = useAuthStore.setState;
  const user = session?.user;
  const [form, setForm] = useState({
    firstName: user?.firstName || "",
    lastName: user?.lastName || "",
    displayName: user?.displayName || "",
    phone: user?.phone || "",
    bio: user?.bio || "",
  });

  if (!user) return null;

  return (
    <AccountShell title="Profile">
      <form
        className="max-w-xl space-y-4 rounded-xl border border-[var(--border)] bg-[var(--card)] p-5"
        onSubmit={async (e) => {
          e.preventDefault();
          const updated = await getServices().profile.update(user.id, {
            firstName: form.firstName,
            lastName: form.lastName,
            displayName: form.displayName,
            phone: form.phone,
            bio: form.bio,
          });
          if (session) {
            setSession({ session: { ...session, user: updated } });
          }
          toast.success("Profile updated");
        }}
      >
        {(
          [
            ["firstName", "First name"],
            ["lastName", "Last name"],
            ["displayName", "Display name"],
            ["phone", "Phone"],
            ["bio", "Bio"],
          ] as const
        ).map(([key, label]) => (
          <div key={key} className="space-y-1">
            <Label htmlFor={key}>{label}</Label>
            <Input
              id={key}
              value={form[key]}
              onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
            />
          </div>
        ))}
        <p className="text-sm text-[var(--muted-foreground)]">Email: {user.email}</p>
        <Button type="submit">Save profile</Button>
      </form>
    </AccountShell>
  );
}
