"use client";

import { useEffect, useState } from "react";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Product } from "@/types";
import { ProductCard } from "@/components/commerce/product-card";
import { EmptyState } from "@/components/feedback/empty-state";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function WishlistsPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [products, setProducts] = useState<Product[]>([]);

  async function load() {
    if (!user) return;
    const ids = await getServices().wishlists.listProductIds(user.id);
    const list = (
      await Promise.all(ids.map((id) => getServices().catalog.getProductById(id)))
    ).filter(Boolean) as Product[];
    setProducts(list);
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  return (
    <AccountShell title="Wishlists">
      {!products.length ? (
        <EmptyState
          title="No saved items yet"
          description="Save products you love for later from product pages and discovery cards."
          actionLabel="Discover products"
          actionHref="/discover"
        />
      ) : (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
          {products.map((p) => (
            <div key={p.id} className="space-y-2">
              <ProductCard product={p} />
              <Button
                variant="outline"
                size="sm"
                className="w-full"
                onClick={async () => {
                  if (!user) return;
                  await getServices().wishlists.removeItem(user.id, p.id);
                  toast.message("Removed from wishlist");
                  await load();
                }}
              >
                Remove
              </Button>
            </div>
          ))}
        </div>
      )}
    </AccountShell>
  );
}
