"use client";

import { Suspense, useEffect, useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Order, ReturnRequest } from "@/types";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/feedback/empty-state";
import { toast } from "sonner";

function ReturnsPageInner() {
  const user = useAuthStore((s) => s.session?.user);
  const search = useSearchParams();
  const prefillOrderId = search.get("orderId") || "";
  const [returns, setReturns] = useState<ReturnRequest[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [orderId, setOrderId] = useState(prefillOrderId);
  const [reason, setReason] = useState("Changed mind");
  const [notes, setNotes] = useState("");

  async function load() {
    if (!user) return;
    const services = getServices();
    setReturns(await services.returns.listByBuyer(user.id));
    setOrders(await services.orders.listByBuyer(user.id));
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  useEffect(() => {
    if (prefillOrderId) setOrderId(prefillOrderId);
  }, [prefillOrderId]);

  const eligibleOrders = useMemo(
    () => orders.filter((o) => ["completed", "delivered"].includes(o.status)),
    [orders]
  );

  return (
    <AccountShell title="Returns">
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-3">
          {returns.map((r) => (
            <div key={r.id} className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
              <p className="font-semibold capitalize">{r.status.replaceAll("_", " ")}</p>
              <p className="mt-1 text-sm text-[var(--muted-foreground)]">
                Order {r.orderId} · {r.reason}
              </p>
              {r.notes ? <p className="mt-2 text-sm">{r.notes}</p> : null}
            </div>
          ))}
          {!returns.length ? (
            <EmptyState
              title="No return requests"
              description="Eligible completed orders can request returns within the product return window."
            />
          ) : null}
        </div>

        <form
          className="space-y-3 rounded-xl border border-[var(--border)] bg-[var(--card)] p-4"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!user || !orderId) return;
            const order = orders.find((o) => o.id === orderId);
            if (!order) return;
            await getServices().returns.create({
              orderId,
              buyerId: user.id,
              storeId: order.storeId,
              reason,
              notes,
              itemIds: order.items.map((i) => i.id),
              evidenceUrls: [],
            });
            toast.success("Return requested");
            setNotes("");
            await load();
          }}
        >
          <h2 className="font-semibold">Request a return</h2>
          <label className="block text-sm">
            Order
            <select
              className="mt-1 h-10 w-full rounded-md border border-[var(--border)] bg-[var(--background)] px-3"
              value={orderId}
              onChange={(e) => setOrderId(e.target.value)}
              required
            >
              <option value="">Select order</option>
              {eligibleOrders.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.orderNumber}
                </option>
              ))}
            </select>
          </label>
          <label className="block text-sm">
            Reason
            <select
              className="mt-1 h-10 w-full rounded-md border border-[var(--border)] bg-[var(--background)] px-3"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            >
              <option>Changed mind</option>
              <option>Item damaged</option>
              <option>Wrong item</option>
              <option>Not as described</option>
            </select>
          </label>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Additional notes (optional)"
          />
          <Button type="submit" disabled={!eligibleOrders.length}>
            Submit return request
          </Button>
        </form>
      </div>
    </AccountShell>
  );
}


export default function ReturnsPage() {
  return (
    <Suspense fallback={<AccountShell title="Returns"><p className="text-sm text-[var(--muted-foreground)]">Loading…</p></AccountShell>}>
      <ReturnsPageInner />
    </Suspense>
  );
}
