"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useParams, useRouter } from "next/navigation";
import { AccountShell } from "@/components/layout/account-shell";
import { getServices } from "@/services";
import type { Order } from "@/types";
import { formatMoney } from "@/lib/money";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuthStore } from "@/features/auth/store";
import { toast } from "sonner";

export default function OrderDetailPage() {
  const params = useParams<{ id: string }>();
  const user = useAuthStore((s) => s.session?.user);
  const [order, setOrder] = useState<Order | null>(null);
  const router = useRouter();

  useEffect(() => {
    void getServices().orders.getById(params.id).then(setOrder);
  }, [params.id]);

  if (!order) {
    return (
      <AccountShell title="Order">
        <p className="text-sm text-[var(--muted-foreground)]">Loading order…</p>
      </AccountShell>
    );
  }

  return (
    <AccountShell title={order.orderNumber}>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <Badge className="capitalize">{order.status.replaceAll("_", " ")}</Badge>
        <Badge variant="outline" className="capitalize">
          Payment {order.paymentStatus.replaceAll("_", " ")}
        </Badge>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.3fr_0.7fr]">
        <div className="space-y-4">
          <section className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <h2 className="font-semibold">Items</h2>
            <ul className="mt-3 divide-y divide-[var(--border)]">
              {order.items.map((item) => (
                <li key={item.id} className="flex gap-3 py-3">
                  <div className="relative h-16 w-14 overflow-hidden rounded-md bg-[var(--muted)]">
                    <Image
                      src={item.imageUrl || "/images/placeholder-product.svg"}
                      alt=""
                      fill
                      className="object-cover"
                      unoptimized
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-medium">{item.title.en}</p>
                    <p className="text-sm text-[var(--muted-foreground)]">Qty {item.quantity}</p>
                  </div>
                  <p className="text-sm font-semibold">{formatMoney(item.total)}</p>
                </li>
              ))}
            </ul>
          </section>

          <section className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4">
            <h2 className="font-semibold">Status timeline</h2>
            <ol className="mt-4 space-y-3">
              {order.timeline.map((event, idx) => (
                <li key={`${event.status}-${idx}`} className="flex gap-3 text-sm">
                  <span className="mt-1 h-2.5 w-2.5 shrink-0 rounded-full bg-[var(--primary)]" />
                  <div>
                    <p className="font-medium capitalize">{String(event.status).replaceAll("_", " ")}</p>
                    <p className="text-[var(--muted-foreground)]">
                      {new Date(event.at).toLocaleString()}
                      {event.note ? ` · ${event.note}` : ""}
                    </p>
                  </div>
                </li>
              ))}
            </ol>
          </section>
        </div>

        <aside className="space-y-4">
          <section className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 text-sm">
            <h2 className="font-semibold">Summary</h2>
            <dl className="mt-3 space-y-2">
              <div className="flex justify-between">
                <dt>Subtotal</dt>
                <dd>{formatMoney(order.subtotal)}</dd>
              </div>
              <div className="flex justify-between">
                <dt>Discount</dt>
                <dd>{formatMoney(order.discount)}</dd>
              </div>
              <div className="flex justify-between">
                <dt>Shipping</dt>
                <dd>{formatMoney(order.shipping)}</dd>
              </div>
              <div className="flex justify-between">
                <dt>Tax</dt>
                <dd>{formatMoney(order.tax)}</dd>
              </div>
              <div className="flex justify-between border-t border-[var(--border)] pt-2 font-semibold">
                <dt>Total</dt>
                <dd>{formatMoney(order.total)}</dd>
              </div>
            </dl>
          </section>

          <section className="rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 text-sm">
            <h2 className="font-semibold">Delivery</h2>
            <p className="mt-2">{order.shippingAddress.fullName}</p>
            <p className="text-[var(--muted-foreground)]">
              {order.shippingAddress.line1}, {order.shippingAddress.city},{" "}
              {order.shippingAddress.country}
            </p>
            <p className="mt-2 text-[var(--muted-foreground)]">
              Method: {order.shippingMethod || "—"}
            </p>
            {order.trackingNumber ? (
              <p className="mt-2">
                Tracking: <span className="font-medium">{order.trackingNumber}</span>
              </p>
            ) : null}
          </section>

          <div className="flex flex-col gap-2">
            {["pending_payment", "paid", "confirmed", "preparing"].includes(order.status) ? (
              <Button
                variant="outline"
                onClick={async () => {
                  if (!user) return;
                  try {
                    const updated = await getServices().orders.cancel(order.id, user.id);
                    setOrder(updated);
                    toast.success("Order cancelled");
                  } catch (e) {
                    toast.error(e instanceof Error ? e.message : "Cannot cancel");
                  }
                }}
              >
                Cancel order
              </Button>
            ) : null}
            {["completed", "delivered"].includes(order.status) ? (
              <Button asChild variant="outline">
                <Link href={`/account/returns?orderId=${order.id}`}>Request return</Link>
              </Button>
            ) : null}
            <Button
              variant="secondary"
              onClick={async () => {
                if (!user) return;
                const { conversation } = await getServices().conversations.sendMessage({
                  senderId: user.id,
                  recipientId: order.sellerId,
                  body: `Support request for order ${order.orderNumber}`,
                  orderId: order.id,
                  storeId: order.storeId,
                  type: "order_support",
                });
                router.push(`/account/messages/${conversation.id}`);
              }}
            >
              Message seller
            </Button>
          </div>
        </aside>
      </div>
    </AccountShell>
  );
}
