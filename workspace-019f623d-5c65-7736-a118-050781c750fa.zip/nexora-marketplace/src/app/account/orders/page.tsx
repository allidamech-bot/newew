"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { AccountShell } from "@/components/layout/account-shell";
import { useAuthStore } from "@/features/auth/store";
import { getServices } from "@/services";
import type { Order } from "@/types";
import { formatMoney } from "@/lib/money";
import { Badge } from "@/components/ui/badge";
import { EmptyState } from "@/components/feedback/empty-state";

export default function AccountOrdersPage() {
  const user = useAuthStore((s) => s.session?.user);
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    if (!user) return;
    void getServices().orders.listByBuyer(user.id).then(setOrders);
  }, [user]);

  return (
    <AccountShell title="Orders">
      {!orders.length ? (
        <EmptyState
          title="No orders yet"
          description="When you purchase, your orders will appear here with full tracking."
          actionLabel="Start discovering"
          actionHref="/discover"
        />
      ) : (
        <div className="space-y-3">
          {orders.map((order) => (
            <Link
              key={order.id}
              href={`/account/orders/${order.id}`}
              className="block rounded-xl border border-[var(--border)] bg-[var(--card)] p-4 hover:border-[var(--primary)]"
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-semibold">{order.orderNumber}</p>
                  <p className="mt-1 text-sm text-[var(--muted-foreground)]">
                    {new Date(order.createdAt).toLocaleString()} · {order.items.length} item(s)
                  </p>
                </div>
                <div className="text-end">
                  <Badge variant="secondary" className="capitalize">
                    {order.status.replaceAll("_", " ")}
                  </Badge>
                  <p className="mt-2 font-semibold">{formatMoney(order.total)}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </AccountShell>
  );
}
