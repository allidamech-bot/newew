import { getServices } from "@/services";
import { DiscoverClient } from "@/features/search/discover-client";

export const metadata = { title: "Discover" };

export default async function DiscoverPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const sort = typeof sp.sort === "string" ? sp.sort : "recommended";
  const type = typeof sp.type === "string" ? sp.type : undefined;
  const page = Number(typeof sp.page === "string" ? sp.page : "1") || 1;
  const services = getServices();
  const [products, categories, stores] = await Promise.all([
    services.catalog.listProducts({
      sort,
      page,
      pageSize: 12,
      filters: type
        ? { productTypes: [type as "digital" | "service" | "physical"] }
        : undefined,
    }),
    services.categories.getTree(),
    services.stores.list({ pageSize: 20 }),
  ]);

  return (
    <DiscoverClient
      initialProducts={products.items}
      total={products.total}
      categories={categories}
      stores={stores.items}
      initialSort={sort}
      initialType={type}
    />
  );
}
