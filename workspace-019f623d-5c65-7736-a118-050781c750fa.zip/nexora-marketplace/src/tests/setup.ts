import "@testing-library/jest-dom/vitest";
import { beforeEach } from "vitest";
import { resetMockDb } from "@/mocks/db";

beforeEach(() => {
  resetMockDb();
});
