import { describe, expect, it } from "vitest";
import { getServices } from "@/services";
import { resetMockDb } from "@/mocks/db";

describe("promotion validation", () => {
  it("validates WELCOME10 against minimum spend", async () => {
    resetMockDb();
    const services = getServices();
    const ok = await services.promotions.validateCoupon("WELCOME10", 6000);
    expect(ok?.code).toBe("WELCOME10");

    const tooLow = await services.promotions.validateCoupon("WELCOME10", 1000);
    expect(tooLow).toBeNull();
  });

  it("returns null for unknown coupons", async () => {
    resetMockDb();
    const result = await getServices().promotions.validateCoupon("NOPE", 10000);
    expect(result).toBeNull();
  });
});
