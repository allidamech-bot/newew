import { describe, expect, it } from "vitest";
import {
  addMoney,
  applyFixedDiscount,
  applyPercentDiscount,
  discountPercent,
  fromMajor,
  money,
  multiplyMoney,
  percentOf,
  subtractMoney,
  sumMoney,
  toMajor,
} from "@/lib/money";

describe("money helpers", () => {
  it("converts major/minor units without floating error", () => {
    expect(fromMajor(19.99).amount).toBe(1999);
    expect(toMajor(money(1999))).toBe(19.99);
  });

  it("adds and multiplies using integer minor units", () => {
    const a = fromMajor(10);
    const b = fromMajor(2.5);
    expect(addMoney(a, b).amount).toBe(1250);
    expect(multiplyMoney(a, 3).amount).toBe(3000);
  });

  it("applies percent and fixed discounts", () => {
    const price = fromMajor(100);
    expect(applyPercentDiscount(price, 10).amount).toBe(9000);
    expect(applyFixedDiscount(price, fromMajor(15)).amount).toBe(8500);
    expect(percentOf(price, 8).amount).toBe(800);
  });

  it("computes discount percent and sum", () => {
    expect(discountPercent(fromMajor(200), fromMajor(150))).toBe(25);
    expect(sumMoney([fromMajor(1), fromMajor(2), fromMajor(3)]).amount).toBe(600);
    expect(subtractMoney(fromMajor(5), fromMajor(2)).amount).toBe(300);
  });

  it("rejects currency mismatches", () => {
    expect(() => addMoney(money(100, "USD"), money(100, "EUR"))).toThrow(/Currency mismatch/);
  });
});
