import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

describe("create_checkout_order_group SQL contract", () => {
  const sql = readFileSync(
    resolve("supabase/migrations/00013_complete_checkout_function.sql"),
    "utf8"
  );

  it("implements full checkout responsibilities", () => {
    expect(sql).toMatch(/create or replace function public\.create_checkout_order_group/i);
    expect(sql).toMatch(/idempotency_key/i);
    expect(sql).toMatch(/for update/i);
    expect(sql).toMatch(/order_groups/i);
    expect(sql).toMatch(/order_items/i);
    expect(sql).toMatch(/order_addresses/i);
    expect(sql).toMatch(/order_status_events/i);
    expect(sql).toMatch(/inventory_movements/i);
    expect(sql).toMatch(/payment_intents/i);
    expect(sql).toMatch(/commission_records/i);
    expect(sql).toMatch(/price changed/i);
    expect(sql).toMatch(/insufficient stock/i);
    expect(sql).not.toMatch(/requires cart tables to be populated by application service layer/i);
  });
});
