import { describe, expect, it } from "vitest";
import { getServices } from "@/services";
import { resetMockDb } from "@/mocks/db";
import { fromMajor } from "@/lib/money";

describe("seller/admin management CRUD", () => {
  it("creates promotion, shipping method, staff, warehouse and transfer", async () => {
    resetMockDb();
    const services = getServices();
    const seller = await services.auth.signIn("seller@nexora.demo", "demo1234");
    const stores = await services.stores.listByOwner(seller.user.id);
    const storeId = stores[0]?.id;
    expect(storeId).toBeTruthy();
    if (!storeId) return;

    const promo = await services.sellerManagement.createPromotion({
      storeId,
      platformWide: false,
      name: { en: "Flash 5", ar: "عرض 5" },
      type: "percentage",
      value: 5,
      startsAt: new Date().toISOString(),
      endsAt: new Date(Date.now() + 86400000).toISOString(),
      stackable: false,
      active: true,
    });
    expect(promo.id).toBeTruthy();

    const method = await services.sellerManagement.createShippingMethod({
      storeId,
      name: { en: "Local rush", ar: "سريع" },
      description: { en: "1 day", ar: "يوم" },
      price: fromMajor(9),
      minDays: 1,
      maxDays: 1,
      enabled: true,
      type: "flat",
    });
    expect(method.enabled).toBe(true);

    const staff = await services.sellerManagement.inviteStaff({
      storeId,
      email: "helper@nexora.demo",
      name: "Helper",
      role: "catalog_manager",
      permissions: ["catalog.manage"],
    });
    expect(staff.status).toBe("invited");
    await services.sellerManagement.updateStaff(staff.id, { status: "active" });
    await services.sellerManagement.removeStaff(staff.id);

    const wh = await services.sellerManagement.createWarehouse({
      storeId,
      name: "Secondary",
      location: "Dock 2",
      isDefault: false,
    });
    const warehouses = await services.sellerManagement.listWarehouses(storeId);
    expect(warehouses.some((w) => w.id === wh.id)).toBe(true);

    const xfer = await services.sellerManagement.transferStock({
      storeId,
      fromWarehouseId: warehouses[0].id,
      toWarehouseId: wh.id,
      productId: "prod-camp-mug",
      quantity: 2,
      createdBy: seller.user.id,
    });
    expect(xfer.quantity).toBe(2);
  });

  it("admin can update settings, modules, refunds and campaigns", async () => {
    resetMockDb();
    const services = getServices();
    const admin = await services.auth.signIn("admin@nexora.demo", "demo1234");
    const settings = await services.adminManagement.updateSettings(
      { defaultCommissionPercent: 9 },
      admin.user.id
    );
    expect(settings.defaultCommissionPercent).toBe(9);

    const mod = await services.adminManagement.upsertHomepageModule({
      type: "editorial",
      title: { en: "Campaign block", ar: "حملة" },
      visible: true,
      sortOrder: 0,
    });
    expect(mod.id).toBeTruthy();
    await services.adminManagement.upsertHomepageModule({ ...mod, visible: false });

    const refund = await services.adminManagement.createRefund({
      orderId: "ord-1",
      amount: fromMajor(10),
      reason: "Test refund",
    });
    expect(refund.status).toBe("succeeded");

    const camp = await services.adminManagement.upsertCampaign({
      title: { en: "Hello", ar: "مرحبا" },
      body: { en: "Body", ar: "نص" },
      audience: "all",
      channel: "in_app",
      status: "draft",
    });
    const sent = await services.adminManagement.sendCampaign(camp.id);
    expect(sent.status).toBe("sent");
  });
});
