import { describe, expect, it } from "vitest";
import { getServices } from "@/services";
import { resetMockDb, mockDb } from "@/mocks/db";

describe("cart and order flow (integration-style unit)", () => {
  it("adds product to cart, applies coupon, and creates multi-store-safe order", async () => {
    resetMockDb();
    const services = getServices();
    const cartKey = "test-guest-cart";

    const cart = await services.cart.addItem(cartKey, {
      productId: "prod-linen-lamp",
      quantity: 1,
    });
    expect(cart.items).toHaveLength(1);

    await services.cart.applyCoupon(cartKey, "WELCOME10");
    const withCoupon = await services.cart.getCart(cartKey);
    expect(withCoupon.couponCode).toBe("WELCOME10");

    // sign-in buyer and merge
    const session = await services.auth.signIn("buyer@nexora.demo", "demo1234");
    const merged = await services.cart.mergeGuestCart(cartKey, session.user.id);
    expect(merged.items.length).toBeGreaterThan(0);

    const addresses = await services.profile.listAddresses(session.user.id);
    expect(addresses.length).toBeGreaterThan(0);

    const orders = await services.orders.createFromCart({
      cartKey: `user:${session.user.id}`,
      buyerId: session.user.id,
      addressId: addresses[0].id,
      shippingMethodId: "ship-standard",
      paymentMethod: "card",
      idempotencyKey: "test-idem-1",
    });

    expect(orders.length).toBeGreaterThan(0);
    expect(orders[0].orderNumber).toMatch(/^SOL-/);
    expect(orders[0].timeline.some((t) => t.status === "paid")).toBe(true);

    // idempotent replay
    const again = await services.orders.createFromCart({
      cartKey: `user:${session.user.id}`,
      buyerId: session.user.id,
      addressId: addresses[0].id,
      shippingMethodId: "ship-standard",
      paymentMethod: "card",
      idempotencyKey: "test-idem-1",
    });
    expect(again[0].groupId).toBe(orders[0].groupId);
    expect(mockDb.orders.filter((o) => o.groupId === orders[0].groupId).length).toBe(
      orders.length
    );
  });

  it("prevents overselling when inventory is insufficient", async () => {
    resetMockDb();
    const services = getServices();
    const product = mockDb.products.find((p) => p.id === "prod-desk-mat");
    expect(product).toBeTruthy();
    if (product) product.quantity = 1;

    const cartKey = "oos-cart";
    await services.cart.addItem(cartKey, { productId: "prod-desk-mat", quantity: 1 });
    // force quantity above available via direct mutation of cart for conflict path
    const cart = await services.cart.getCart(cartKey);
    cart.items[0].quantity = 5;
    cart.items[0].maxQuantity = 5;

    const session = await services.auth.signIn("buyer@nexora.demo", "demo1234");
    await services.cart.mergeGuestCart(cartKey, session.user.id);
    const addresses = await services.profile.listAddresses(session.user.id);

    await expect(
      services.orders.createFromCart({
        cartKey: `user:${session.user.id}`,
        buyerId: session.user.id,
        addressId: addresses[0].id,
        shippingMethodId: "ship-standard",
        paymentMethod: "card",
        idempotencyKey: "test-idem-oos",
      })
    ).rejects.toThrow(/stock|inventory|insufficient/i);
  });
});
