import { describe, expect, it } from "vitest";
import { getServices } from "@/services";
import { resetMockDb } from "@/mocks/db";

describe("auth and role demos", () => {
  it("signs in demo buyer/seller/admin accounts", async () => {
    resetMockDb();
    const services = getServices();
    const buyer = await services.auth.signIn("buyer@nexora.demo", "demo1234");
    expect(buyer.user.roles).toContain("buyer");

    const seller = await services.auth.signIn("seller@nexora.demo", "demo1234");
    expect(seller.user.roles).toContain("seller");

    const admin = await services.auth.signIn("admin@nexora.demo", "demo1234");
    expect(admin.user.roles).toContain("admin");
  });

  it("rejects invalid credentials", async () => {
    resetMockDb();
    await expect(getServices().auth.signIn("buyer@nexora.demo", "wrong")).rejects.toThrow();
  });
});
