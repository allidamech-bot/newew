import { describe, expect, it, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import { ProductCard } from "@/components/commerce/product-card";
import { fromMajor } from "@/lib/money";
import type { Product } from "@/types";

vi.mock("next/image", () => ({
  default: (props: { alt: string }) => {
    // eslint-disable-next-line @next/next/no-img-element
    return <img alt={props.alt} />;
  },
}));

vi.mock("next/link", () => ({
  default: ({ children, href }: { children: React.ReactNode; href: string }) => (
    <a href={href}>{children}</a>
  ),
}));

const product: Product = {
  id: "p1",
  storeId: "s1",
  sellerId: "u1",
  categoryId: "c1",
  type: "physical",
  slug: "test-product",
  title: { en: "Test Product", ar: "منتج" },
  description: { en: "desc", ar: "وصف" },
  shortDescription: { en: "short", ar: "قصير" },
  status: "published",
  moderationStatus: "approved",
  visibility: "public",
  condition: "new",
  basePrice: fromMajor(42),
  currency: "USD",
  quantity: 5,
  reservedQuantity: 0,
  lowStockThreshold: 2,
  inventoryPolicy: "deny",
  requiresShipping: true,
  tags: [],
  media: [
    {
      id: "m1",
      bucket: "product-media",
      path: "x",
      url: "/images/placeholder-product.svg",
      isCover: true,
    },
  ],
  attributes: {},
  variantOptions: [],
  variants: [],
  rating: 4.5,
  reviewCount: 3,
  salesCount: 10,
  featured: false,
  offersEnabled: false,
  processingDays: 2,
  returnDays: 14,
  relatedProductIds: [],
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

describe("ProductCard", () => {
  it("renders product title and add to cart control", () => {
    render(<ProductCard product={product} />);
    expect(screen.getByText("Test Product")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /add to cart/i })).toBeInTheDocument();
  });
});
