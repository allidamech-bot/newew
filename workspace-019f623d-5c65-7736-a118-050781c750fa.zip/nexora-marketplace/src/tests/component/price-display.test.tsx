import { describe, expect, it } from "vitest";
import { render, screen } from "@testing-library/react";
import { PriceDisplay } from "@/components/commerce/price-display";
import { fromMajor } from "@/lib/money";

describe("PriceDisplay", () => {
  it("renders sale price and compare-at price", () => {
    render(
      <PriceDisplay price={fromMajor(80)} compareAt={fromMajor(100)} />
    );
    expect(screen.getByText(/\$80\.00/)).toBeInTheDocument();
    expect(screen.getByText(/\$100\.00/)).toBeInTheDocument();
    expect(screen.getByText(/−20%/)).toBeInTheDocument();
  });
});
