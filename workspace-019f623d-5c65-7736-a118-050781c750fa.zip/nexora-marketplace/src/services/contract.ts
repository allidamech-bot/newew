import type {
  AnalyticsRepository,
  AuditRepository,
  AuthRepository,
  BrandRepository,
  CartRepository,
  CatalogRepository,
  CategoryRepository,
  CmsRepository,
  ConversationRepository,
  DisputeRepository,
  InventoryRepository,
  MediaStorageProvider,
  ModerationRepository,
  NotificationRepository,
  OfferRepository,
  OrderRepository,
  PaymentProvider,
  ProfileRepository,
  PromotionRepository,
  ReturnsRepository,
  ReviewRepository,
  SearchProvider,
  ShippingProvider,
  StoreRepository,
  WishlistRepository,
} from "@/repositories/types";
import type {
  AdminManagementRepository,
  SellerManagementRepository,
} from "@/repositories/management";

/**
 * Shared typed service contract.
 * Both mock and Supabase adapters must satisfy this shape at compile time.
 */
export type MarketplaceServices = {
  auth: AuthRepository;
  profile: ProfileRepository;
  catalog: CatalogRepository;
  categories: CategoryRepository;
  stores: StoreRepository;
  brands: BrandRepository;
  cart: CartRepository;
  orders: OrderRepository;
  reviews: ReviewRepository;
  conversations: ConversationRepository;
  notifications: NotificationRepository;
  wishlists: WishlistRepository;
  promotions: PromotionRepository;
  search: SearchProvider;
  inventory: InventoryRepository;
  shipping: ShippingProvider;
  payments: PaymentProvider;
  media: MediaStorageProvider;
  moderation: ModerationRepository;
  returns: ReturnsRepository;
  disputes: DisputeRepository;
  offers: OfferRepository;
  analytics: AnalyticsRepository;
  cms: CmsRepository;
  audit: AuditRepository;
  sellerManagement: SellerManagementRepository;
  adminManagement: AdminManagementRepository;
  sellerApplications: {
    listByUser(userId: string): Promise<import("@/types").SellerApplication[]>;
    upsertDraft(input: {
      userId: string;
      sellerType: "individual" | "business";
      storeName: string;
      storeSlug: string;
      categories: string[];
      contactEmail: string;
      contactPhone: string;
      address: Record<string, string>;
      documents?: Array<{ type: string; path: string; status: string }>;
    }): Promise<import("@/types").SellerApplication>;
    submit(userId: string): Promise<import("@/types").SellerApplication>;
  };
};

export function assertMarketplaceServices(
  services: MarketplaceServices
): MarketplaceServices {
  return services;
}
