import { platform } from "@/config/platform";
import { mockServices } from "@/adapters/mock";
import { supabaseServices } from "@/adapters/supabase";
import { isSupabaseConfigured } from "@/lib/supabase/env";

/**
 * Service locator.
 * - mock (default): fully functional local marketplace with persistence
 * - supabase: real typed adapters (require credentials at runtime)
 */
export function getServices() {
  if (platform.dataProvider === "supabase") {
    if (!isSupabaseConfigured()) {
      // Keep local demos working if flag is flipped without credentials.
      return mockServices;
    }
    return supabaseServices as unknown as typeof mockServices;
  }
  return mockServices;
}

export type Services = ReturnType<typeof getServices>;
