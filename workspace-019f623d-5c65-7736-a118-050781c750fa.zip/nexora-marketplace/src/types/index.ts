import type { Money as MoneyType } from "@/lib/money";
export type Money = MoneyType;

export type Locale = "en" | "ar";
export type LocalizedString = { en: string; ar: string };

export type Role =
  | "guest"
  | "buyer"
  | "seller"
  | "store_staff"
  | "moderator"
  | "admin"
  | "super_admin";

export type ProductType =
  | "physical"
  | "digital"
  | "service"
  | "made_to_order"
  | "preorder";

export type ProductStatus =
  | "draft"
  | "pending_review"
  | "changes_requested"
  | "approved"
  | "published"
  | "paused"
  | "out_of_stock"
  | "archived"
  | "rejected"
  | "suspended";

export type OrderStatus =
  | "pending_payment"
  | "payment_processing"
  | "paid"
  | "confirmed"
  | "preparing"
  | "partially_shipped"
  | "shipped"
  | "out_for_delivery"
  | "delivered"
  | "completed"
  | "cancellation_requested"
  | "cancelled"
  | "return_requested"
  | "partially_returned"
  | "returned"
  | "refund_pending"
  | "partially_refunded"
  | "refunded"
  | "disputed"
  | "failed";

export type ReturnStatus =
  | "requested"
  | "awaiting_seller"
  | "more_info_required"
  | "approved"
  | "rejected"
  | "in_transit"
  | "received"
  | "refund_pending"
  | "refunded"
  | "closed"
  | "escalated";

export type DisputeStatus =
  | "open"
  | "awaiting_seller"
  | "awaiting_buyer"
  | "under_review"
  | "resolved"
  | "rejected"
  | "appealed"
  | "closed";

export type SellerApplicationStatus =
  | "draft"
  | "submitted"
  | "under_review"
  | "more_info_required"
  | "approved"
  | "rejected"
  | "suspended";

export type VerificationStatus = "unverified" | "pending" | "verified" | "rejected";

export type Condition = "new" | "refurbished" | "used_like_new" | "used_good" | "used_fair";

export type AttributeType =
  | "text"
  | "long_text"
  | "number"
  | "decimal"
  | "boolean"
  | "date"
  | "date_range"
  | "single_select"
  | "multi_select"
  | "color"
  | "size"
  | "measurement"
  | "location"
  | "brand"
  | "condition"
  | "file"
  | "url";

export type MediaRef = {
  id: string;
  bucket: string;
  path: string;
  url: string;
  alt?: LocalizedString;
  width?: number;
  height?: number;
  mimeType?: string;
  sizeBytes?: number;
  isCover?: boolean;
  sortOrder?: number;
  moderationStatus?: "pending" | "approved" | "rejected";
};

export type UserProfile = {
  id: string;
  email: string;
  displayName: string;
  firstName?: string;
  lastName?: string;
  avatarUrl?: string;
  phone?: string;
  roles: Role[];
  locale: Locale;
  currency: string;
  status: "active" | "suspended" | "deleted" | "pending_verification";
  emailVerified: boolean;
  createdAt: string;
  updatedAt: string;
  bio?: string;
};

export type Address = {
  id: string;
  userId: string;
  label: string;
  fullName: string;
  phone: string;
  line1: string;
  line2?: string;
  city: string;
  state?: string;
  postalCode: string;
  country: string;
  isDefault: boolean;
  instructions?: string;
};

export type Category = {
  id: string;
  parentId: string | null;
  slug: string;
  name: LocalizedString;
  description: LocalizedString;
  imageUrl?: string;
  icon?: string;
  sortOrder: number;
  featured: boolean;
  visible: boolean;
  productTypes: ProductType[];
  commissionPercent?: number;
  seoTitle?: LocalizedString;
  seoDescription?: LocalizedString;
  attributeIds: string[];
};

export type AttributeDefinition = {
  id: string;
  key: string;
  name: LocalizedString;
  type: AttributeType;
  unit?: string;
  required: boolean;
  filterable: boolean;
  searchable: boolean;
  variantAxis: boolean;
  options?: Array<{ id: string; value: string; label: LocalizedString; colorHex?: string }>;
  sortOrder: number;
};

export type Brand = {
  id: string;
  name: string;
  slug: string;
  logoUrl?: string;
};

export type Store = {
  id: string;
  ownerId: string;
  name: string;
  slug: string;
  description: LocalizedString;
  story?: LocalizedString;
  logoUrl?: string;
  coverUrl?: string;
  verificationStatus: VerificationStatus;
  status: "active" | "pending" | "suspended" | "closed";
  rating: number;
  reviewCount: number;
  salesCount: number;
  followersCount: number;
  responseRate: number;
  responseTimeHours: number;
  location?: string;
  shippingOrigin?: string;
  supportHours?: string;
  categories: string[];
  accentColor?: string;
  createdAt: string;
  policies?: {
    returns?: LocalizedString;
    shipping?: LocalizedString;
    warranty?: LocalizedString;
  };
  socialLinks?: Array<{ platform: string; url: string }>;
  announcement?: LocalizedString;
};

export type ProductVariant = {
  id: string;
  productId: string;
  sku: string;
  barcode?: string;
  title: LocalizedString;
  options: Record<string, string>;
  price: Money;
  compareAtPrice?: Money;
  costPrice?: Money;
  quantity: number;
  reservedQuantity: number;
  lowStockThreshold: number;
  weightGrams?: number;
  enabled: boolean;
  mediaIds: string[];
};

export type Product = {
  id: string;
  storeId: string;
  sellerId: string;
  categoryId: string;
  brandId?: string;
  type: ProductType;
  slug: string;
  title: LocalizedString;
  description: LocalizedString;
  shortDescription: LocalizedString;
  status: ProductStatus;
  moderationStatus: "pending" | "approved" | "rejected" | "changes_requested";
  visibility: "public" | "unlisted" | "private";
  condition: Condition;
  basePrice: Money;
  compareAtPrice?: Money;
  currency: string;
  sku?: string;
  quantity: number;
  reservedQuantity: number;
  lowStockThreshold: number;
  inventoryPolicy: "deny" | "continue";
  requiresShipping: boolean;
  weightGrams?: number;
  dimensionsCm?: { l: number; w: number; h: number };
  tags: string[];
  media: MediaRef[];
  attributes: Record<string, string | number | boolean | string[]>;
  variantOptions: Array<{ name: string; values: string[] }>;
  variants: ProductVariant[];
  rating: number;
  reviewCount: number;
  salesCount: number;
  featured: boolean;
  offersEnabled: boolean;
  processingDays: number;
  returnDays: number;
  warrantyMonths?: number;
  seoTitle?: LocalizedString;
  seoDescription?: LocalizedString;
  digitalFileRef?: string;
  serviceDurationMinutes?: number;
  relatedProductIds: string[];
  createdAt: string;
  updatedAt: string;
  publishedAt?: string;
};

export type CartItem = {
  id: string;
  productId: string;
  variantId?: string;
  storeId: string;
  quantity: number;
  unitPrice: Money;
  title: LocalizedString;
  imageUrl?: string;
  maxQuantity: number;
  notes?: string;
  savedForLater?: boolean;
};

export type Cart = {
  id: string;
  userId?: string;
  items: CartItem[];
  couponCode?: string;
  updatedAt: string;
};

export type OrderItem = {
  id: string;
  productId: string;
  variantId?: string;
  title: LocalizedString;
  imageUrl?: string;
  quantity: number;
  unitPrice: Money;
  total: Money;
  sku?: string;
  attributesSnapshot?: Record<string, string>;
};

export type Order = {
  id: string;
  orderNumber: string;
  groupId: string;
  buyerId: string;
  storeId: string;
  sellerId: string;
  status: OrderStatus;
  paymentStatus: "pending" | "paid" | "failed" | "refunded" | "partially_refunded";
  items: OrderItem[];
  subtotal: Money;
  discount: Money;
  shipping: Money;
  tax: Money;
  fees: Money;
  total: Money;
  currency: string;
  shippingAddress: Address;
  billingAddress?: Address;
  shippingMethod?: string;
  trackingNumber?: string;
  trackingUrl?: string;
  notes?: string;
  couponCode?: string;
  timeline: Array<{ status: OrderStatus | string; at: string; note?: string }>;
  createdAt: string;
  updatedAt: string;
  deliveredAt?: string;
};

export type Review = {
  id: string;
  productId: string;
  storeId: string;
  orderId: string;
  orderItemId: string;
  buyerId: string;
  buyerName: string;
  productRating: number;
  storeRating: number;
  deliveryRating: number;
  communicationRating: number;
  title: LocalizedString;
  body: LocalizedString;
  media: MediaRef[];
  verifiedPurchase: boolean;
  helpfulCount: number;
  moderationStatus: "pending" | "approved" | "rejected";
  sellerResponse?: { body: LocalizedString; createdAt: string };
  createdAt: string;
  updatedAt: string;
};

export type Conversation = {
  id: string;
  type: "product_inquiry" | "order_support" | "return_case" | "dispute_case" | "general" | "offer";
  participantIds: string[];
  storeId?: string;
  productId?: string;
  orderId?: string;
  subject: string;
  lastMessageAt: string;
  lastMessagePreview: string;
  unreadBy: Record<string, number>;
  status: "open" | "archived" | "blocked";
  createdAt: string;
};

export type Message = {
  id: string;
  conversationId: string;
  senderId: string;
  body: string;
  attachmentUrls?: string[];
  createdAt: string;
  readBy: string[];
};

export type Notification = {
  id: string;
  userId: string;
  category:
    | "account"
    | "security"
    | "orders"
    | "shipping"
    | "returns"
    | "refunds"
    | "messages"
    | "reviews"
    | "promotions"
    | "store"
    | "saved_search"
    | "price_drop"
    | "inventory"
    | "moderation"
    | "platform";
  title: LocalizedString;
  body: LocalizedString;
  href?: string;
  read: boolean;
  createdAt: string;
};

export type Wishlist = {
  id: string;
  userId: string;
  name: string;
  isDefault: boolean;
  isPrivate: boolean;
  itemIds: string[];
  createdAt: string;
};

export type WishlistItem = {
  id: string;
  wishlistId: string;
  productId: string;
  variantId?: string;
  note?: string;
  createdAt: string;
};

export type SavedSearch = {
  id: string;
  userId: string;
  name: string;
  query: string;
  filters: SearchFilters;
  sort: string;
  notify: boolean;
  createdAt: string;
};

export type SearchFilters = {
  categoryId?: string;
  storeId?: string;
  brandIds?: string[];
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  condition?: Condition[];
  productTypes?: ProductType[];
  verifiedSellersOnly?: boolean;
  inStockOnly?: boolean;
  freeShipping?: boolean;
  onSale?: boolean;
  tags?: string[];
  attributes?: Record<string, string | string[]>;
};

export type SearchResult = {
  products: Product[];
  stores: Store[];
  total: number;
  facets: {
    categories: Array<{ id: string; count: number }>;
    brands: Array<{ id: string; count: number }>;
    priceRange: { min: number; max: number };
  };
};

export type Promotion = {
  id: string;
  storeId?: string;
  platformWide: boolean;
  name: LocalizedString;
  type: "percentage" | "fixed" | "free_shipping";
  value: number;
  maxDiscount?: Money;
  minOrder?: Money;
  code?: string;
  startsAt: string;
  endsAt: string;
  usageLimit?: number;
  perUserLimit?: number;
  usageCount: number;
  productIds?: string[];
  categoryIds?: string[];
  storeIds?: string[];
  firstOrderOnly?: boolean;
  stackable: boolean;
  active: boolean;
};

export type Offer = {
  id: string;
  productId: string;
  variantId?: string;
  storeId: string;
  buyerId: string;
  sellerId: string;
  quantity: number;
  offeredPrice: Money;
  status: "pending" | "countered" | "accepted" | "declined" | "expired" | "cancelled";
  message?: string;
  expiresAt: string;
  history: Array<{
    by: string;
    price: Money;
    message?: string;
    at: string;
  }>;
  createdAt: string;
};

export type ReturnRequest = {
  id: string;
  orderId: string;
  buyerId: string;
  storeId: string;
  status: ReturnStatus;
  reason: string;
  notes?: string;
  itemIds: string[];
  evidenceUrls: string[];
  timeline: Array<{ status: ReturnStatus | string; at: string; note?: string }>;
  createdAt: string;
  updatedAt: string;
};

export type Dispute = {
  id: string;
  orderId: string;
  returnId?: string;
  buyerId: string;
  sellerId: string;
  storeId: string;
  status: DisputeStatus;
  reason: string;
  resolution?: string;
  evidenceUrls: string[];
  timeline: Array<{ status: DisputeStatus | string; at: string; note?: string; by?: string }>;
  createdAt: string;
  updatedAt: string;
};

export type Report = {
  id: string;
  reporterId: string;
  targetType: "product" | "review" | "store" | "user" | "message" | "conversation";
  targetId: string;
  reason: string;
  details?: string;
  status: "open" | "reviewing" | "resolved" | "dismissed";
  createdAt: string;
};

export type InventoryItem = {
  id: string;
  storeId: string;
  productId: string;
  variantId?: string;
  warehouseId: string;
  onHand: number;
  reserved: number;
  incoming: number;
  lowStockThreshold: number;
};

export type Warehouse = {
  id: string;
  storeId: string;
  name: string;
  location: string;
  isDefault: boolean;
};

export type InventoryMovement = {
  id: string;
  inventoryItemId: string;
  type:
    | "initial"
    | "manual_adjustment"
    | "sale"
    | "cancellation_release"
    | "return"
    | "restock"
    | "damage"
    | "transfer"
    | "correction";
  quantityDelta: number;
  note?: string;
  createdAt: string;
  createdBy: string;
};

export type ShippingMethod = {
  id: string;
  storeId?: string;
  name: LocalizedString;
  description: LocalizedString;
  price: Money;
  freeAbove?: Money;
  minDays: number;
  maxDays: number;
  enabled: boolean;
  type: "flat" | "weight" | "pickup" | "digital" | "service";
};

export type HelpArticle = {
  id: string;
  categoryId: string;
  slug: string;
  title: LocalizedString;
  body: LocalizedString;
  audience: "buyer" | "seller" | "all";
  updatedAt: string;
};

export type HelpCategory = {
  id: string;
  slug: string;
  name: LocalizedString;
  icon: string;
};

export type SupportTicket = {
  id: string;
  userId: string;
  subject: string;
  status: "open" | "in_progress" | "waiting_for_user" | "resolved" | "closed";
  priority: "low" | "normal" | "high";
  messages: Array<{ id: string; senderId: string; body: string; createdAt: string }>;
  createdAt: string;
  updatedAt: string;
};

export type HomepageModule =
  | {
      id: string;
      type: "editorial";
      title: LocalizedString;
      subtitle?: LocalizedString;
      cta?: { label: LocalizedString; href: string };
      imageUrl?: string;
      visible: boolean;
    }
  | {
      id: string;
      type: "product_rail";
      title: LocalizedString;
      source: "trending" | "recommended" | "deals" | "new" | "best_value" | "premium" | "sustainable" | "local" | "digital" | "services" | "fast_delivery";
      visible: boolean;
    }
  | {
      id: string;
      type: "category_universe";
      title: LocalizedString;
      visible: boolean;
    }
  | {
      id: string;
      type: "store_rail";
      title: LocalizedString;
      visible: boolean;
    }
  | {
      id: string;
      type: "intent_grid";
      title: LocalizedString;
      visible: boolean;
    }
  | {
      id: string;
      type: "trust";
      title: LocalizedString;
      visible: boolean;
    }
  | {
      id: string;
      type: "seller_cta";
      title: LocalizedString;
      subtitle: LocalizedString;
      visible: boolean;
    }
  | {
      id: string;
      type: "recently_viewed";
      title: LocalizedString;
      visible: boolean;
    };

export type AuditLog = {
  id: string;
  actorId: string;
  action: string;
  entityType: string;
  entityId: string;
  metadata?: Record<string, unknown>;
  createdAt: string;
};

export type PlatformSettings = {
  maintenanceMode: boolean;
  sellerRegistrationOpen: boolean;
  defaultCommissionPercent: number;
  returnWindowDays: number;
  requireProductModeration: boolean;
  allowGuestCheckout: boolean;
  supportedLocales: Locale[];
  defaultLocale: Locale;
  defaultCurrency: string;
};

export type SellerApplication = {
  id: string;
  userId: string;
  status: SellerApplicationStatus;
  sellerType: "individual" | "business";
  storeName: string;
  storeSlug: string;
  categories: string[];
  contactEmail: string;
  contactPhone: string;
  address: Partial<Address>;
  documents: Array<{ type: string; path: string; status: string }>;
  notes?: string;
  timeline: Array<{ status: SellerApplicationStatus | string; at: string; note?: string }>;
  createdAt: string;
  updatedAt: string;
};

export type Paginated<T> = {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
};

export type Session = {
  user: UserProfile;
  accessToken: string;
  expiresAt: string;
};
