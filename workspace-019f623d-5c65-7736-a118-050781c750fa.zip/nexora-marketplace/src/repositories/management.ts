import type {
  LocalizedString,
  Money,
  PlatformSettings,
  Promotion,
  ShippingMethod,
  SupportTicket,
  UserProfile,
  Warehouse,
} from "@/types";

export type StoreStaffMember = {
  id: string;
  storeId: string;
  userId: string;
  email: string;
  name: string;
  role: "store_admin" | "catalog_manager" | "inventory_manager" | "order_manager" | "customer_support" | "marketing_manager" | "analyst";
  permissions: string[];
  status: "active" | "invited" | "removed";
  createdAt: string;
};

export type WarehouseTransfer = {
  id: string;
  storeId: string;
  fromWarehouseId: string;
  toWarehouseId: string;
  productId: string;
  variantId?: string;
  quantity: number;
  note?: string;
  createdAt: string;
  createdBy: string;
};

export type NotificationCampaign = {
  id: string;
  title: LocalizedString;
  body: LocalizedString;
  audience: "all" | "buyers" | "sellers";
  channel: "in_app" | "email" | "push";
  status: "draft" | "scheduled" | "sent" | "cancelled";
  scheduledAt?: string;
  sentAt?: string;
  createdAt: string;
};

export type SecurityEvent = {
  id: string;
  userId?: string;
  eventType: string;
  ip?: string;
  userAgent?: string;
  metadata?: Record<string, unknown>;
  createdAt: string;
};

export type TransactionRecord = {
  id: string;
  orderId: string;
  orderNumber: string;
  buyerId: string;
  storeId: string;
  amount: Money;
  method: string;
  status: string;
  createdAt: string;
};

export type CommissionRecord = {
  id: string;
  orderId: string;
  storeId: string;
  ratePercent: number;
  amount: Money;
  createdAt: string;
};

export type RefundRecord = {
  id: string;
  orderId: string;
  amount: Money;
  reason: string;
  status: "pending" | "succeeded" | "failed";
  createdAt: string;
};

export type HomepageModuleRecord = {
  id: string;
  type: string;
  title: LocalizedString;
  subtitle?: LocalizedString;
  visible: boolean;
  sortOrder: number;
  config?: Record<string, unknown>;
};

export interface SellerManagementRepository {
  listPromotions(storeId: string): Promise<Promotion[]>;
  createPromotion(input: Omit<Promotion, "id" | "usageCount">): Promise<Promotion>;
  updatePromotion(id: string, patch: Partial<Promotion>): Promise<Promotion>;
  listShippingMethods(storeId: string): Promise<ShippingMethod[]>;
  createShippingMethod(input: Omit<ShippingMethod, "id">): Promise<ShippingMethod>;
  updateShippingMethod(id: string, patch: Partial<ShippingMethod>): Promise<ShippingMethod>;
  listStaff(storeId: string): Promise<StoreStaffMember[]>;
  inviteStaff(input: {
    storeId: string;
    email: string;
    name: string;
    role: StoreStaffMember["role"];
    permissions: string[];
  }): Promise<StoreStaffMember>;
  updateStaff(id: string, patch: Partial<StoreStaffMember>): Promise<StoreStaffMember>;
  removeStaff(id: string): Promise<void>;
  listWarehouses(storeId: string): Promise<Warehouse[]>;
  createWarehouse(input: Omit<Warehouse, "id">): Promise<Warehouse>;
  transferStock(input: Omit<WarehouseTransfer, "id" | "createdAt">): Promise<WarehouseTransfer>;
  listTransfers(storeId: string): Promise<WarehouseTransfer[]>;
  listAudit(storeId: string): Promise<Array<{ id: string; action: string; entityType: string; entityId: string; createdAt: string; actorId: string }>>;
}

export interface AdminManagementRepository {
  listUsers(): Promise<UserProfile[]>;
  updateUserStatus(userId: string, status: UserProfile["status"]): Promise<UserProfile>;
  updateUserRoles(userId: string, roles: UserProfile["roles"]): Promise<UserProfile>;
  updateStoreStatus(storeId: string, status: "active" | "suspended" | "closed" | "pending"): Promise<void>;
  listTransactions(): Promise<TransactionRecord[]>;
  listCommissions(): Promise<CommissionRecord[]>;
  listRefunds(): Promise<RefundRecord[]>;
  createRefund(input: Omit<RefundRecord, "id" | "createdAt" | "status">): Promise<RefundRecord>;
  listCampaigns(): Promise<NotificationCampaign[]>;
  upsertCampaign(input: Partial<NotificationCampaign> & { title: LocalizedString; body: LocalizedString }): Promise<NotificationCampaign>;
  sendCampaign(id: string): Promise<NotificationCampaign>;
  listSecurityEvents(): Promise<SecurityEvent[]>;
  getSettings(): Promise<PlatformSettings>;
  updateSettings(patch: Partial<PlatformSettings>, actorId: string): Promise<PlatformSettings>;
  listHomepageModules(): Promise<HomepageModuleRecord[]>;
  upsertHomepageModule(input: Partial<HomepageModuleRecord> & { type: string; title: LocalizedString }): Promise<HomepageModuleRecord>;
  reorderHomepageModules(ids: string[]): Promise<HomepageModuleRecord[]>;
  listSupportTickets(): Promise<SupportTicket[]>;
  replySupportTicket(ticketId: string, senderId: string, body: string): Promise<SupportTicket>;
}
