import type {
  Address,
  AttributeDefinition,
  Brand,
  Cart,
  Category,
  Conversation,
  Dispute,
  HelpArticle,
  HelpCategory,
  HomepageModule,
  InventoryItem,
  Message,
  Notification,
  Offer,
  Order,
  OrderStatus,
  Paginated,
  Product,
  Promotion,
  Report,
  ReturnRequest,
  Review,
  SearchFilters,
  SearchResult,
  SellerApplication,
  Session,
  ShippingMethod,
  Store,
  SupportTicket,
  UserProfile,
  Wishlist,
} from "@/types";

export type ListParams = {
  page?: number;
  pageSize?: number;
  query?: string;
  sort?: string;
};

export interface AuthRepository {
  signIn(email: string, password: string): Promise<Session>;
  signUp(input: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
  }): Promise<Session>;
  signOut(token: string): Promise<void>;
  getSession(token: string): Promise<Session | null>;
  requestPasswordReset(email: string): Promise<{ ok: true }>;
  listDemoAccounts(): Promise<Array<{ email: string; role: string }>>;
}

export interface ProfileRepository {
  getById(id: string): Promise<UserProfile | null>;
  update(id: string, patch: Partial<UserProfile>): Promise<UserProfile>;
  listAddresses(userId: string): Promise<Address[]>;
  createAddress(address: Omit<Address, "id">): Promise<Address>;
  updateAddress(id: string, patch: Partial<Address>): Promise<Address>;
  deleteAddress(id: string): Promise<void>;
}

export interface CatalogRepository {
  listProducts(
    params?: ListParams & { filters?: SearchFilters }
  ): Promise<Paginated<Product>>;
  getProductBySlug(slug: string): Promise<Product | null>;
  getProductById(id: string): Promise<Product | null>;
  listRelated(productId: string, limit?: number): Promise<Product[]>;
  createProduct(product: Partial<Product> & Pick<Product, "storeId" | "sellerId" | "title" | "type">): Promise<Product>;
  updateProduct(id: string, patch: Partial<Product>): Promise<Product>;
  listByStore(storeId: string, params?: ListParams): Promise<Paginated<Product>>;
}

export interface CategoryRepository {
  list(): Promise<Category[]>;
  getBySlug(slug: string): Promise<Category | null>;
  getTree(): Promise<Array<Category & { children: Category[] }>>;
  listAttributes(categoryId: string): Promise<AttributeDefinition[]>;
  listAllAttributes(): Promise<AttributeDefinition[]>;
  createCategory(input: Partial<Category> & Pick<Category, "name" | "slug">): Promise<Category>;
  updateCategory(id: string, patch: Partial<Category>): Promise<Category>;
}

export interface StoreRepository {
  list(params?: ListParams): Promise<Paginated<Store>>;
  getBySlug(slug: string): Promise<Store | null>;
  getById(id: string): Promise<Store | null>;
  listByOwner(ownerId: string): Promise<Store[]>;
  follow(userId: string, storeId: string): Promise<void>;
  unfollow(userId: string, storeId: string): Promise<void>;
  listFollowed(userId: string): Promise<Store[]>;
  updateStore(id: string, patch: Partial<Store>): Promise<Store>;
}

export interface BrandRepository {
  list(): Promise<Brand[]>;
}

export interface CartRepository {
  getCart(key: string): Promise<Cart>;
  addItem(
    key: string,
    item: {
      productId: string;
      variantId?: string;
      quantity: number;
      notes?: string;
    }
  ): Promise<Cart>;
  updateItem(key: string, itemId: string, quantity: number): Promise<Cart>;
  removeItem(key: string, itemId: string): Promise<Cart>;
  applyCoupon(key: string, code: string): Promise<Cart>;
  clearCoupon(key: string): Promise<Cart>;
  mergeGuestCart(guestKey: string, userId: string): Promise<Cart>;
  saveForLater(key: string, itemId: string): Promise<Cart>;
}

export interface OrderRepository {
  createFromCart(input: {
    cartKey: string;
    buyerId: string;
    addressId: string;
    shippingMethodId: string;
    paymentMethod: string;
    idempotencyKey: string;
  }): Promise<Order[]>;
  listByBuyer(buyerId: string): Promise<Order[]>;
  listByStore(storeId: string): Promise<Order[]>;
  getById(id: string): Promise<Order | null>;
  updateStatus(id: string, status: OrderStatus, note?: string): Promise<Order>;
  cancel(id: string, buyerId: string): Promise<Order>;
}

export interface ReviewRepository {
  listByProduct(productId: string): Promise<Review[]>;
  listByStore(storeId: string): Promise<Review[]>;
  listByBuyer(buyerId: string): Promise<Review[]>;
  create(input: Omit<Review, "id" | "createdAt" | "updatedAt" | "helpfulCount" | "moderationStatus">): Promise<Review>;
  respond(reviewId: string, body: { en: string; ar: string }): Promise<Review>;
}

export interface ConversationRepository {
  listForUser(userId: string): Promise<Conversation[]>;
  get(id: string): Promise<Conversation | null>;
  listMessages(conversationId: string): Promise<Message[]>;
  sendMessage(input: {
    conversationId?: string;
    senderId: string;
    recipientId: string;
    body: string;
    productId?: string;
    orderId?: string;
    storeId?: string;
    type?: Conversation["type"];
  }): Promise<{ conversation: Conversation; message: Message }>;
  markRead(conversationId: string, userId: string): Promise<void>;
}

export interface NotificationRepository {
  list(userId: string): Promise<Notification[]>;
  markRead(id: string, userId: string): Promise<void>;
  markAllRead(userId: string): Promise<void>;
}

export interface WishlistRepository {
  list(userId: string): Promise<Wishlist[]>;
  addItem(userId: string, productId: string, variantId?: string): Promise<void>;
  removeItem(userId: string, productId: string): Promise<void>;
  listProductIds(userId: string): Promise<string[]>;
}

export interface PromotionRepository {
  listActive(): Promise<Promotion[]>;
  validateCoupon(code: string, subtotalMinor: number, userId?: string): Promise<Promotion | null>;
}

export interface SearchProvider {
  search(query: string, filters?: SearchFilters, sort?: string, page?: number, pageSize?: number): Promise<SearchResult>;
  suggest(query: string): Promise<string[]>;
  trending(): Promise<string[]>;
}

export interface InventoryRepository {
  listByStore(storeId: string): Promise<InventoryItem[]>;
  adjust(input: {
    productId: string;
    variantId?: string;
    delta: number;
    note?: string;
    actorId: string;
  }): Promise<InventoryItem>;
}

export interface ShippingProvider {
  listMethods(storeId?: string, productType?: string): Promise<ShippingMethod[]>;
  estimate(input: {
    storeId: string;
    subtotalMinor: number;
    methodId: string;
  }): Promise<{ priceMinor: number; minDays: number; maxDays: number }>;
}

export interface PaymentProvider {
  createIntent(input: {
    amountMinor: number;
    currency: string;
    method: string;
    idempotencyKey: string;
  }): Promise<{ id: string; status: "requires_confirmation" | "succeeded" | "failed"; clientSecret?: string }>;
  confirm(intentId: string): Promise<{ status: "succeeded" | "failed" }>;
}

export interface MediaStorageProvider {
  upload(input: {
    bucket: string;
    path: string;
    dataUrl: string;
    contentType: string;
  }): Promise<{ bucket: string; path: string; url: string }>;
  getPublicUrl(bucket: string, path: string): Promise<string>;
}

export interface ModerationRepository {
  listReports(): Promise<Report[]>;
  updateReport(id: string, status: Report["status"]): Promise<Report>;
  listPendingProducts(): Promise<Product[]>;
  moderateProduct(id: string, status: Product["moderationStatus"], note?: string): Promise<Product>;
  listSellerApplications(): Promise<SellerApplication[]>;
  reviewApplication(id: string, status: SellerApplication["status"], note?: string): Promise<SellerApplication>;
}

export interface ReturnsRepository {
  listByBuyer(buyerId: string): Promise<ReturnRequest[]>;
  listByStore(storeId: string): Promise<ReturnRequest[]>;
  create(input: Omit<ReturnRequest, "id" | "createdAt" | "updatedAt" | "timeline" | "status">): Promise<ReturnRequest>;
  updateStatus(id: string, status: ReturnRequest["status"], note?: string): Promise<ReturnRequest>;
}

export interface DisputeRepository {
  list(): Promise<Dispute[]>;
  listByBuyer(buyerId: string): Promise<Dispute[]>;
  create(input: Omit<Dispute, "id" | "createdAt" | "updatedAt" | "timeline" | "status">): Promise<Dispute>;
  updateStatus(id: string, status: Dispute["status"], note?: string): Promise<Dispute>;
}

export interface OfferRepository {
  listForUser(userId: string): Promise<Offer[]>;
  create(input: Omit<Offer, "id" | "createdAt" | "history" | "status">): Promise<Offer>;
  respond(id: string, action: "accept" | "decline" | "counter", priceMinor?: number, message?: string, by?: string): Promise<Offer>;
}

export interface AnalyticsRepository {
  track(event: string, payload?: Record<string, unknown>): Promise<void>;
  sellerMetrics(storeId: string): Promise<{
    revenueMinor: number;
    orders: number;
    unitsSold: number;
    aovMinor: number;
    conversion: number;
    productViews: number;
    storeViews: number;
    followers: number;
    lowStock: number;
    pendingOrders: number;
    topProducts: Array<{ productId: string; title: string; sales: number }>;
    salesTrend: Array<{ date: string; revenueMinor: number }>;
  }>;
  platformMetrics(): Promise<{
    gmvMinor: number;
    orders: number;
    activeBuyers: number;
    activeSellers: number;
    openDisputes: number;
    openReports: number;
    pendingProducts: number;
    pendingApplications: number;
  }>;
}

export interface CmsRepository {
  homepageModules(): Promise<HomepageModule[]>;
  collections(): Promise<
    Array<{
      id: string;
      slug: string;
      title: { en: string; ar: string };
      description: { en: string; ar: string };
      productIds: string[];
      imageUrl?: string;
    }>
  >;
  getCollection(slug: string): Promise<{
    id: string;
    slug: string;
    title: { en: string; ar: string };
    description: { en: string; ar: string };
    productIds: string[];
    imageUrl?: string;
  } | null>;
  helpCategories(): Promise<HelpCategory[]>;
  helpArticles(categorySlug?: string): Promise<HelpArticle[]>;
  helpArticle(slug: string): Promise<HelpArticle | null>;
  createTicket(input: { userId: string; subject: string; body: string }): Promise<SupportTicket>;
  listTickets(userId: string): Promise<SupportTicket[]>;
}

export interface AuditRepository {
  list(limit?: number): Promise<
    Array<{
      id: string;
      actorId: string;
      action: string;
      entityType: string;
      entityId: string;
      metadata?: Record<string, unknown>;
      createdAt: string;
    }>
  >;
  write(entry: {
    actorId: string;
    action: string;
    entityType: string;
    entityId: string;
    metadata?: Record<string, unknown>;
  }): Promise<void>;
}
