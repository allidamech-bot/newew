-- Enable RLS on exposed tables
alter table public.profiles enable row level security;
alter table public.profile_private enable row level security;
alter table public.addresses enable row level security;
alter table public.stores enable row level security;
alter table public.products enable row level security;
alter table public.product_translations enable row level security;
alter table public.product_media enable row level security;
alter table public.product_variants enable row level security;
alter table public.categories enable row level security;
alter table public.category_translations enable row level security;
alter table public.carts enable row level security;
alter table public.cart_items enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.reviews enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_participants enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;
alter table public.wishlists enable row level security;
alter table public.wishlist_items enable row level security;
alter table public.reports enable row level security;
alter table public.return_requests enable row level security;
alter table public.disputes enable row level security;
alter table public.seller_applications enable row level security;
alter table public.seller_documents enable row level security;
alter table public.inventory_items enable row level security;
alter table public.audit_logs enable row level security;
alter table public.support_tickets enable row level security;
alter table public.help_articles enable row level security;
alter table public.homepage_modules enable row level security;
alter table public.platform_settings enable row level security;
alter table public.feature_flags enable row level security;

-- Public catalog reads
create policy categories_public_read on public.categories
  for select using (visible = true or public.is_admin());

create policy category_translations_public_read on public.category_translations
  for select using (
    exists (
      select 1 from public.categories c
      where c.id = category_id and (c.visible = true or public.is_admin())
    )
  );

create policy products_public_read on public.products
  for select using (
    (status = 'published' and visibility = 'public' and moderation_status = 'approved')
    or seller_id = auth.uid()
    or public.owns_store(store_id)
    or public.is_admin()
  );

create policy product_translations_public_read on public.product_translations
  for select using (
    exists (select 1 from public.products p where p.id = product_id)
  );

create policy product_media_public_read on public.product_media
  for select using (
    exists (
      select 1 from public.products p
      where p.id = product_id
        and (
          (p.status = 'published' and p.visibility = 'public')
          or p.seller_id = auth.uid()
          or public.owns_store(p.store_id)
          or public.is_admin()
        )
    )
  );

create policy product_variants_public_read on public.product_variants
  for select using (
    exists (select 1 from public.products p where p.id = product_id)
  );

create policy stores_public_read on public.stores
  for select using (status = 'active' or owner_id = auth.uid() or public.is_admin());

create policy homepage_modules_public_read on public.homepage_modules
  for select using (visible = true or public.is_admin());

create policy help_articles_public_read on public.help_articles
  for select using (true);

create policy reviews_public_read on public.reviews
  for select using (moderation_status = 'approved' or buyer_id = auth.uid() or public.is_admin());

-- Profile / private data
create policy profiles_self_read on public.profiles
  for select using (id = auth.uid() or public.is_admin());

create policy profiles_self_update on public.profiles
  for update using (id = auth.uid());

create policy profile_private_self on public.profile_private
  for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid() or public.is_admin());

create policy addresses_self on public.addresses
  for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

-- Carts
create policy carts_self on public.carts
  for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

create policy cart_items_self on public.cart_items
  for all using (
    exists (select 1 from public.carts c where c.id = cart_id and c.user_id = auth.uid())
    or public.is_admin()
  )
  with check (
    exists (select 1 from public.carts c where c.id = cart_id and c.user_id = auth.uid())
  );

-- Orders
create policy orders_buyer_or_seller on public.orders
  for select using (
    buyer_id = auth.uid()
    or seller_id = auth.uid()
    or public.owns_store(store_id)
    or public.is_admin()
  );

create policy order_items_via_order on public.order_items
  for select using (
    exists (
      select 1 from public.orders o
      where o.id = order_id
        and (
          o.buyer_id = auth.uid()
          or o.seller_id = auth.uid()
          or public.owns_store(o.store_id)
          or public.is_admin()
        )
    )
  );

-- Messaging
create policy conversations_participant on public.conversations
  for select using (
    exists (
      select 1 from public.conversation_participants cp
      where cp.conversation_id = id and cp.user_id = auth.uid()
    ) or public.is_admin()
  );

create policy conversation_participants_self on public.conversation_participants
  for select using (user_id = auth.uid() or public.is_admin());

create policy messages_participant on public.messages
  for select using (
    exists (
      select 1 from public.conversation_participants cp
      where cp.conversation_id = messages.conversation_id and cp.user_id = auth.uid()
    ) or public.is_admin()
  );

create policy messages_insert_participant on public.messages
  for insert with check (
    sender_id = auth.uid()
    and exists (
      select 1 from public.conversation_participants cp
      where cp.conversation_id = conversation_id and cp.user_id = auth.uid()
    )
  );

-- Notifications / wishlists
create policy notifications_self on public.notifications
  for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

create policy wishlists_self on public.wishlists
  for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

create policy wishlist_items_self on public.wishlist_items
  for all using (
    exists (select 1 from public.wishlists w where w.id = wishlist_id and w.user_id = auth.uid())
    or public.is_admin()
  )
  with check (
    exists (select 1 from public.wishlists w where w.id = wishlist_id and w.user_id = auth.uid())
  );

-- Seller inventory / applications
create policy inventory_store_members on public.inventory_items
  for all using (public.has_store_permission(store_id, 'inventory.manage') or public.is_admin())
  with check (public.has_store_permission(store_id, 'inventory.manage') or public.is_admin());

create policy seller_applications_self on public.seller_applications
  for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid() or public.is_admin());

create policy seller_documents_restricted on public.seller_documents
  for select using (
    public.is_admin()
    or exists (
      select 1 from public.seller_applications sa
      where sa.id = application_id and sa.user_id = auth.uid()
    )
  );

-- Returns / disputes / reports
create policy returns_parties on public.return_requests
  for select using (
    buyer_id = auth.uid() or public.owns_store(store_id) or public.is_admin()
  );

create policy disputes_parties on public.disputes
  for select using (
    buyer_id = auth.uid() or seller_id = auth.uid() or public.is_admin()
  );

create policy reports_self_or_admin on public.reports
  for select using (reporter_id = auth.uid() or public.is_admin());

create policy reports_insert_auth on public.reports
  for insert with check (reporter_id = auth.uid());

-- Admin only
create policy audit_logs_admin on public.audit_logs
  for select using (public.is_admin());

create policy platform_settings_admin on public.platform_settings
  for all using (public.is_admin())
  with check (public.is_admin());

create policy feature_flags_read on public.feature_flags
  for select using (true);

create policy feature_flags_admin_write on public.feature_flags
  for all using (public.is_admin())
  with check (public.is_admin());

create policy support_tickets_self on public.support_tickets
  for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid() or public.is_admin());
