-- Atomic checkout helpers (server/edge function ready)
create or replace function public.reserve_inventory(
  p_product_id uuid,
  p_variant_id uuid,
  p_quantity integer
) returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  item public.inventory_items%rowtype;
begin
  if p_quantity <= 0 then
    raise exception 'quantity must be positive';
  end if;

  select * into item
  from public.inventory_items
  where product_id = p_product_id
    and (variant_id is not distinct from p_variant_id)
  for update;

  if not found then
    raise exception 'inventory item not found';
  end if;

  if (item.on_hand - item.reserved) < p_quantity then
    return false;
  end if;

  update public.inventory_items
  set reserved = reserved + p_quantity
  where id = item.id;

  insert into public.inventory_movements(inventory_item_id, type, quantity_delta, note)
  values (item.id, 'sale', -p_quantity, 'reserve for checkout');

  return true;
end;
$$;

create or replace function public.release_inventory(
  p_product_id uuid,
  p_variant_id uuid,
  p_quantity integer
) returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  item public.inventory_items%rowtype;
begin
  select * into item
  from public.inventory_items
  where product_id = p_product_id
    and (variant_id is not distinct from p_variant_id)
  for update;

  if not found then
    return;
  end if;

  update public.inventory_items
  set reserved = greatest(0, reserved - p_quantity),
      on_hand = on_hand + 0
  where id = item.id;

  insert into public.inventory_movements(inventory_item_id, type, quantity_delta, note)
  values (item.id, 'cancellation_release', p_quantity, 'release reservation');
end;
$$;

create or replace function public.can_access_order(p_order_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.orders o
    where o.id = p_order_id
      and (
        o.buyer_id = auth.uid()
        or o.seller_id = auth.uid()
        or public.owns_store(o.store_id)
        or public.is_admin()
      )
  );
$$;

create or replace function public.can_access_conversation(p_conversation_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.conversation_participants cp
    where cp.conversation_id = p_conversation_id
      and cp.user_id = auth.uid()
  ) or public.is_admin();
$$;

-- Storage bucket setup instructions (SQL for storage.buckets when using Supabase Storage)
-- Run in Supabase SQL editor after project creation:
--
-- insert into storage.buckets (id, name, public) values
--   ('product-media', 'product-media', true),
--   ('store-branding', 'store-branding', true),
--   ('user-avatars', 'user-avatars', true),
--   ('seller-documents', 'seller-documents', false),
--   ('dispute-evidence', 'dispute-evidence', false),
--   ('message-attachments', 'message-attachments', false),
--   ('digital-goods', 'digital-goods', false),
--   ('review-media', 'review-media', true),
--   ('support-attachments', 'support-attachments', false)
-- on conflict (id) do nothing;
--
-- Example private policy pattern:
-- create policy seller_documents_owner on storage.objects
--   for select using (
--     bucket_id = 'seller-documents'
--     and auth.uid()::text = (storage.foldername(name))[1]
--   );
