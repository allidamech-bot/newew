create table if not exists public.seller_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  seller_type text not null check (seller_type in ('individual', 'business')),
  legal_name text,
  business_name text,
  status text not null default 'pending',
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.seller_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'draft',
  seller_type text not null,
  store_name text,
  store_slug text,
  contact_email text,
  contact_phone text,
  categories jsonb not null default '[]'::jsonb,
  address jsonb not null default '{}'::jsonb,
  notes text,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.seller_documents (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.seller_applications(id) on delete cascade,
  doc_type text not null,
  storage_bucket text not null,
  storage_path text not null,
  status text not null default 'pending',
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.seller_application_events (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.seller_applications(id) on delete cascade,
  status text not null,
  note text,
  actor_id uuid references public.profiles(id),
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.stores (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id),
  name text not null,
  slug text not null unique,
  description_en text not null default '',
  description_ar text not null default '',
  story_en text,
  story_ar text,
  logo_path text,
  cover_path text,
  verification_status text not null default 'unverified',
  status text not null default 'pending',
  rating numeric(3,2) not null default 0,
  review_count integer not null default 0 check (review_count >= 0),
  sales_count integer not null default 0 check (sales_count >= 0),
  followers_count integer not null default 0 check (followers_count >= 0),
  response_rate numeric(5,2) not null default 0,
  response_time_hours integer not null default 24,
  location text,
  shipping_origin text,
  support_hours text,
  accent_color text,
  announcement_en text,
  announcement_ar text,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.store_members (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'active',
  created_at timestamptz not null default timezone('utc', now()),
  unique (store_id, user_id)
);

create table if not exists public.store_member_roles (
  member_id uuid not null references public.store_members(id) on delete cascade,
  role_id uuid not null references public.roles(id) on delete cascade,
  primary key (member_id, role_id)
);

create table if not exists public.store_follows (
  user_id uuid not null references public.profiles(id) on delete cascade,
  store_id uuid not null references public.stores(id) on delete cascade,
  created_at timestamptz not null default timezone('utc', now()),
  primary key (user_id, store_id)
);

create table if not exists public.store_policies (
  store_id uuid primary key references public.stores(id) on delete cascade,
  returns_en text,
  returns_ar text,
  shipping_en text,
  shipping_ar text,
  warranty_en text,
  warranty_ar text,
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.store_settings (
  store_id uuid primary key references public.stores(id) on delete cascade,
  settings jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.store_social_links (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  platform text not null,
  url text not null
);

create table if not exists public.store_collections (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  title_en text not null,
  title_ar text not null,
  slug text not null,
  sort_order integer not null default 0,
  unique (store_id, slug)
);

create table if not exists public.store_collection_items (
  collection_id uuid not null references public.store_collections(id) on delete cascade,
  product_id uuid not null,
  sort_order integer not null default 0,
  primary key (collection_id, product_id)
);

create table if not exists public.store_announcements (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  body_en text not null,
  body_ar text not null,
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default timezone('utc', now())
);

create index if not exists idx_stores_owner on public.stores(owner_id);
create index if not exists idx_stores_slug on public.stores(slug);
create index if not exists idx_store_follows_store on public.store_follows(store_id);
