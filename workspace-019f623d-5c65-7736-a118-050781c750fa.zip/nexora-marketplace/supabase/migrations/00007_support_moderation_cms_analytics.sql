create table if not exists public.support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  subject text not null,
  status text not null default 'open',
  priority text not null default 'normal',
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.support_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.support_tickets(id) on delete cascade,
  sender_id uuid not null references public.profiles(id),
  body text not null,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.help_categories (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name_en text not null,
  name_ar text not null,
  icon text
);

create table if not exists public.help_articles (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.help_categories(id),
  slug text not null unique,
  audience text not null default 'all',
  title_en text not null,
  title_ar text not null,
  body_en text not null,
  body_ar text not null,
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id),
  target_type text not null,
  target_id uuid not null,
  reason text not null,
  details text,
  status text not null default 'open',
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.moderation_actions (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id),
  target_type text not null,
  target_id uuid not null,
  action text not null,
  note text,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.platform_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.feature_flags (
  key text primary key,
  enabled boolean not null default false,
  description text,
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.homepage_modules (
  id uuid primary key default gen_random_uuid(),
  type text not null,
  title_en text,
  title_ar text,
  config jsonb not null default '{}'::jsonb,
  visible boolean not null default true,
  sort_order integer not null default 0
);

create table if not exists public.cms_pages (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title_en text not null,
  title_ar text not null,
  body_en text not null,
  body_ar text not null,
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid,
  action text not null,
  entity_type text not null,
  entity_id text not null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.security_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  event_type text not null,
  ip inet,
  user_agent text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.analytics_events (
  id uuid primary key default gen_random_uuid(),
  event_name text not null,
  user_id uuid,
  session_id text,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.daily_platform_metrics (
  day date primary key,
  gmv_minor bigint not null default 0,
  orders integer not null default 0,
  active_buyers integer not null default 0,
  active_sellers integer not null default 0
);

create table if not exists public.daily_store_metrics (
  day date not null,
  store_id uuid not null references public.stores(id) on delete cascade,
  revenue_minor bigint not null default 0,
  orders integer not null default 0,
  units_sold integer not null default 0,
  primary key (day, store_id)
);

create index if not exists idx_audit_entity_time on public.audit_logs(entity_type, entity_id, created_at desc);
create index if not exists idx_reports_status on public.reports(status, created_at desc);
create index if not exists idx_moderation_queue on public.products(moderation_status, updated_at desc);
