-- NEXORA marketplace — shared extensions and helpers
create extension if not exists "pgcrypto";
create extension if not exists "uuid-ossp";
create extension if not exists "unaccent";

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = timezone('utc', now());
  return new;
end;
$$;

create or replace function public.current_uid()
returns uuid
language sql
stable
as $$
  select auth.uid();
$$;

create or replace function public.has_platform_role(role_name text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.user_roles ur
    join public.roles r on r.id = ur.role_id
    where ur.user_id = auth.uid()
      and r.key = role_name
  );
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.has_platform_role('admin')
      or public.has_platform_role('super_admin')
      or public.has_platform_role('moderator');
$$;

create or replace function public.owns_store(store uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.stores s
    where s.id = store and s.owner_id = auth.uid()
  ) or exists (
    select 1 from public.store_members sm
    where sm.store_id = store and sm.user_id = auth.uid() and sm.status = 'active'
  );
$$;

create or replace function public.has_store_permission(store uuid, permission_key text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.owns_store(store)
      or public.is_admin()
      or exists (
        select 1
        from public.store_members sm
        join public.store_member_roles smr on smr.member_id = sm.id
        join public.role_permissions rp on rp.role_id = smr.role_id
        join public.permissions p on p.id = rp.permission_id
        where sm.store_id = store
          and sm.user_id = auth.uid()
          and sm.status = 'active'
          and p.key = permission_key
      );
$$;
