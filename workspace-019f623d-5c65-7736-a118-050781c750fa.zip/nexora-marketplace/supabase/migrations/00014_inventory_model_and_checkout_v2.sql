-- Inventory model correction + rebuilt atomic checkout
-- available = on_hand - reserved
-- checkout: reserved += qty (on_hand unchanged)
-- cancel pre-fulfillment: reserved -= qty
-- fulfillment: on_hand -= qty AND reserved -= qty

-- Strengthen inventory constraints
alter table public.inventory_items
  drop constraint if exists inventory_items_reserved_check;

alter table public.inventory_items
  drop constraint if exists inventory_items_on_hand_check;

alter table public.inventory_items
  add constraint inventory_items_on_hand_nonneg check (on_hand >= 0);

alter table public.inventory_items
  add constraint inventory_items_reserved_nonneg check (reserved >= 0);

alter table public.inventory_items
  add constraint inventory_items_reserved_lte_on_hand check (reserved <= on_hand);

-- Mirror constraints on products/variants reserved
alter table public.products
  drop constraint if exists products_reserved_lte_qty;

alter table public.products
  add constraint products_reserved_lte_qty check (reserved_quantity >= 0 and quantity >= 0 and reserved_quantity <= quantity);

alter table public.product_variants
  drop constraint if exists product_variants_reserved_lte_qty;

alter table public.product_variants
  add constraint product_variants_reserved_lte_qty check (reserved_quantity >= 0 and quantity >= 0 and reserved_quantity <= quantity);

-- Helper: lock inventory item deterministically by product/variant
create or replace function public.lock_inventory_item(
  p_product_id uuid,
  p_variant_id uuid
) returns public.inventory_items
language plpgsql
security definer
set search_path = public
as $$
declare
  item public.inventory_items;
begin
  select * into item
  from public.inventory_items
  where product_id = p_product_id
    and (variant_id is not distinct from p_variant_id)
  order by id
  for update;

  if not found then
    raise exception 'inventory item not found for product % variant %', p_product_id, p_variant_id;
  end if;
  return item;
end;
$$;

create or replace function public.reserve_inventory_item(
  p_product_id uuid,
  p_variant_id uuid,
  p_quantity integer,
  p_actor uuid,
  p_note text default null
) returns public.inventory_items
language plpgsql
security definer
set search_path = public
as $$
declare
  item public.inventory_items;
begin
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'quantity must be positive';
  end if;

  item := public.lock_inventory_item(p_product_id, p_variant_id);

  if (item.on_hand - item.reserved) < p_quantity then
    raise exception 'insufficient available stock';
  end if;

  update public.inventory_items
  set reserved = reserved + p_quantity
  where id = item.id
  returning * into item;

  -- keep product/variant mirrors in sync (quantity = on_hand, reserved_quantity = reserved)
  if p_variant_id is not null then
    update public.product_variants
    set reserved_quantity = item.reserved,
        quantity = item.on_hand
    where id = p_variant_id;
  else
    update public.products
    set reserved_quantity = item.reserved,
        quantity = item.on_hand
    where id = p_product_id;
  end if;

  insert into public.inventory_reservations(inventory_item_id, quantity, status)
  values (item.id, p_quantity, 'active');

  insert into public.inventory_movements(inventory_item_id, type, quantity_delta, note, created_by)
  values (item.id, 'sale', 0, coalesce(p_note, 'reserve (reserved++)'), p_actor);

  return item;
end;
$$;

create or replace function public.release_inventory_item(
  p_product_id uuid,
  p_variant_id uuid,
  p_quantity integer,
  p_actor uuid,
  p_note text default null
) returns public.inventory_items
language plpgsql
security definer
set search_path = public
as $$
declare
  item public.inventory_items;
begin
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'quantity must be positive';
  end if;

  item := public.lock_inventory_item(p_product_id, p_variant_id);

  if item.reserved < p_quantity then
    raise exception 'cannot release more than reserved';
  end if;

  update public.inventory_items
  set reserved = reserved - p_quantity
  where id = item.id
  returning * into item;

  if p_variant_id is not null then
    update public.product_variants
    set reserved_quantity = item.reserved,
        quantity = item.on_hand
    where id = p_variant_id;
  else
    update public.products
    set reserved_quantity = item.reserved,
        quantity = item.on_hand
    where id = p_product_id;
  end if;

  update public.inventory_reservations
  set status = 'released',
      released_at = timezone('utc', now())
  where inventory_item_id = item.id
    and status = 'active'
    and quantity = p_quantity
  ;

  insert into public.inventory_movements(inventory_item_id, type, quantity_delta, note, created_by)
  values (item.id, 'cancellation_release', 0, coalesce(p_note, 'release reservation (reserved--)'), p_actor);

  return item;
end;
$$;

create or replace function public.fulfill_inventory_item(
  p_product_id uuid,
  p_variant_id uuid,
  p_quantity integer,
  p_actor uuid,
  p_note text default null
) returns public.inventory_items
language plpgsql
security definer
set search_path = public
as $$
declare
  item public.inventory_items;
begin
  if p_quantity is null or p_quantity <= 0 then
    raise exception 'quantity must be positive';
  end if;

  item := public.lock_inventory_item(p_product_id, p_variant_id);

  if item.reserved < p_quantity or item.on_hand < p_quantity then
    raise exception 'cannot fulfill quantity';
  end if;

  update public.inventory_items
  set on_hand = on_hand - p_quantity,
      reserved = reserved - p_quantity
  where id = item.id
  returning * into item;

  if p_variant_id is not null then
    update public.product_variants
    set reserved_quantity = item.reserved,
        quantity = item.on_hand
    where id = p_variant_id;
  else
    update public.products
    set reserved_quantity = item.reserved,
        quantity = item.on_hand
    where id = p_product_id;
  end if;

  update public.inventory_reservations
  set status = 'consumed',
      released_at = timezone('utc', now())
  where inventory_item_id = item.id
    and status = 'active'
    and quantity = p_quantity;

  insert into public.inventory_movements(inventory_item_id, type, quantity_delta, note, created_by)
  values (item.id, 'sale', -p_quantity, coalesce(p_note, 'fulfillment (on_hand-- reserved--)'), p_actor);

  return item;
end;
$$;

-- Rebuild atomic multi-store checkout with correct reservation model
create or replace function public.create_checkout_order_group(
  p_cart_key text,
  p_buyer_id uuid,
  p_address_id uuid,
  p_shipping_method_id uuid,
  p_payment_method text,
  p_idempotency_key text
) returns setof public.orders
language plpgsql
security definer
set search_path = public
as $$
declare
  existing_group uuid;
  v_cart public.carts%rowtype;
  v_address public.addresses%rowtype;
  v_group_id uuid;
  store_rec record;
  v_order_id uuid;
  v_order_number text;
  v_subtotal integer;
  v_discount integer := 0;
  v_shipping integer := 0;
  v_tax integer := 0;
  v_total integer := 0;
  item_rec record;
  product_rec public.products%rowtype;
  variant_rec public.product_variants%rowtype;
  store_row public.stores%rowtype;
  unit_price integer;
  shipping_rec public.shipping_methods%rowtype;
  promo_rec public.promotions%rowtype;
  payment_id uuid;
  inv_item public.inventory_items%rowtype;
  lock_ids uuid[];
begin
  if auth.uid() is distinct from p_buyer_id and not public.is_admin() then
    raise exception 'forbidden';
  end if;

  if p_idempotency_key is null or length(trim(p_idempotency_key)) = 0 then
    raise exception 'idempotency key required';
  end if;

  select id into existing_group
  from public.order_groups
  where idempotency_key = p_idempotency_key;

  if existing_group is not null then
    return query select * from public.orders where group_id = existing_group order by created_at;
    return;
  end if;

  -- Lock cart
  select * into v_cart
  from public.carts
  where (guest_key = p_cart_key)
     or (user_id = p_buyer_id and (p_cart_key = 'user:' || p_buyer_id::text or p_cart_key like 'user:%'))
  order by updated_at desc
  limit 1
  for update;

  if not found then
    raise exception 'cart not found';
  end if;

  select * into v_address
  from public.addresses
  where id = p_address_id and user_id = p_buyer_id
  for update;

  if not found then
    raise exception 'address not found';
  end if;

  if not exists (
    select 1 from public.cart_items ci
    where ci.cart_id = v_cart.id and coalesce(ci.saved_for_later, false) = false
  ) then
    raise exception 'cart is empty';
  end if;

  -- Deterministic lock order for inventory rows to reduce deadlocks
  select array_agg(ii.id order by ii.id)
  into lock_ids
  from public.cart_items ci
  join public.inventory_items ii
    on ii.product_id = ci.product_id
   and (ii.variant_id is not distinct from ci.variant_id)
  where ci.cart_id = v_cart.id
    and coalesce(ci.saved_for_later, false) = false;

  if lock_ids is not null then
    perform 1 from public.inventory_items where id = any(lock_ids) order by id for update;
  end if;

  select * into shipping_rec
  from public.shipping_methods
  where id = p_shipping_method_id
  limit 1;

  if not found then
    select * into shipping_rec from public.shipping_methods where enabled = true order by id limit 1;
  end if;

  insert into public.order_groups(buyer_id, currency, idempotency_key)
  values (p_buyer_id, 'USD', p_idempotency_key)
  returning id into v_group_id;

  for store_rec in
    select distinct ci.store_id
    from public.cart_items ci
    where ci.cart_id = v_cart.id
      and coalesce(ci.saved_for_later, false) = false
    order by 1
  loop
    select * into store_row from public.stores where id = store_rec.store_id for update;
    if not found or store_row.status <> 'active' then
      raise exception 'store unavailable: %', store_rec.store_id;
    end if;

    v_subtotal := 0;
    v_discount := 0;
    v_shipping := coalesce(shipping_rec.price_minor, 0);
    v_tax := 0;
    v_total := 0;

    for item_rec in
      select *
      from public.cart_items ci
      where ci.cart_id = v_cart.id
        and ci.store_id = store_rec.store_id
        and coalesce(ci.saved_for_later, false) = false
      order by ci.product_id, ci.variant_id nulls first
      for update
    loop
      if item_rec.quantity is null or item_rec.quantity <= 0 then
        raise exception 'invalid cart quantity';
      end if;

      select * into product_rec
      from public.products
      where id = item_rec.product_id
      for update;

      if not found then
        raise exception 'product not found: %', item_rec.product_id;
      end if;

      if product_rec.status <> 'published'
         or product_rec.moderation_status <> 'approved'
         or product_rec.visibility <> 'public' then
        raise exception 'product unavailable: %', product_rec.id;
      end if;

      if product_rec.seller_id = p_buyer_id or store_row.owner_id = p_buyer_id then
        raise exception 'seller cannot purchase own product';
      end if;

      unit_price := product_rec.base_price_minor;

      if item_rec.variant_id is not null then
        select * into variant_rec
        from public.product_variants
        where id = item_rec.variant_id and product_id = product_rec.id
        for update;
        if not found or not variant_rec.enabled then
          raise exception 'variant unavailable: %', item_rec.variant_id;
        end if;
        unit_price := variant_rec.price_minor;
      end if;

      if unit_price <> item_rec.unit_price_minor then
        raise exception 'price changed for product %', product_rec.id;
      end if;

      if item_rec.currency is distinct from product_rec.currency then
        raise exception 'currency mismatch for product %', product_rec.id;
      end if;

      -- Reserve using inventory_items as source of truth (reserved++ only)
      inv_item := public.reserve_inventory_item(
        product_rec.id,
        item_rec.variant_id,
        item_rec.quantity,
        p_buyer_id,
        'checkout reservation'
      );

      v_subtotal := v_subtotal + (unit_price * item_rec.quantity);
    end loop;

    if v_cart.coupon_code is not null then
      select * into promo_rec
      from public.promotions
      where code = v_cart.coupon_code
        and active = true
        and starts_at <= timezone('utc', now())
        and ends_at >= timezone('utc', now())
      limit 1;
      if found then
        if promo_rec.min_order_minor is null or v_subtotal >= promo_rec.min_order_minor then
          if promo_rec.type = 'percentage' then
            v_discount := floor(v_subtotal * promo_rec.value / 100.0)::int;
            if promo_rec.max_discount_minor is not null then
              v_discount := least(v_discount, promo_rec.max_discount_minor);
            end if;
          elsif promo_rec.type = 'fixed' then
            v_discount := least(v_subtotal, floor(promo_rec.value * 100)::int);
          elsif promo_rec.type = 'free_shipping' then
            v_shipping := 0;
          end if;
          update public.promotions set usage_count = usage_count + 1 where id = promo_rec.id;
          insert into public.coupon_redemptions(promotion_id, user_id)
          values (promo_rec.id, p_buyer_id);
        end if;
      end if;
    end if;

    if shipping_rec.free_above_minor is not null and v_subtotal >= shipping_rec.free_above_minor then
      v_shipping := 0;
    end if;

    if not exists (
      select 1
      from public.cart_items ci
      join public.products p on p.id = ci.product_id
      where ci.cart_id = v_cart.id
        and ci.store_id = store_rec.store_id
        and coalesce(ci.saved_for_later, false) = false
        and p.requires_shipping = true
    ) then
      v_shipping := 0;
    end if;

    v_tax := floor((greatest(0, v_subtotal - v_discount) + v_shipping) * 0.08)::int;
    v_total := greatest(0, v_subtotal - v_discount + v_shipping + v_tax);
    v_order_number := 'NXR-' || to_char(timezone('utc', now()), 'YYMMDDHH24MISS') || '-' || substr(replace(gen_random_uuid()::text, '-', ''), 1, 6);

    insert into public.orders(
      order_number, group_id, buyer_id, store_id, seller_id,
      status, payment_status,
      subtotal_minor, discount_minor, shipping_minor, tax_minor, fees_minor, total_minor,
      currency, shipping_method, coupon_code
    ) values (
      v_order_number,
      v_group_id,
      p_buyer_id,
      store_rec.store_id,
      store_row.owner_id,
      'paid',
      'paid',
      v_subtotal,
      v_discount,
      v_shipping,
      v_tax,
      0,
      v_total,
      'USD',
      coalesce(shipping_rec.name_en, 'Standard'),
      v_cart.coupon_code
    ) returning id into v_order_id;

    -- Immutable order item snapshots
    insert into public.order_items(
      order_id, product_id, variant_id, title_en, title_ar, image_path,
      quantity, unit_price_minor, total_minor, sku, attributes_snapshot
    )
    select
      v_order_id,
      ci.product_id,
      ci.variant_id,
      ci.title_snapshot_en,
      ci.title_snapshot_ar,
      ci.image_path,
      ci.quantity,
      ci.unit_price_minor,
      ci.unit_price_minor * ci.quantity,
      coalesce(pv.sku, p.sku),
      jsonb_build_object(
        'product_status', p.status,
        'moderation_status', p.moderation_status,
        'store_id', p.store_id,
        'seller_id', p.seller_id,
        'return_days', coalesce(p.return_days, 14),
        'attributes', coalesce(p.attributes, '{}'::jsonb)
      )
    from public.cart_items ci
    join public.products p on p.id = ci.product_id
    left join public.product_variants pv on pv.id = ci.variant_id
    where ci.cart_id = v_cart.id
      and ci.store_id = store_rec.store_id
      and coalesce(ci.saved_for_later, false) = false;

    -- Attach reservation order_id for auditability
    update public.inventory_reservations ir
    set order_id = v_order_id
    where ir.status = 'active'
      and ir.order_id is null
      and ir.inventory_item_id in (
        select ii.id
        from public.inventory_items ii
        join public.cart_items ci on ci.product_id = ii.product_id
          and (ci.variant_id is not distinct from ii.variant_id)
        where ci.cart_id = v_cart.id
          and ci.store_id = store_rec.store_id
          and coalesce(ci.saved_for_later, false) = false
      );

    insert into public.order_addresses(
      order_id, full_name, phone, line1, line2, city, state, postal_code, country
    ) values (
      v_order_id,
      v_address.full_name,
      v_address.phone,
      v_address.line1,
      v_address.line2,
      v_address.city,
      v_address.state,
      v_address.postal_code,
      v_address.country
    );

    insert into public.order_status_events(order_id, status, note)
    values
      (v_order_id, 'paid', 'Payment confirmed'),
      (v_order_id, 'confirmed', 'Order confirmed');

    insert into public.commission_records(order_id, store_id, rate_percent, amount_minor)
    values (
      v_order_id,
      store_rec.store_id,
      8,
      floor(v_total * 0.08)::int
    );

    insert into public.shipments(order_id, status)
    values (v_order_id, 'pending');
  end loop;

  insert into public.payment_intents(
    order_group_id, amount_minor, currency, method, status, provider_ref, idempotency_key
  ) values (
    v_group_id,
    (select coalesce(sum(total_minor), 0) from public.orders where group_id = v_group_id),
    'USD',
    p_payment_method,
    'succeeded',
    'ref_' || p_idempotency_key,
    p_idempotency_key || ':payment'
  ) returning id into payment_id;

  insert into public.payment_transactions(payment_intent_id, status, raw_provider_payload)
  values (payment_id, 'succeeded', jsonb_build_object('method', p_payment_method, 'idempotency_key', p_idempotency_key));

  delete from public.cart_items
  where cart_id = v_cart.id
    and coalesce(saved_for_later, false) = false;

  update public.carts
  set coupon_code = null,
      updated_at = timezone('utc', now())
  where id = v_cart.id;

  return query select * from public.orders where group_id = v_group_id order by created_at;
exception
  when others then
    raise;
end;
$$;

-- Cancellation with reservation release (pre-fulfillment only)
create or replace function public.cancel_order_with_inventory(
  p_order_id uuid,
  p_actor uuid,
  p_reason text default null
) returns public.orders
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.orders;
  item_rec record;
begin
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'order not found'; end if;

  if o.buyer_id is distinct from p_actor
     and o.seller_id is distinct from p_actor
     and not public.is_admin() then
    raise exception 'forbidden';
  end if;

  if o.status = 'cancelled' then
    return o; -- idempotent
  end if;

  if o.status not in ('pending_payment','payment_processing','paid','confirmed','preparing','cancellation_requested') then
    raise exception 'order cannot be cancelled after fulfillment';
  end if;

  for item_rec in
    select * from public.order_items where order_id = p_order_id order by product_id, variant_id nulls first
  loop
    perform public.release_inventory_item(
      item_rec.product_id,
      item_rec.variant_id,
      item_rec.quantity,
      p_actor,
      coalesce(p_reason, 'order cancelled')
    );
  end loop;

  update public.orders
  set status = 'cancelled',
      updated_at = timezone('utc', now())
  where id = p_order_id
  returning * into o;

  insert into public.order_status_events(order_id, status, note)
  values (p_order_id, 'cancelled', coalesce(p_reason, 'cancelled'));

  update public.shipments set status = 'cancelled' where order_id = p_order_id and status = 'pending';

  return o;
end;
$$;

-- Fulfillment consumes reserved + on_hand once
create or replace function public.fulfill_order_items(
  p_order_id uuid,
  p_actor uuid,
  p_note text default null
) returns public.orders
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.orders;
  item_rec record;
begin
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'order not found'; end if;

  if o.seller_id is distinct from p_actor
     and not public.has_store_permission(o.store_id, 'orders.manage')
     and not public.is_admin() then
    raise exception 'forbidden';
  end if;

  if o.status not in ('paid','confirmed','preparing') then
    raise exception 'order not fulfillable from %', o.status;
  end if;

  for item_rec in
    select * from public.order_items where order_id = p_order_id order by product_id, variant_id nulls first
  loop
    perform public.fulfill_inventory_item(
      item_rec.product_id,
      item_rec.variant_id,
      item_rec.quantity,
      p_actor,
      coalesce(p_note, 'order fulfillment')
    );
  end loop;

  update public.orders
  set status = 'shipped',
      updated_at = timezone('utc', now()),
      tracking_number = coalesce(tracking_number, 'TRK' || substr(replace(gen_random_uuid()::text,'-',''),1,10))
  where id = p_order_id
  returning * into o;

  insert into public.order_status_events(order_id, status, note)
  values (p_order_id, 'shipped', coalesce(p_note, 'fulfilled/shipped'));

  update public.shipments
  set status = 'shipped',
      shipped_at = timezone('utc', now()),
      tracking_number = o.tracking_number
  where order_id = p_order_id;

  return o;
end;
$$;

revoke all on function public.lock_inventory_item(uuid, uuid) from public;
revoke all on function public.reserve_inventory_item(uuid, uuid, integer, uuid, text) from public;
revoke all on function public.release_inventory_item(uuid, uuid, integer, uuid, text) from public;
revoke all on function public.fulfill_inventory_item(uuid, uuid, integer, uuid, text) from public;
revoke all on function public.create_checkout_order_group(text, uuid, uuid, uuid, text, text) from public;
revoke all on function public.cancel_order_with_inventory(uuid, uuid, text) from public;
revoke all on function public.fulfill_order_items(uuid, uuid, text) from public;

grant execute on function public.reserve_inventory_item(uuid, uuid, integer, uuid, text) to authenticated;
grant execute on function public.release_inventory_item(uuid, uuid, integer, uuid, text) to authenticated;
grant execute on function public.fulfill_inventory_item(uuid, uuid, integer, uuid, text) to authenticated;
grant execute on function public.create_checkout_order_group(text, uuid, uuid, uuid, text, text) to authenticated;
grant execute on function public.cancel_order_with_inventory(uuid, uuid, text) to authenticated;
grant execute on function public.fulfill_order_items(uuid, uuid, text) to authenticated;
