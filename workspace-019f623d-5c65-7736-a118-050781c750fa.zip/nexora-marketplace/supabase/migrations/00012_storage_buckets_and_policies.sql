-- Storage buckets + object policies (Supabase Storage)

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values
  ('product-media', 'product-media', true, 10485760, array['image/jpeg','image/png','image/webp','image/gif','image/svg+xml']),
  ('store-branding', 'store-branding', true, 5242880, array['image/jpeg','image/png','image/webp','image/svg+xml']),
  ('user-avatars', 'user-avatars', true, 2097152, array['image/jpeg','image/png','image/webp']),
  ('seller-documents', 'seller-documents', false, 10485760, array['application/pdf','image/jpeg','image/png']),
  ('dispute-evidence', 'dispute-evidence', false, 15728640, array['application/pdf','image/jpeg','image/png','image/webp']),
  ('message-attachments', 'message-attachments', false, 10485760, array['application/pdf','image/jpeg','image/png','image/webp']),
  ('digital-goods', 'digital-goods', false, 52428800, array['application/zip','application/pdf','application/octet-stream']),
  ('review-media', 'review-media', true, 5242880, array['image/jpeg','image/png','image/webp']),
  ('support-attachments', 'support-attachments', false, 10485760, array['application/pdf','image/jpeg','image/png','image/webp'])
on conflict (id) do update
set public = excluded.public,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

-- Public read for public buckets
drop policy if exists product_media_public_read on storage.objects;
create policy product_media_public_read on storage.objects
  for select using (bucket_id in ('product-media','store-branding','user-avatars','review-media'));

-- Authenticated upload into own folder: {userId}/...
drop policy if exists storage_owner_insert on storage.objects;
create policy storage_owner_insert on storage.objects
  for insert to authenticated
  with check (
    bucket_id in ('product-media','store-branding','user-avatars','review-media','message-attachments','support-attachments','seller-documents','dispute-evidence','digital-goods')
    and auth.uid()::text = (storage.foldername(name))[1]
  );

drop policy if exists storage_owner_update on storage.objects;
create policy storage_owner_update on storage.objects
  for update to authenticated
  using (auth.uid()::text = (storage.foldername(name))[1])
  with check (auth.uid()::text = (storage.foldername(name))[1]);

drop policy if exists storage_owner_delete on storage.objects;
create policy storage_owner_delete on storage.objects
  for delete to authenticated
  using (auth.uid()::text = (storage.foldername(name))[1] or public.is_admin());

-- Private buckets: owner or admin/moderator
drop policy if exists private_bucket_read on storage.objects;
create policy private_bucket_read on storage.objects
  for select to authenticated
  using (
    bucket_id not in ('product-media','store-branding','user-avatars','review-media')
    and (
      auth.uid()::text = (storage.foldername(name))[1]
      or public.is_admin()
      or (bucket_id in ('seller-documents','dispute-evidence') and public.is_moderator())
    )
  );
