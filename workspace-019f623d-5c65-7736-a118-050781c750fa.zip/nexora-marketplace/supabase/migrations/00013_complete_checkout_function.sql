-- Fully atomic multi-store checkout workflow with inventory reservation,
-- snapshots, payment intent reference, and idempotency.

create or replace function public.create_checkout_order_group(
  p_cart_key text,
  p_buyer_id uuid,
  p_address_id uuid,
  p_shipping_method_id uuid,
  p_payment_method text,
  p_idempotency_key text
) returns setof public.orders
language plpgsql
security definer
set search_path = public
as $$
declare
  existing_group uuid;
  v_cart public.carts%rowtype;
  v_address public.addresses%rowtype;
  v_group_id uuid;
  store_rec record;
  v_order_id uuid;
  v_order_number text;
  v_subtotal integer;
  v_discount integer := 0;
  v_shipping integer := 0;
  v_tax integer := 0;
  v_total integer := 0;
  item_rec record;
  product_rec public.products%rowtype;
  variant_rec public.product_variants%rowtype;
  unit_price integer;
  available integer;
  shipping_rec public.shipping_methods%rowtype;
  promo_rec public.promotions%rowtype;
  payment_id uuid;
begin
  if auth.uid() is distinct from p_buyer_id and not public.is_admin() then
    raise exception 'forbidden';
  end if;

  -- Idempotency: return prior orders if key already used
  select id into existing_group
  from public.order_groups
  where idempotency_key = p_idempotency_key;

  if existing_group is not null then
    return query select * from public.orders where group_id = existing_group;
    return;
  end if;

  select * into v_cart
  from public.carts
  where (guest_key = p_cart_key)
     or (user_id = p_buyer_id and p_cart_key like 'user:%')
  order by updated_at desc
  limit 1
  for update;

  if not found then
    raise exception 'cart not found';
  end if;

  select * into v_address
  from public.addresses
  where id = p_address_id and user_id = p_buyer_id
  for update;

  if not found then
    raise exception 'address not found';
  end if;

  if not exists (
    select 1 from public.cart_items ci
    where ci.cart_id = v_cart.id and coalesce(ci.saved_for_later, false) = false
  ) then
    raise exception 'cart is empty';
  end if;

  select * into shipping_rec
  from public.shipping_methods
  where id = p_shipping_method_id
  limit 1;

  if not found then
    select * into shipping_rec from public.shipping_methods where enabled = true limit 1;
  end if;

  insert into public.order_groups(buyer_id, currency, idempotency_key)
  values (p_buyer_id, 'USD', p_idempotency_key)
  returning id into v_group_id;

  -- One seller order per store in the cart
  for store_rec in
    select distinct ci.store_id
    from public.cart_items ci
    where ci.cart_id = v_cart.id
      and coalesce(ci.saved_for_later, false) = false
  loop
    v_subtotal := 0;
    v_discount := 0;
    v_shipping := coalesce(shipping_rec.price_minor, 0);
    v_tax := 0;
    v_total := 0;

    -- Validate and reserve inventory for each item in this store
    for item_rec in
      select *
      from public.cart_items ci
      where ci.cart_id = v_cart.id
        and ci.store_id = store_rec.store_id
        and coalesce(ci.saved_for_later, false) = false
      for update
    loop
      select * into product_rec
      from public.products
      where id = item_rec.product_id
      for update;

      if not found or product_rec.status <> 'published' then
        raise exception 'product unavailable: %', item_rec.product_id;
      end if;

      if product_rec.seller_id = p_buyer_id then
        raise exception 'seller cannot purchase own product';
      end if;

      unit_price := product_rec.base_price_minor;
      available := product_rec.quantity - product_rec.reserved_quantity;

      if item_rec.variant_id is not null then
        select * into variant_rec
        from public.product_variants
        where id = item_rec.variant_id and product_id = product_rec.id
        for update;
        if not found or not variant_rec.enabled then
          raise exception 'variant unavailable: %', item_rec.variant_id;
        end if;
        unit_price := variant_rec.price_minor;
        available := variant_rec.quantity - variant_rec.reserved_quantity;
      end if;

      if unit_price <> item_rec.unit_price_minor then
        raise exception 'price changed for product %', product_rec.id;
      end if;

      if available < item_rec.quantity then
        raise exception 'insufficient stock for product %', product_rec.id;
      end if;

      -- Reserve inventory
      if item_rec.variant_id is not null then
        update public.product_variants
        set reserved_quantity = reserved_quantity + item_rec.quantity,
            quantity = quantity - item_rec.quantity
        where id = item_rec.variant_id;
      else
        update public.products
        set reserved_quantity = reserved_quantity + item_rec.quantity,
            quantity = quantity - item_rec.quantity
        where id = product_rec.id;
      end if;

      update public.inventory_items
      set reserved = reserved + item_rec.quantity,
          on_hand = greatest(0, on_hand - item_rec.quantity)
      where product_id = product_rec.id
        and (variant_id is not distinct from item_rec.variant_id);

      insert into public.inventory_movements(inventory_item_id, type, quantity_delta, note, created_by)
      select ii.id, 'sale', -item_rec.quantity, 'checkout reservation', p_buyer_id
      from public.inventory_items ii
      where ii.product_id = product_rec.id
        and (ii.variant_id is not distinct from item_rec.variant_id)
      limit 1;

      v_subtotal := v_subtotal + (unit_price * item_rec.quantity);
    end loop;

    if v_cart.coupon_code is not null then
      select * into promo_rec
      from public.promotions
      where code = v_cart.coupon_code and active = true
      limit 1;
      if found then
        if promo_rec.min_order_minor is null or v_subtotal >= promo_rec.min_order_minor then
          if promo_rec.type = 'percentage' then
            v_discount := floor(v_subtotal * promo_rec.value / 100.0)::int;
            if promo_rec.max_discount_minor is not null then
              v_discount := least(v_discount, promo_rec.max_discount_minor);
            end if;
          elsif promo_rec.type = 'fixed' then
            v_discount := least(v_subtotal, floor(promo_rec.value * 100)::int);
          elsif promo_rec.type = 'free_shipping' then
            v_shipping := 0;
          end if;
          update public.promotions set usage_count = usage_count + 1 where id = promo_rec.id;
          insert into public.coupon_redemptions(promotion_id, user_id)
          values (promo_rec.id, p_buyer_id);
        end if;
      end if;
    end if;

    if shipping_rec.free_above_minor is not null and v_subtotal >= shipping_rec.free_above_minor then
      v_shipping := 0;
    end if;

    -- If all items digital/service (no shipping required), zero shipping
    if not exists (
      select 1
      from public.cart_items ci
      join public.products p on p.id = ci.product_id
      where ci.cart_id = v_cart.id
        and ci.store_id = store_rec.store_id
        and coalesce(ci.saved_for_later, false) = false
        and p.requires_shipping = true
    ) then
      v_shipping := 0;
    end if;

    v_tax := floor((v_subtotal - v_discount + v_shipping) * 0.08)::int;
    v_total := greatest(0, v_subtotal - v_discount + v_shipping + v_tax);
    v_order_number := 'NXR-' || to_char(timezone('utc', now()), 'YYMMDDHH24MISS') || '-' || substr(replace(gen_random_uuid()::text, '-', ''), 1, 6);

    insert into public.orders(
      order_number, group_id, buyer_id, store_id, seller_id,
      status, payment_status,
      subtotal_minor, discount_minor, shipping_minor, tax_minor, fees_minor, total_minor,
      currency, shipping_method, coupon_code
    )
    select
      v_order_number,
      v_group_id,
      p_buyer_id,
      store_rec.store_id,
      s.owner_id,
      'paid',
      'paid',
      v_subtotal,
      v_discount,
      v_shipping,
      v_tax,
      0,
      v_total,
      'USD',
      coalesce(shipping_rec.name_en, 'Standard'),
      v_cart.coupon_code
    from public.stores s
    where s.id = store_rec.store_id
    returning id into v_order_id;

    -- Immutable snapshots: order items
    insert into public.order_items(
      order_id, product_id, variant_id, title_en, title_ar, image_path,
      quantity, unit_price_minor, total_minor, sku, attributes_snapshot
    )
    select
      v_order_id,
      ci.product_id,
      ci.variant_id,
      ci.title_snapshot_en,
      ci.title_snapshot_ar,
      ci.image_path,
      ci.quantity,
      ci.unit_price_minor,
      ci.unit_price_minor * ci.quantity,
      coalesce(pv.sku, p.sku),
      coalesce(p.attributes, '{}'::jsonb)
    from public.cart_items ci
    join public.products p on p.id = ci.product_id
    left join public.product_variants pv on pv.id = ci.variant_id
    where ci.cart_id = v_cart.id
      and ci.store_id = store_rec.store_id
      and coalesce(ci.saved_for_later, false) = false;

    -- Address snapshot
    insert into public.order_addresses(
      order_id, full_name, phone, line1, line2, city, state, postal_code, country
    ) values (
      v_order_id,
      v_address.full_name,
      v_address.phone,
      v_address.line1,
      v_address.line2,
      v_address.city,
      v_address.state,
      v_address.postal_code,
      v_address.country
    );

    insert into public.order_status_events(order_id, status, note)
    values
      (v_order_id, 'paid', 'Payment confirmed'),
      (v_order_id, 'confirmed', 'Order confirmed');

    -- Commission snapshot
    insert into public.commission_records(order_id, store_id, rate_percent, amount_minor)
    values (
      v_order_id,
      store_rec.store_id,
      coalesce((select commission_percent from public.categories c join public.products p on p.category_id = c.id where p.store_id = store_rec.store_id limit 1), 8),
      floor(v_total * 0.08)::int
    );

    if shipping_rec.id is not null and v_shipping >= 0 then
      insert into public.shipments(order_id, status)
      values (v_order_id, 'pending');
    end if;
  end loop;

  insert into public.payment_intents(
    order_group_id, amount_minor, currency, method, status, provider_ref, idempotency_key
  ) values (
    v_group_id,
    (select coalesce(sum(total_minor), 0) from public.orders where group_id = v_group_id),
    'USD',
    p_payment_method,
    'succeeded',
    'mock_' || p_idempotency_key,
    p_idempotency_key || ':payment'
  ) returning id into payment_id;

  insert into public.payment_transactions(payment_intent_id, status, raw_provider_payload)
  values (payment_id, 'succeeded', jsonb_build_object('method', p_payment_method));

  -- Clear purchased cart items
  delete from public.cart_items
  where cart_id = v_cart.id
    and coalesce(saved_for_later, false) = false;

  update public.carts
  set coupon_code = null,
      updated_at = timezone('utc', now())
  where id = v_cart.id;

  return query select * from public.orders where group_id = v_group_id;
exception
  when others then
    -- Full transaction rollback is automatic for the function body.
    raise;
end;
$$;

revoke all on function public.create_checkout_order_group(text, uuid, uuid, uuid, text, text) from public;
grant execute on function public.create_checkout_order_group(text, uuid, uuid, uuid, text, text) to authenticated;
