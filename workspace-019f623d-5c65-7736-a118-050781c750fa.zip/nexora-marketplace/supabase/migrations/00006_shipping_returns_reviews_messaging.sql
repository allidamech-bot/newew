create table if not exists public.shipping_methods (
  id uuid primary key default gen_random_uuid(),
  store_id uuid references public.stores(id) on delete cascade,
  name_en text not null,
  name_ar text not null,
  description_en text not null default '',
  description_ar text not null default '',
  price_minor integer not null default 0 check (price_minor >= 0),
  free_above_minor integer,
  min_days integer not null default 0,
  max_days integer not null default 0,
  enabled boolean not null default true,
  type text not null
);

create table if not exists public.shipments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  carrier text,
  tracking_number text,
  tracking_url text,
  status text not null default 'pending',
  shipped_at timestamptz,
  estimated_delivery date,
  delivered_at timestamptz
);

create table if not exists public.shipment_events (
  id uuid primary key default gen_random_uuid(),
  shipment_id uuid not null references public.shipments(id) on delete cascade,
  status text not null,
  description text,
  occurred_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.return_requests (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  buyer_id uuid not null references public.profiles(id),
  store_id uuid not null references public.stores(id),
  status text not null,
  reason text not null,
  notes text,
  evidence_paths text[] not null default '{}',
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.return_items (
  return_id uuid not null references public.return_requests(id) on delete cascade,
  order_item_id uuid not null references public.order_items(id),
  quantity integer not null check (quantity > 0),
  primary key (return_id, order_item_id)
);

create table if not exists public.return_events (
  id uuid primary key default gen_random_uuid(),
  return_id uuid not null references public.return_requests(id) on delete cascade,
  status text not null,
  note text,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.disputes (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  return_id uuid references public.return_requests(id),
  buyer_id uuid not null references public.profiles(id),
  seller_id uuid not null references public.profiles(id),
  store_id uuid not null references public.stores(id),
  status text not null,
  reason text not null,
  resolution text,
  evidence_paths text[] not null default '{}',
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.dispute_events (
  id uuid primary key default gen_random_uuid(),
  dispute_id uuid not null references public.disputes(id) on delete cascade,
  status text not null,
  note text,
  by_user uuid references public.profiles(id),
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  store_id uuid not null references public.stores(id),
  order_id uuid not null references public.orders(id),
  order_item_id uuid not null references public.order_items(id),
  buyer_id uuid not null references public.profiles(id),
  product_rating integer not null check (product_rating between 1 and 5),
  store_rating integer not null check (store_rating between 1 and 5),
  delivery_rating integer not null check (delivery_rating between 1 and 5),
  communication_rating integer not null check (communication_rating between 1 and 5),
  title_en text not null,
  title_ar text not null,
  body_en text not null,
  body_ar text not null,
  verified_purchase boolean not null default true,
  helpful_count integer not null default 0,
  moderation_status text not null default 'pending',
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  unique (order_item_id)
);

create table if not exists public.review_responses (
  review_id uuid primary key references public.reviews(id) on delete cascade,
  body_en text not null,
  body_ar text not null,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  type text not null,
  store_id uuid references public.stores(id),
  product_id uuid references public.products(id),
  order_id uuid references public.orders(id),
  subject text not null,
  status text not null default 'open',
  last_message_at timestamptz not null default timezone('utc', now()),
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.conversation_participants (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  unread_count integer not null default 0,
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id),
  body text not null,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.message_reads (
  message_id uuid not null references public.messages(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  read_at timestamptz not null default timezone('utc', now()),
  primary key (message_id, user_id)
);

create table if not exists public.offers (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id),
  variant_id uuid references public.product_variants(id),
  store_id uuid not null references public.stores(id),
  buyer_id uuid not null references public.profiles(id),
  seller_id uuid not null references public.profiles(id),
  quantity integer not null check (quantity > 0),
  offered_price_minor integer not null check (offered_price_minor >= 0),
  currency text not null default 'USD',
  status text not null,
  message text,
  expires_at timestamptz not null,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  category text not null,
  title_en text not null,
  title_ar text not null,
  body_en text not null,
  body_ar text not null,
  href text,
  read boolean not null default false,
  created_at timestamptz not null default timezone('utc', now())
);

create index if not exists idx_messages_conversation_created
  on public.messages(conversation_id, created_at);
create index if not exists idx_notifications_user_read
  on public.notifications(user_id, read, created_at desc);
create index if not exists idx_reviews_product on public.reviews(product_id);
