create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid references public.categories(id) on delete set null,
  slug text not null unique,
  sort_order integer not null default 0,
  featured boolean not null default false,
  visible boolean not null default true,
  product_types text[] not null default array['physical']::text[],
  commission_percent numeric(5,2),
  image_path text,
  icon text,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.category_translations (
  category_id uuid not null references public.categories(id) on delete cascade,
  locale text not null check (locale in ('en', 'ar')),
  name text not null,
  description text not null default '',
  seo_title text,
  seo_description text,
  primary key (category_id, locale)
);

create table if not exists public.attribute_definitions (
  id uuid primary key default gen_random_uuid(),
  key text not null unique,
  type text not null,
  unit text,
  required boolean not null default false,
  filterable boolean not null default false,
  searchable boolean not null default false,
  variant_axis boolean not null default false,
  sort_order integer not null default 0,
  name_en text not null,
  name_ar text not null
);

create table if not exists public.attribute_options (
  id uuid primary key default gen_random_uuid(),
  attribute_id uuid not null references public.attribute_definitions(id) on delete cascade,
  value text not null,
  color_hex text,
  sort_order integer not null default 0,
  unique (attribute_id, value)
);

create table if not exists public.attribute_option_translations (
  option_id uuid not null references public.attribute_options(id) on delete cascade,
  locale text not null,
  label text not null,
  primary key (option_id, locale)
);

create table if not exists public.category_attributes (
  category_id uuid not null references public.categories(id) on delete cascade,
  attribute_id uuid not null references public.attribute_definitions(id) on delete cascade,
  sort_order integer not null default 0,
  required_override boolean,
  primary key (category_id, attribute_id)
);

create table if not exists public.brands (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  logo_path text
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  seller_id uuid not null references public.profiles(id),
  category_id uuid not null references public.categories(id),
  brand_id uuid references public.brands(id),
  type text not null,
  slug text not null,
  status text not null default 'draft',
  moderation_status text not null default 'pending',
  visibility text not null default 'public',
  condition text not null default 'new',
  base_price_minor integer not null check (base_price_minor >= 0),
  compare_at_price_minor integer check (compare_at_price_minor is null or compare_at_price_minor >= 0),
  currency text not null default 'USD',
  sku text,
  quantity integer not null default 0 check (quantity >= 0),
  reserved_quantity integer not null default 0 check (reserved_quantity >= 0),
  low_stock_threshold integer not null default 5,
  inventory_policy text not null default 'deny',
  requires_shipping boolean not null default true,
  weight_grams integer,
  tags text[] not null default '{}',
  attributes jsonb not null default '{}'::jsonb,
  rating numeric(3,2) not null default 0,
  review_count integer not null default 0,
  sales_count integer not null default 0,
  featured boolean not null default false,
  offers_enabled boolean not null default false,
  processing_days integer not null default 2,
  return_days integer not null default 14,
  warranty_months integer,
  digital_file_path text,
  service_duration_minutes integer,
  published_at timestamptz,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  unique (store_id, slug),
  check (reserved_quantity <= quantity)
);

create table if not exists public.product_translations (
  product_id uuid not null references public.products(id) on delete cascade,
  locale text not null,
  title text not null,
  description text not null default '',
  short_description text not null default '',
  seo_title text,
  seo_description text,
  primary key (product_id, locale)
);

create table if not exists public.product_media (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  bucket text not null,
  path text not null,
  alt_en text,
  alt_ar text,
  width integer,
  height integer,
  mime_type text,
  size_bytes integer,
  is_cover boolean not null default false,
  sort_order integer not null default 0,
  moderation_status text not null default 'pending'
);

create table if not exists public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  sku text not null,
  title_en text not null,
  title_ar text not null,
  options jsonb not null default '{}'::jsonb,
  price_minor integer not null check (price_minor >= 0),
  compare_at_price_minor integer,
  quantity integer not null default 0 check (quantity >= 0),
  reserved_quantity integer not null default 0 check (reserved_quantity >= 0),
  low_stock_threshold integer not null default 5,
  enabled boolean not null default true,
  unique (product_id, sku),
  check (reserved_quantity <= quantity)
);

create table if not exists public.product_relations (
  product_id uuid not null references public.products(id) on delete cascade,
  related_product_id uuid not null references public.products(id) on delete cascade,
  relation_type text not null default 'related',
  primary key (product_id, related_product_id, relation_type)
);

create table if not exists public.product_status_events (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  status text not null,
  note text,
  actor_id uuid references public.profiles(id),
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.product_moderation_events (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  moderation_status text not null,
  note text,
  actor_id uuid references public.profiles(id),
  created_at timestamptz not null default timezone('utc', now())
);

create index if not exists idx_products_store on public.products(store_id);
create index if not exists idx_products_category on public.products(category_id);
create index if not exists idx_products_status on public.products(status);
create index if not exists idx_products_price on public.products(base_price_minor);
create index if not exists idx_products_published on public.products(published_at desc);
create index if not exists idx_product_variants_product on public.product_variants(product_id);
