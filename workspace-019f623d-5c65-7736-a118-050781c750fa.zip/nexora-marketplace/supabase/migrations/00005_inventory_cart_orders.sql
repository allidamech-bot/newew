create table if not exists public.warehouses (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  name text not null,
  location text,
  is_default boolean not null default false
);

create table if not exists public.inventory_items (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  variant_id uuid references public.product_variants(id) on delete cascade,
  warehouse_id uuid not null references public.warehouses(id) on delete cascade,
  on_hand integer not null default 0 check (on_hand >= 0),
  reserved integer not null default 0 check (reserved >= 0),
  incoming integer not null default 0 check (incoming >= 0),
  low_stock_threshold integer not null default 5,
  unique (product_id, variant_id, warehouse_id),
  check (reserved <= on_hand)
);

create table if not exists public.inventory_reservations (
  id uuid primary key default gen_random_uuid(),
  inventory_item_id uuid not null references public.inventory_items(id) on delete cascade,
  order_id uuid,
  quantity integer not null check (quantity > 0),
  status text not null default 'active',
  created_at timestamptz not null default timezone('utc', now()),
  released_at timestamptz
);

create table if not exists public.inventory_movements (
  id uuid primary key default gen_random_uuid(),
  inventory_item_id uuid not null references public.inventory_items(id) on delete cascade,
  type text not null,
  quantity_delta integer not null,
  note text,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.carts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  guest_key text,
  coupon_code text,
  updated_at timestamptz not null default timezone('utc', now()),
  created_at timestamptz not null default timezone('utc', now())
);

create unique index if not exists idx_carts_user_unique
  on public.carts(user_id)
  where user_id is not null;

create table if not exists public.cart_items (
  id uuid primary key default gen_random_uuid(),
  cart_id uuid not null references public.carts(id) on delete cascade,
  product_id uuid not null references public.products(id),
  variant_id uuid references public.product_variants(id),
  store_id uuid not null references public.stores(id),
  quantity integer not null check (quantity > 0),
  unit_price_minor integer not null check (unit_price_minor >= 0),
  currency text not null default 'USD',
  title_snapshot_en text not null,
  title_snapshot_ar text not null,
  image_path text,
  saved_for_later boolean not null default false,
  notes text
);

create table if not exists public.wishlists (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  is_default boolean not null default false,
  is_private boolean not null default true,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.wishlist_items (
  id uuid primary key default gen_random_uuid(),
  wishlist_id uuid not null references public.wishlists(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  variant_id uuid references public.product_variants(id),
  note text,
  created_at timestamptz not null default timezone('utc', now()),
  unique (wishlist_id, product_id, variant_id)
);

create table if not exists public.saved_searches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  query text not null default '',
  filters jsonb not null default '{}'::jsonb,
  sort text not null default 'relevance',
  notify boolean not null default false,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.promotions (
  id uuid primary key default gen_random_uuid(),
  store_id uuid references public.stores(id) on delete cascade,
  platform_wide boolean not null default false,
  name_en text not null,
  name_ar text not null,
  type text not null,
  value numeric(12,2) not null,
  max_discount_minor integer,
  min_order_minor integer,
  code text unique,
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  usage_limit integer,
  per_user_limit integer,
  usage_count integer not null default 0,
  first_order_only boolean not null default false,
  stackable boolean not null default false,
  active boolean not null default true,
  check (ends_at > starts_at)
);

create table if not exists public.coupon_redemptions (
  id uuid primary key default gen_random_uuid(),
  promotion_id uuid not null references public.promotions(id),
  user_id uuid not null references public.profiles(id),
  order_id uuid,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.order_groups (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references public.profiles(id),
  currency text not null default 'USD',
  idempotency_key text not null unique,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  group_id uuid not null references public.order_groups(id) on delete cascade,
  buyer_id uuid not null references public.profiles(id),
  store_id uuid not null references public.stores(id),
  seller_id uuid not null references public.profiles(id),
  status text not null,
  payment_status text not null,
  subtotal_minor integer not null check (subtotal_minor >= 0),
  discount_minor integer not null default 0 check (discount_minor >= 0),
  shipping_minor integer not null default 0 check (shipping_minor >= 0),
  tax_minor integer not null default 0 check (tax_minor >= 0),
  fees_minor integer not null default 0 check (fees_minor >= 0),
  total_minor integer not null check (total_minor >= 0),
  currency text not null default 'USD',
  shipping_method text,
  tracking_number text,
  tracking_url text,
  coupon_code text,
  notes text,
  delivered_at timestamptz,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null,
  variant_id uuid,
  title_en text not null,
  title_ar text not null,
  image_path text,
  quantity integer not null check (quantity > 0),
  unit_price_minor integer not null check (unit_price_minor >= 0),
  total_minor integer not null check (total_minor >= 0),
  sku text,
  attributes_snapshot jsonb not null default '{}'::jsonb
);

create table if not exists public.order_addresses (
  order_id uuid primary key references public.orders(id) on delete cascade,
  full_name text not null,
  phone text not null,
  line1 text not null,
  line2 text,
  city text not null,
  state text,
  postal_code text not null,
  country text not null
);

create table if not exists public.order_status_events (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  status text not null,
  note text,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.payment_intents (
  id uuid primary key default gen_random_uuid(),
  order_group_id uuid references public.order_groups(id),
  amount_minor integer not null check (amount_minor >= 0),
  currency text not null,
  method text not null,
  status text not null,
  provider_ref text,
  idempotency_key text not null unique,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.payment_transactions (
  id uuid primary key default gen_random_uuid(),
  payment_intent_id uuid not null references public.payment_intents(id),
  status text not null,
  raw_provider_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default timezone('utc', now())
);

create table if not exists public.commission_records (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  store_id uuid not null references public.stores(id),
  rate_percent numeric(5,2) not null,
  amount_minor integer not null check (amount_minor >= 0),
  created_at timestamptz not null default timezone('utc', now())
);

create index if not exists idx_orders_buyer on public.orders(buyer_id);
create index if not exists idx_orders_store on public.orders(store_id);
create index if not exists idx_orders_status on public.orders(status);
create index if not exists idx_inventory_product on public.inventory_items(product_id, variant_id);
