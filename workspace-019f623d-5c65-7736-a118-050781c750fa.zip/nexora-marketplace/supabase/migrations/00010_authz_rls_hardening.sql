-- Correct role helpers and broaden RLS coverage.
-- moderator is NOT admin.

create or replace function public.is_moderator()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.has_platform_role('moderator');
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.has_platform_role('admin')
      or public.has_platform_role('super_admin');
$$;

create or replace function public.is_super_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.has_platform_role('super_admin');
$$;

-- Owner only (members must use has_store_permission)
create or replace function public.owns_store(store uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.stores s
    where s.id = store and s.owner_id = auth.uid()
  );
$$;

create or replace function public.has_store_permission(store uuid, permission_key text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.owns_store(store)
      or public.is_admin()
      or exists (
        select 1
        from public.store_members sm
        join public.store_member_roles smr on smr.member_id = sm.id
        join public.role_permissions rp on rp.role_id = smr.role_id
        join public.permissions p on p.id = rp.permission_id
        where sm.store_id = store
          and sm.user_id = auth.uid()
          and sm.status = 'active'
          and p.key = permission_key
      );
$$;

-- Enable RLS on remaining public tables
do $$
declare
  t text;
begin
  foreach t in array array[
    'roles','permissions','role_permissions','user_roles','user_preferences','notification_preferences',
    'account_deletion_requests','data_export_requests','seller_profiles','seller_application_events',
    'store_members','store_member_roles','store_follows','store_policies','store_settings','store_social_links',
    'store_collections','store_collection_items','store_announcements','category_attributes','attribute_definitions',
    'attribute_options','attribute_option_translations','brands','product_relations','product_status_events',
    'product_moderation_events','warehouses','inventory_reservations','inventory_movements','saved_searches',
    'promotions','coupon_redemptions','order_groups','order_addresses','order_status_events','payment_intents',
    'payment_transactions','commission_records','shipping_methods','shipments','shipment_events','return_items',
    'return_events','dispute_events','review_responses','offers','support_messages','help_categories',
    'moderation_actions','cms_pages','security_events','analytics_events','daily_platform_metrics','daily_store_metrics'
  ]
  loop
    execute format('alter table if exists public.%I enable row level security', t);
  end loop;
end $$;

-- Brands / attributes public read
drop policy if exists brands_public_read on public.brands;
create policy brands_public_read on public.brands for select using (true);

drop policy if exists attribute_definitions_public_read on public.attribute_definitions;
create policy attribute_definitions_public_read on public.attribute_definitions for select using (true);

drop policy if exists attribute_options_public_read on public.attribute_options;
create policy attribute_options_public_read on public.attribute_options for select using (true);

-- Shipping methods public/authenticated read
drop policy if exists shipping_methods_read on public.shipping_methods;
create policy shipping_methods_read on public.shipping_methods
  for select using (enabled = true or public.is_admin() or public.owns_store(store_id));

-- Promotions
drop policy if exists promotions_read on public.promotions;
create policy promotions_read on public.promotions
  for select using (active = true or public.is_admin() or public.owns_store(store_id));

drop policy if exists promotions_store_write on public.promotions;
create policy promotions_store_write on public.promotions
  for all using (public.has_store_permission(store_id, 'promotions.manage') or public.is_admin())
  with check (public.has_store_permission(store_id, 'promotions.manage') or public.is_admin());

-- Inventory movements / reservations
drop policy if exists inventory_movements_store on public.inventory_movements;
create policy inventory_movements_store on public.inventory_movements
  for select using (
    public.is_admin()
    or exists (
      select 1 from public.inventory_items ii
      where ii.id = inventory_item_id
        and public.has_store_permission(ii.store_id, 'inventory.manage')
    )
  );

drop policy if exists warehouses_store on public.warehouses;
create policy warehouses_store on public.warehouses
  for all using (public.has_store_permission(store_id, 'inventory.manage') or public.is_admin())
  with check (public.has_store_permission(store_id, 'inventory.manage') or public.is_admin());

-- Order child tables
drop policy if exists order_status_events_access on public.order_status_events;
create policy order_status_events_access on public.order_status_events
  for select using (public.can_access_order(order_id));

drop policy if exists order_addresses_access on public.order_addresses;
create policy order_addresses_access on public.order_addresses
  for select using (public.can_access_order(order_id));

drop policy if exists payment_intents_access on public.payment_intents;
create policy payment_intents_access on public.payment_intents
  for select using (
    public.is_admin()
    or exists (
      select 1 from public.order_groups og
      where og.id = order_group_id and og.buyer_id = auth.uid()
    )
  );

drop policy if exists commission_records_store_admin on public.commission_records;
create policy commission_records_store_admin on public.commission_records
  for select using (public.is_admin() or public.has_store_permission(store_id, 'analytics.read'));

-- Reviews responses
drop policy if exists review_responses_read on public.review_responses;
create policy review_responses_read on public.review_responses for select using (true);

drop policy if exists review_responses_seller_write on public.review_responses;
create policy review_responses_seller_write on public.review_responses
  for all using (
    public.is_admin()
    or exists (
      select 1 from public.reviews r
      where r.id = review_id and public.has_store_permission(r.store_id, 'reviews.respond')
    )
  )
  with check (
    public.is_admin()
    or exists (
      select 1 from public.reviews r
      where r.id = review_id and public.has_store_permission(r.store_id, 'reviews.respond')
    )
  );

-- Moderator can read reports/moderation queues but not platform settings
drop policy if exists reports_moderator_read on public.reports;
create policy reports_moderator_read on public.reports
  for select using (public.is_moderator() or public.is_admin() or reporter_id = auth.uid());

drop policy if exists moderation_actions_staff on public.moderation_actions;
create policy moderation_actions_staff on public.moderation_actions
  for select using (public.is_moderator() or public.is_admin());

-- Analytics/security restricted
drop policy if exists analytics_events_admin on public.analytics_events;
create policy analytics_events_admin on public.analytics_events
  for select using (public.is_admin());

drop policy if exists security_events_admin on public.security_events;
create policy security_events_admin on public.security_events
  for select using (public.is_admin() or public.is_super_admin());

drop policy if exists platform_settings_admin_only on public.platform_settings;
drop policy if exists platform_settings_admin on public.platform_settings;
create policy platform_settings_admin on public.platform_settings
  for all using (public.is_admin())
  with check (public.is_admin());

-- Store members
drop policy if exists store_members_access on public.store_members;
create policy store_members_access on public.store_members
  for select using (
    user_id = auth.uid()
    or public.owns_store(store_id)
    or public.is_admin()
  );

-- Saved searches
drop policy if exists saved_searches_self on public.saved_searches;
create policy saved_searches_self on public.saved_searches
  for all using (user_id = auth.uid() or public.is_admin())
  with check (user_id = auth.uid());

-- Offers
drop policy if exists offers_parties on public.offers;
create policy offers_parties on public.offers
  for select using (buyer_id = auth.uid() or seller_id = auth.uid() or public.is_admin());

-- Help categories public
drop policy if exists help_categories_public on public.help_categories;
create policy help_categories_public on public.help_categories for select using (true);

-- Support messages via ticket ownership
drop policy if exists support_messages_access on public.support_messages;
create policy support_messages_access on public.support_messages
  for select using (
    public.is_admin()
    or exists (
      select 1 from public.support_tickets st
      where st.id = ticket_id and st.user_id = auth.uid()
    )
  );
