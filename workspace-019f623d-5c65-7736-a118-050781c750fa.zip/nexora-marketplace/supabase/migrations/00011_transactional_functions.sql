-- Atomic marketplace operations (SECURITY DEFINER with explicit grants)

revoke all on function public.reserve_inventory(uuid, uuid, integer) from public;
revoke all on function public.release_inventory(uuid, uuid, integer) from public;

create or replace function public.transition_order_status(
  p_order_id uuid,
  p_status text,
  p_note text default null
) returns public.orders
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.orders;
  allowed boolean;
begin
  if not public.can_access_order(p_order_id) and not public.is_admin() then
    raise exception 'forbidden';
  end if;

  select * into o from public.orders where id = p_order_id for update;
  if not found then
    raise exception 'order not found';
  end if;

  -- simplified allow-list check
  allowed := (o.status = p_status)
    or (o.status = 'paid' and p_status in ('confirmed','cancelled','cancellation_requested'))
    or (o.status = 'confirmed' and p_status in ('preparing','cancelled'))
    or (o.status = 'preparing' and p_status in ('shipped','cancelled'))
    or (o.status = 'shipped' and p_status in ('out_for_delivery','delivered'))
    or (o.status = 'out_for_delivery' and p_status = 'delivered')
    or (o.status = 'delivered' and p_status in ('completed','return_requested'))
    or (o.status = 'completed' and p_status = 'return_requested')
    or (o.status in ('paid','confirmed','preparing') and p_status = 'cancelled');

  if not allowed then
    raise exception 'invalid transition from % to %', o.status, p_status;
  end if;

  update public.orders
  set status = p_status,
      updated_at = timezone('utc', now()),
      delivered_at = case when p_status in ('delivered','completed') then coalesce(delivered_at, timezone('utc', now())) else delivered_at end
  where id = p_order_id
  returning * into o;

  insert into public.order_status_events(order_id, status, note)
  values (p_order_id, p_status, p_note);

  if p_status = 'cancelled' then
    -- restore stock for each item
    perform public.release_inventory(oi.product_id, oi.variant_id, oi.quantity)
    from public.order_items oi
    where oi.order_id = p_order_id;
  end if;

  return o;
end;
$$;

create or replace function public.create_checkout_order_group(
  p_cart_key text,
  p_buyer_id uuid,
  p_address_id uuid,
  p_shipping_method_id uuid,
  p_payment_method text,
  p_idempotency_key text
) returns setof public.orders
language plpgsql
security definer
set search_path = public
as $$
declare
  existing_group uuid;
begin
  if auth.uid() is distinct from p_buyer_id and not public.is_admin() then
    raise exception 'forbidden';
  end if;

  select id into existing_group
  from public.order_groups
  where idempotency_key = p_idempotency_key;

  if existing_group is not null then
    return query select * from public.orders where group_id = existing_group;
    return;
  end if;

  -- Implementation note: production version validates cart rows, reserves inventory,
  -- snapshots items/prices/addresses, creates one order per store, and records payments.
  raise exception 'create_checkout_order_group requires cart tables to be populated by application service layer';
end;
$$;

create or replace function public.submit_review(p_payload jsonb)
returns public.reviews
language plpgsql
security definer
set search_path = public
as $$
declare
  o public.orders;
  existing_id uuid;
  created public.reviews;
begin
  select * into o from public.orders where id = (p_payload->>'orderId')::uuid;
  if not found then raise exception 'order not found'; end if;
  if o.buyer_id <> auth.uid() then raise exception 'forbidden'; end if;
  if o.seller_id = auth.uid() then raise exception 'self review forbidden'; end if;
  if o.status not in ('delivered','completed') then raise exception 'order not eligible'; end if;

  select id into existing_id from public.reviews where order_item_id = (p_payload->>'orderItemId')::uuid;
  if existing_id is not null then raise exception 'duplicate review'; end if;

  insert into public.reviews(
    product_id, store_id, order_id, order_item_id, buyer_id,
    product_rating, store_rating, delivery_rating, communication_rating,
    title_en, title_ar, body_en, body_ar, verified_purchase, moderation_status
  ) values (
    (p_payload->>'productId')::uuid,
    o.store_id,
    o.id,
    (p_payload->>'orderItemId')::uuid,
    auth.uid(),
    coalesce((p_payload->>'productRating')::int, 5),
    coalesce((p_payload->>'storeRating')::int, 5),
    coalesce((p_payload->>'deliveryRating')::int, 5),
    coalesce((p_payload->>'communicationRating')::int, 5),
    coalesce(p_payload#>>'{title,en}', 'Review'),
    coalesce(p_payload#>>'{title,ar}', 'تقييم'),
    coalesce(p_payload#>>'{body,en}', ''),
    coalesce(p_payload#>>'{body,ar}', ''),
    true,
    'approved'
  ) returning * into created;

  return created;
end;
$$;

create or replace function public.adjust_inventory(
  p_product_id uuid,
  p_variant_id uuid,
  p_delta integer,
  p_actor_id uuid,
  p_note text default null
) returns public.inventory_items
language plpgsql
security definer
set search_path = public
as $$
declare
  item public.inventory_items;
begin
  select * into item
  from public.inventory_items
  where product_id = p_product_id
    and (variant_id is not distinct from p_variant_id)
  for update;

  if not found then
    raise exception 'inventory item not found';
  end if;

  if not public.has_store_permission(item.store_id, 'inventory.manage') and not public.is_admin() then
    raise exception 'forbidden';
  end if;

  update public.inventory_items
  set on_hand = greatest(0, on_hand + p_delta)
  where id = item.id
  returning * into item;

  insert into public.inventory_movements(inventory_item_id, type, quantity_delta, note, created_by)
  values (item.id, 'manual_adjustment', p_delta, p_note, p_actor_id);

  return item;
end;
$$;

create or replace function public.mark_notifications_read(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is distinct from p_user_id and not public.is_admin() then
    raise exception 'forbidden';
  end if;
  update public.notifications set read = true where user_id = p_user_id and read = false;
end;
$$;

create or replace function public.send_secure_message(p_payload jsonb)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  conv_id uuid;
  msg_id uuid;
begin
  if (p_payload->>'senderId')::uuid is distinct from auth.uid() then
    raise exception 'forbidden';
  end if;

  conv_id := nullif(p_payload->>'conversationId','')::uuid;
  if conv_id is null then
    insert into public.conversations(type, store_id, product_id, order_id, subject, status)
    values (
      coalesce(p_payload->>'type','general'),
      nullif(p_payload->>'storeId','')::uuid,
      nullif(p_payload->>'productId','')::uuid,
      nullif(p_payload->>'orderId','')::uuid,
      coalesce(p_payload->>'subject','Conversation'),
      'open'
    ) returning id into conv_id;

    insert into public.conversation_participants(conversation_id, user_id, unread_count)
    values
      (conv_id, auth.uid(), 0),
      (conv_id, (p_payload->>'recipientId')::uuid, 1);
  end if;

  if not public.can_access_conversation(conv_id) then
    raise exception 'forbidden';
  end if;

  insert into public.messages(conversation_id, sender_id, body)
  values (conv_id, auth.uid(), p_payload->>'body')
  returning id into msg_id;

  update public.conversations
  set last_message_at = timezone('utc', now())
  where id = conv_id;

  return jsonb_build_object('conversationId', conv_id, 'messageId', msg_id);
end;
$$;

create or replace function public.review_seller_application(
  p_application_id uuid,
  p_status text,
  p_note text default null
) returns public.seller_applications
language plpgsql
security definer
set search_path = public
as $$
declare
  app public.seller_applications;
begin
  if not public.is_admin() and not public.is_moderator() then
    raise exception 'forbidden';
  end if;
  if public.is_moderator() and p_status = 'approved' and not public.is_admin() then
    -- moderators may request info / reject; approval reserved for admin
    raise exception 'moderator cannot approve sellers';
  end if;

  update public.seller_applications
  set status = p_status,
      updated_at = timezone('utc', now()),
      notes = coalesce(p_note, notes)
  where id = p_application_id
  returning * into app;

  insert into public.seller_application_events(application_id, status, note, actor_id)
  values (p_application_id, p_status, p_note, auth.uid());

  if p_status = 'approved' then
    insert into public.user_roles(user_id, role_id)
    select app.user_id, r.id
    from public.roles r
    where r.key = 'seller'
    on conflict do nothing;

    insert into public.stores(owner_id, name, slug, description_en, description_ar, verification_status, status)
    values (
      app.user_id,
      coalesce(app.store_name, 'New Store'),
      coalesce(nullif(app.store_slug,''), 'store-' || substr(app.id::text,1,8)),
      coalesce(app.store_name, 'New Store'),
      coalesce(app.store_name, 'New Store'),
      'verified',
      'active'
    )
    on conflict (slug) do update
      set status = 'active',
          verification_status = 'verified';
  end if;

  return app;
end;
$$;

-- Restrict execute
revoke all on function public.transition_order_status(uuid, text, text) from public;
revoke all on function public.create_checkout_order_group(text, uuid, uuid, uuid, text, text) from public;
revoke all on function public.submit_review(jsonb) from public;
revoke all on function public.adjust_inventory(uuid, uuid, integer, uuid, text) from public;
revoke all on function public.mark_notifications_read(uuid) from public;
revoke all on function public.send_secure_message(jsonb) from public;
revoke all on function public.review_seller_application(uuid, text, text) from public;

grant execute on function public.transition_order_status(uuid, text, text) to authenticated;
grant execute on function public.create_checkout_order_group(text, uuid, uuid, uuid, text, text) to authenticated;
grant execute on function public.submit_review(jsonb) to authenticated;
grant execute on function public.adjust_inventory(uuid, uuid, integer, uuid, text) to authenticated;
grant execute on function public.mark_notifications_read(uuid) to authenticated;
grant execute on function public.send_secure_message(jsonb) to authenticated;
grant execute on function public.review_seller_application(uuid, text, text) to authenticated;
