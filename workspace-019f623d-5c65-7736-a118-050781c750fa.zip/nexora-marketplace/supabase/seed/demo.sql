-- Development seed is primarily provided by src/mocks/seed.ts for mock mode.
-- After applying migrations, insert role keys and platform defaults here.
insert into public.roles (key, name) values
  ('buyer', 'Buyer'),
  ('seller', 'Seller'),
  ('store_staff', 'Store Staff'),
  ('moderator', 'Moderator'),
  ('admin', 'Administrator'),
  ('super_admin', 'Super Administrator')
on conflict (key) do nothing;

insert into public.feature_flags (key, enabled, description) values
  ('offers', true, 'Buyer offers'),
  ('messaging', true, 'Buyer-seller messaging'),
  ('productModeration', true, 'Require product moderation'),
  ('maintenanceMode', false, 'Maintenance mode')
on conflict (key) do nothing;
